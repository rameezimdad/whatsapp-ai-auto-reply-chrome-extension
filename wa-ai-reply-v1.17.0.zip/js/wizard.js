/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// first-run setup wizard + welcome tour
import { $, esc, bg, toast, busy, openWa } from './ui.js';
import { BIZ, buildPrompt, PRESETS, presetOf, getCfg, setCfg, bizDemo, demoSeq } from './cfg.js';

const ENG = {
  claude: ['Claude', 'fa-asterisk', 'claudeKey', 'console.anthropic.com', 'sk-ant-...'],
  openai: ['ChatGPT', 'fa-brain', 'openaiKey', 'platform.openai.com', 'sk-...'],
  gemini: ['Gemini', 'fa-gem', 'geminiKey', 'aistudio.google.com', 'AIza...'],
  grok: ['Grok', 'fa-x', 'grokKey', 'console.x.ai', 'xai-...']
};
const STEPS = ['Pick the AI', 'Add the key', 'Your business', 'Go live'];
const BIZ_KEYS = ['bizType', 'bizName', 'bizAbout', 'bizProducts', 'bizHours', 'bizAddress', 'bizDelivery', 'bizPayment', 'bizReturns', 'bizOrder', 'bizExtra'];
const dlg = $('wizDlg');
let w = {}, step = 0;
// a saved key is never put back on screen: the box starts empty, empty = keep it
const keyOf = () => w.key || w.saved?.[ENG[w.engine][2]] || '';
const masked = v => v.length > 12 ? `${v.slice(0, 5)}…${v.slice(-4)}` : '••••••';
const val = id => $(id)?.value.trim() ?? '';

// keep typed values when moving between steps
const grab = () => {
  if (step === 0) w.engine = dlg.querySelector('[name=wEngine]:checked')?.value || w.engine;
  if (step === 1) w.key = val('wKey');
  if (step === 2) {
    w.bizType = dlg.querySelector('[name=wBizType]:checked')?.value || w.bizType;
    ['bizName', 'bizProducts', 'bizHours', 'bizAddress', 'bizDelivery', 'bizPayment'].forEach(k => w[k] = val('w_' + k));
  }
  if (step === 3) { w.preset = dlg.querySelector('[name=wPreset]:checked')?.value || w.preset; w.allow = val('wAllow'); w.on = $('wOn').checked; w.consent = $('wConsent').checked; }
};

const tiles = (name, list, cur) => list.map(([k, label, ic, note]) => `<label class="tile"><input type="radio" name="${name}" value="${k}"${k === cur ? ' checked' : ''}>
  <span class="ic"><i class="fa-solid ${ic}"></i></span><b>${esc(label)}</b>${note ? `<small>${esc(note)}</small>` : ''}<i class="chk fa-solid fa-circle-check"></i></label>`).join('');
const field = (id, label, ph, tall) => `<div class="fg"><label for="w_${id}">${esc(label)}</label>${tall
  ? `<textarea class="field" id="w_${id}" placeholder="${esc(ph)}">${esc(w[id] || '')}</textarea>`
  : `<input class="field" id="w_${id}" placeholder="${esc(ph)}" value="${esc(w[id] || '')}">`}</div>`;

const PANES = [
  () => `<h3 class="wiz-h"><i class="fa-solid fa-microchip"></i> Which AI should write your replies?</h3>
    <p class="hint">Any of them works well. You can switch later on the AI engine page.</p>
    <div class="tiles wiz-tiles">${tiles('wEngine', Object.entries(ENG).map(([k, e]) => [k, e[0], e[1], k === 'claude' ? 'Anthropic' : k === 'openai' ? 'OpenAI' : k === 'gemini' ? 'Google' : 'xAI']), w.engine)}</div>`,
  () => { const e = ENG[w.engine]; return `<h3 class="wiz-h"><i class="fa-solid fa-key"></i> Paste your ${e[0]} API key</h3>
    <p class="hint">Make one at <b>${e[3]}</b> → API keys. It stays in this browser and goes only to ${e[0]}.</p>
    <div class="fg"><label for="wKey">API key</label>
      <div class="key-row"><div class="pwd"><input class="field" type="password" id="wKey" placeholder="${w.saved?.[e[2]] ? esc(`Saved key ${masked(w.saved[e[2]])} · leave empty to keep it`) : e[4]}" value="${esc(w.key || '')}" autocomplete="off" spellcheck="false">
        <button type="button" data-eye="wKey" aria-label="Show or hide key"><i class="fa-solid fa-eye"></i></button></div>
        <button type="button" class="btn btn-primary" id="wCheck"><i class="fa-solid fa-plug-circle-check"></i> Check key</button></div>
      <span class="key-msg ${w.keyOk ? 'ok' : w.keyErr ? 'bad' : ''}" id="wKeyMsg">${w.keyOk ? `<i class="fa-solid fa-circle-check"></i> Key works. ${w.keyN ? `${w.keyN} models found.` : ''}` : w.keyErr ? `<i class="fa-solid fa-circle-exclamation"></i> ${esc(w.keyErr)}` : 'Press Check key after pasting.'}</span>
    </div>`; },
  () => `<h3 class="wiz-h"><i class="fa-solid fa-store"></i> Tell the AI about your business</h3>
    <p class="hint">Short answers are fine. You can add more later on Business info.</p>
    <div class="fill-bar">
      <button type="button" class="btn btn-primary" id="wFillWa"><i class="fa-brands fa-whatsapp"></i> Fill from my WhatsApp</button>
      <button type="button" class="btn btn-secondary" id="wFillDemo" title="Fill with demo data for testing" aria-label="Fill with demo data for testing"><i class="fa-solid fa-circle-info"></i> Demo data</button>
      <span class="hint" id="wFillMsg">${esc(w.fillMsg || 'Reads your WhatsApp Business profile, catalog and your own replies. Keep WhatsApp Web open.')}</span>
    </div>
    <div class="tiles biz-tiles">${tiles('wBizType', Object.entries(BIZ).map(([k, b]) => [k, b.label, b.ic]), w.bizType)}</div>
    ${field('bizName', 'Business name', 'Demo Store')}
    ${field('bizProducts', (BIZ[w.bizType] || BIZ.other).products, (BIZ[w.bizType] || BIZ.other).ph, true)}
    ${field('bizHours', 'Timings', '10am to 9pm, Monday to Saturday')}
    ${field('bizAddress', 'Address', 'House 1, Street 1, Demo City')}
    ${field('bizDelivery', 'Delivery', 'All over the country in 2-4 days, Rs 200')}
    ${field('bizPayment', 'Payment', 'Cash on delivery or bank transfer')}`,
  () => `<h3 class="wiz-h"><i class="fa-solid fa-shield-heart"></i> How careful should the bot be?</h3>
    <p class="hint">Careful is best for a new number. You can change it on the Safety page.</p>
    <div class="tiles presets">${tiles('wPreset', Object.entries(PRESETS).map(([k, p]) => [k, p.label, p.ic, p.note]), w.preset)}</div>
    <div class="fg"><label for="wAllow">Test on your own second number first (optional)</label>
      <input class="field" id="wAllow" placeholder="923001234567" value="${esc(w.allow || '')}" inputmode="tel">
      <span class="hint">With country code. The bot replies only to this number until you clear it on Contacts.</span></div>
    <div class="toggle-row wiz-on"><div class="txt"><b>Turn the bot on when I finish</b><span class="hint">It writes replies; you check and send them from the panel on WhatsApp Web.</span></div>
      <input type="checkbox" class="toggle" id="wOn" ${w.on ? 'checked' : ''} aria-label="Turn the bot on when I finish"></div>
    <label class="consent"><input type="checkbox" id="wConsent" ${w.consent ? 'checked' : ''}>
      <span>I understand: WA AI Reply reads new messages in my WhatsApp Web chats and sends them, with my business info, to ${esc(ENG[w.engine][0])} to write replies. Every reply waits for my Send, and nothing goes to Rameez Scripts.</span></label>
    <button type="button" class="btn btn-secondary" id="wWa"><i class="fa-brands fa-whatsapp"></i> Open WhatsApp Web</button>`
];

const side = () => {
  if (step === 2) return `<h3><i class="fa-solid fa-eye"></i> What the AI will read</h3><pre class="sample">${esc(buildPrompt({ ...w, bizTone: 'friendly and short' }))}</pre>`;
  const e = ENG[w.engine] || ENG.claude, done = (ok, t) => `<li class="${ok ? 'done' : ''}"><i class="fa-solid ${ok ? 'fa-circle-check' : 'fa-circle-exclamation'}"></i>${esc(t)}</li>`;
  return `<h3><i class="fa-solid fa-list-check"></i> Your setup</h3><ul class="need">
    ${done(true, `AI: ${e[0]}`)}${done(w.keyOk, w.keyOk ? 'Key checked' : 'Key not checked yet')}
    ${done(!!w.bizName, w.bizName ? `Business: ${w.bizName}` : 'Business name missing')}
    ${done(true, `Safety: ${PRESETS[w.preset]?.label || 'Normal'}`)}${done(!!w.allow, w.allow ? `Test number: ${w.allow}` : 'No test number (replies to everyone)')}</ul>
    <h3><i class="fa-solid fa-circle-info"></i> Good to know</h3>
    <ul class="plain"><li>You pay ${esc(e[0])} for what the bot uses, on your own account.</li><li>Every reply waits for your Send on WhatsApp Web, so you always see what goes out.</li><li>Everything here can be changed later in Settings.</li></ul>`;
};

const render = () => {
  $('wizSteps').innerHTML = STEPS.map((t, i) => `<li class="${i === step ? 'on' : i < step ? 'done' : ''}"><span>${i < step ? '<i class="fa-solid fa-check"></i>' : i + 1}</span>${esc(t)}</li>`).join('');
  $('wizPane').innerHTML = PANES[step]();
  $('wizSide').innerHTML = side();
  dlg.querySelector('[data-wiz=back]').hidden = step === 0;
  dlg.querySelector('[data-wiz=next]').innerHTML = step === STEPS.length - 1 ? '<i class="fa-solid fa-check"></i> Finish' : 'Next <i class="fa-solid fa-arrow-right"></i>';
};

const checkKey = async btn => {
  w.key = val('wKey');
  if (!keyOf()) return toast('Paste the key first', true);
  busy(btn, true);
  const r = await bg({ type: 'keyTest', engine: w.engine, key: keyOf() });
  busy(btn, false);
  Object.assign(w, { keyOk: !!r.ok, keyN: r.n || 0, keyErr: r.ok ? '' : r.err });
  render();
};

// auto fill: WhatsApp Business profile + catalog + my own replies, or a demo set for testing
const fillWa = async btn => {
  grab();
  busy(btn, true);
  try {
    const r = await bg({ type: 'bizFill', engine: w.engine, key: keyOf() });
    if (!r?.ok) return toast(r?.err || 'Could not read WhatsApp', true);
    Object.assign(w, r.fields);
    w.fillMsg = !r.business && !r.ai ? 'This number is not a WhatsApp Business account, so only the name was filled. Type the rest, or press Demo data to try it out.'
      : `Filled from ${[r.business && 'your WhatsApp Business profile', r.products && `${r.products} catalog products`, r.chats && `${r.chats} of your replies`].filter(Boolean).join(', ') || 'WhatsApp'}. Check every box and fix what is wrong.`;
    render();
    toast('Filled. Check the boxes before you go on.');
  } finally { busy(btn, false); }
};
const fillDemo = () => {
  grab();
  const n = demoSeq('biz');
  Object.assign(w, bizDemo(w.bizType || 'shop', n), { fillMsg: `Demo set #${n}. Replace it with your real business before you go live.` });
  render();
};

const finish = async btn => {
  busy(btn, true);
  try {
    const cfg = await getCfg(), biz = Object.fromEntries(BIZ_KEYS.map(k => [k, w[k] ?? cfg[k] ?? ''])); // boxes the wizard never showed keep what was saved
    await setCfg({
      engine: w.engine, [ENG[w.engine][2]]: keyOf(), ...biz, bizMode: 'form', prompt: buildPrompt({ ...cfg, ...biz }),
      ...PRESETS[w.preset].set, allow: w.allow, enabled: !!w.on, consent: true, setupDone: true
    });
    dlg.close();
    dispatchEvent(new CustomEvent('waai:saved')); // settings page reloads its form
    toast(w.on ? 'Setup done. The bot is on.' : 'Setup done. Turn the bot on when you are ready.');
    openTour();
  } finally { busy(btn, false); }
};

dlg.addEventListener('click', e => {
  const b = e.target.closest('[data-wiz]');
  if (e.target.closest('#wCheck')) return checkKey(e.target.closest('#wCheck'));
  if (e.target.closest('#wFillWa')) return fillWa(e.target.closest('#wFillWa'));
  if (e.target.closest('#wFillDemo')) return fillDemo();
  if (e.target.closest('#wWa')) return openWa();
  if (!b) return;
  const a = b.dataset.wiz;
  grab();
  if (a === 'close') { try { localStorage.setItem('waai_wiz_later', '1'); } catch {} return dlg.close(); }
  if (a === 'back') { step--; return render(); }
  if (step === 1 && !w.keyOk) return toast('Press Check key first. The bot needs a working key.', true);
  if (step === 3 && !w.consent) return toast('Tick the box to agree before finishing', true);
  if (step === 2 && !w.bizName) { $('w_bizName').classList.add('bad'); $('w_bizName').focus(); return toast('Add your business name', true); }
  step < STEPS.length - 1 ? (step++, render()) : finish(b);
});
dlg.addEventListener('change', e => {
  if (e.target.name === 'wEngine' && e.target.value !== w.engine) { grab(); Object.assign(w, { key: '', keyOk: false, keyErr: '' }); }
  if (e.target.name === 'wBizType') { grab(); render(); }
});
dlg.addEventListener('input', e => {
  e.target.classList.remove('bad');
  if (e.target.id === 'wKey') { w.keyOk = false; $('wKeyMsg').className = 'key-msg'; $('wKeyMsg').textContent = 'Press Check key after pasting.'; }
  if (step === 2) { grab(); $('wizSide').innerHTML = side(); }
});
dlg.addEventListener('cancel', () => { try { localStorage.setItem('waai_wiz_later', '1'); } catch {} });

export const openWizard = async () => {
  const cfg = await getCfg(), engine = cfg.engine === 'webhook' ? 'claude' : cfg.engine, p = presetOf(cfg);
  w = { engine, key: '', saved: Object.fromEntries(Object.values(ENG).map(x => [x[2], cfg[x[2]] || ''])), keyOk: false, consent: !!cfg.consent, ...Object.fromEntries(BIZ_KEYS.map(k => [k, cfg[k]])), preset: p === 'custom' ? 'careful' : p, allow: cfg.allow, on: true };
  step = 0;
  render();
  dlg.showModal();
};

// welcome tour: once per browser
const TOUR = [
  ['fa-paper-plane', 'You press Send', 'The AI writes each reply and it waits on WhatsApp Web (bottom left) and here. Change it if you like, then press Send.'],
  ['fa-gauge-high', 'Dashboard', 'See what the bot did today, the chats that need you, and the one thing to do next.'],
  ['fa-bolt', 'Quick replies', 'Save answers like prices, location and bank details. The bot sends them word for word.'],
  ['fa-bag-shopping', 'Orders', 'Orders the AI takes after the customer says yes. Check them and confirm with one click.'],
  ['fa-book', 'Guide', 'Step by step help and fixes for common problems, any time you need them.']
];
const tour = $('tourDlg');
let ts = 0;
const paintTour = () => {
  const [ic, t, d] = TOUR[ts];
  $('tourIc').className = `fa-solid ${ic}`;
  $('tourTitle').textContent = t;
  $('tourText').textContent = d;
  $('tourDots').innerHTML = TOUR.map((_, i) => `<button type="button" class="${i === ts ? 'on' : ''}" data-dot="${i}" aria-label="Step ${i + 1}"></button>`).join('');
  tour.querySelector('[data-tour=next]').innerHTML = ts < TOUR.length - 1 ? 'Next <i class="fa-solid fa-arrow-right"></i>' : '<i class="fa-solid fa-check"></i> Get started';
};
const closeTour = () => { try { localStorage.setItem('ai_tour_owner', '1'); } catch {} tour.close(); };
tour.addEventListener('click', e => {
  const d = e.target.closest('[data-dot]'), b = e.target.closest('[data-tour]');
  if (d) { ts = +d.dataset.dot; return paintTour(); }
  if (!b) return;
  b.dataset.tour === 'skip' || ts === TOUR.length - 1 ? closeTour() : (ts++, paintTour());
});
tour.addEventListener('cancel', closeTour);
export const openTour = (force = false) => {
  let seen = false;
  try { seen = !!localStorage.getItem('ai_tour_owner'); } catch {}
  if (seen && !force) return;
  ts = 0;
  paintTour();
  tour.showModal();
};
export const wizLater = () => { try { return !!localStorage.getItem('waai_wiz_later'); } catch { return false; } };
