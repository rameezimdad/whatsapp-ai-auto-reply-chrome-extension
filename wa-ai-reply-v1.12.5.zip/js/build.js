/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// tools/pack.sh flips this in the Chrome Web Store zip: that copy never sends without review
export const STORE_BUILD = false;
