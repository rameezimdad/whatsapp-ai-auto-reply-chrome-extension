/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// License page, dashboard banner and sidebar pill
import { $, esc, bg, toast, busy, ago, confirmBox } from './ui.js';
import { PLANS_URL } from './license.js';

document.querySelectorAll('[data-plans]').forEach(a => a.href = PLANS_URL);

const PLANS_API = 'https://rameezscripts.com/wa-ai-reply.php?plans=json';
const FALLBACK_PLANS = [
  { key: '1m', name: 'Monthly', usd: '1.19', display: '1.19', term: '1 month', line: 'One month of replies. Renew whenever you like.', contacts: '100 contacts a day', device: '1 device · 1 month from activation', payments: [] },
  { key: '1y', name: 'Yearly', usd: '11.99', display: '11.99', term: '12 months', line: 'About USD 1.00 a month.', badge: 'Popular', contacts: '500 contacts a day', device: '1 device · 12 months from activation', payments: [] },
  { key: 'src', name: 'Complete Source Code', usd: '49.99', display: '49.99', term: 'lifetime', line: 'Own the source code with a lifetime key. Change it, brand it, run it your way.', badge: 'Lifetime', contacts: 'Unlimited contacts', device: 'Full source code · lifetime key', payments: [] }
];
const planUrl = key => `https://rameezscripts.com/wa-ai-reply.php?buy=${encodeURIComponent(key)}#plans`;
// method name -> icon
const payIcon = n => [[/card|visa|master/i, 'fa-solid fa-credit-card'], [/google/i, 'fa-brands fa-google-pay'], [/binance|usdt|crypto/i, 'fa-brands fa-bitcoin'], [/paypal/i, 'fa-brands fa-paypal'], [/easypaisa|jazz|wallet|upi/i, 'fa-solid fa-mobile-screen'], [/bank|meezan|alfalah|hbl|ubl|wise/i, 'fa-solid fa-building-columns']].find(([re]) => re.test(n))?.[1] || 'fa-solid fa-wallet';
const renderPlans = (plans, currency = 'USD') => {
  const box = $('licPlans');
  if (!box) return;
  // free trial first, shown only while this copy can still start one (trialVis)
  box.innerHTML = `<article class="lic-plan lic-plan-trial" id="trialPlan" hidden>
      <div class="lic-plan-top">
        <div class="lic-plan-hero">
          <div class="lic-plan-tags"><span class="lic-plan-name">Free trial</span><em class="lic-plan-badge">No card</em></div>
          <p class="lic-price">Free<span class="lic-per">/1 day</span></p>
        </div>
        <p class="lic-plan-sub">Try every feature for one day before you buy.</p>
        <button type="button" class="lic-plan-btn" data-trial><i class="fa-brands fa-google"></i> Start with Google</button>
      </div>
      <ul class="lic-plan-feats">
        <li><i class="fa-solid fa-check"></i> Every feature unlocked</li>
        <li><i class="fa-solid fa-check"></i> 5 contacts a day</li>
        <li><i class="fa-solid fa-check"></i> 1 device · 1 day</li>
        <li><i class="fa-solid fa-check"></i> Your own Google Sheet</li>
      </ul>
    </article>` + plans.map(p => {
    const url = esc(p.checkout || planUrl(p.key)), price = String(p.display || p.usd), pay = p.payments || [];
    const per = p.key === 'src' ? 'lifetime' : p.term;
    return `<article class="lic-plan${p.badge === 'Popular' ? ' hot' : ''}">
      <div class="lic-plan-top">
        <div class="lic-plan-hero">
          <div class="lic-plan-tags"><span class="lic-plan-name">${esc(p.name)}</span>${p.badge ? `<em class="lic-plan-badge">${esc(p.badge)}</em>` : ''}</div>
          <p class="lic-price"><small>${esc(currency)}</small>${esc(price)}<span class="lic-per">/${esc(per)}</span></p>
        </div>
        <p class="lic-plan-sub">${esc(p.line)}</p>
        <a class="lic-plan-btn" href="${url}" target="_blank" rel="noopener">Buy ${esc(p.name)}</a>
      </div>
      <ul class="lic-plan-feats">
        <li><i class="fa-solid fa-check"></i> Every feature unlocked</li>
        <li><i class="fa-solid fa-check"></i> ${esc(p.contacts)}</li>
        <li><i class="fa-solid fa-check"></i> ${esc(p.device)}</li>
        <li><i class="fa-solid fa-check"></i> All updates free</li>
      </ul>
      ${pay.length ? `<div class="lic-pay-row">${pay.map(m => `<a class="lic-pay" href="${url}" target="_blank" rel="noopener" title="Pay with ${esc(m.name)}"><i class="${payIcon(m.name)}"></i><span>${esc(m.name)}</span></a>`).join('')}</div>` : ''}
    </article>`;
  }).join('');
  trialVis();
};
const trialVis = () => { $('trialPlan') && ($('trialPlan').hidden = !(last && last.state === 'none' && !last.trialUsed)); };
let plansAsked = false;
const loadPlans = async () => {
  if (plansAsked) return;
  plansAsked = true;
  renderPlans(FALLBACK_PLANS);
  try {
    const r = await fetch(PLANS_API, { credentials: 'omit', cache: 'no-store', signal: AbortSignal.timeout(12000) });
    const j = r.ok ? await r.json() : null, d = j?.success && j.data;
    if (!Array.isArray(d?.plans) || !d.plans.length) throw new Error('Plans unavailable');
    renderPlans(d.plans, d.currency || 'USD');
  } catch {}
};

const day = ms => new Date(ms).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const when = ms => ms ? new Date(ms).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'never';
const safeUrl = u => /^https:\/\//i.test(u || '') ? u : '';
const SOON = 7;
// time left on a short key: hours under two days
const left = s => { const h = Math.max(0, Math.ceil((s.exp - Date.now()) / 36e5)); return h < 48 ? `${h} ${h === 1 ? 'hour' : 'hours'}` : `${Math.ceil(h / 24)} days`; };

// state -> [icon, title, line, tone]
const head = s => s.trial && s.state === 'active' ? ['fa-hourglass-half', 'Free trial', `Ends ${when(s.exp)} · ${left(s)} left. Add a key before then to keep replying.`, 'warn']
  : s.trial && s.state === 'expired' ? ['fa-hourglass-end', 'Free trial ended', 'Get a licence key and paste it below to keep using WA AI Reply.', 'bad'] : ({
  none: ['fa-key', 'Not activated', 'Paste the key you got from the seller and press Activate.', 'warn'],
  active: ['fa-circle-check', 'Active', s.exp ? `Until ${day(s.exp)} · ${s.days < 1 ? 'ends today' : `${s.days} days left`}` : 'Lifetime key, it never ends.', s.days != null && s.days < SOON ? 'warn' : 'ok'],
  offline: ['fa-wifi', 'Needs a check', `The licence server could not be reached since ${when(s.at)}. Nothing is sent until it can check. Connect to the internet and press Check now.`, 'bad'],
  expired: ['fa-calendar-xmark', 'Expired', `Ended on ${s.exp ? day(s.exp) : 'its end date'}. Renew the key to keep replying.`, 'bad'],
  suspended: ['fa-pause', 'Paused by the seller', s.msg, 'bad'],
  revoked: ['fa-ban', 'Cancelled by the seller', s.msg, 'bad'],
  other_device: ['fa-laptop', 'Used on another device', s.msg, 'bad'],
  reset: ['fa-rotate', 'Activate again', s.msg, 'warn'],
  invalid: ['fa-ban', 'Key removed', 'The seller removed this key. Get a new key from the seller.', 'bad'],
  cloned: ['fa-clone', 'Copied to another computer', s.msg, 'bad'],
}[s.state] || ['fa-triangle-exclamation', 'Could not check the key', s.msg || s.err || '', 'bad']);

let last = null;
const paint = s => {
  last = s;
  if (!$('licHero')) return;
  const [ic, title, line, tone] = head(s), soon = s.ok && s.days != null && s.days < SOON, renew = safeUrl(s.renew) || PLANS_URL;
  $('licHero').className = `lic-hero ${tone}`;
  $('licHero').innerHTML = `<span class="lic-ic"><i class="fa-solid ${ic}"></i></span><div><b>${esc(title)}</b><span>${esc(line)}</span></div>`;
  const askKey = ['none', 'reset'].includes(s.state) || s.trial; // a trial can take a bought key any time
  $('licForm').hidden = !askKey;
  askKey && s.key && !$('licKey').value && ($('licKey').value = s.key);
  $('licFail').hidden = !s.fail;
  $('licFail').innerHTML = s.fail ? `<i class="fa-solid fa-circle-exclamation"></i> ${esc(s.fail)}` : '';
  const showInfo = !!s.key && s.state !== 'none';
  $('licInfo').hidden = !showInfo;   // buttons only, the key details are not shown
  if (showInfo) {
    $('licCheck').hidden = false;
    $('licRelease').hidden = s.trial || !['active', 'expired', 'offline'].includes(s.state); // a trial never moves
    $('licForget').hidden = !['other_device', 'revoked', 'reset', 'invalid'].includes(s.state);
    $('licRenew').hidden = s.trial || !renew || !(soon || ['expired', 'suspended', 'revoked'].includes(s.state)); // trial: the Get a key button above
    renew && ($('licRenew').href = renew);
  }
  paintBadges(s);
  gLast && gPaint(gLast);
  trialVis();
};

// key not active: every page but License is locked, and the lock says why
const lock = s => {
  const on = !s.ok;
  document.body.classList.toggle('lic-locked', on);
  if (!on) return;
  $('licLockWhy').textContent = s.state === 'none' ? 'Activate your licence key to use the extension.' : `${head(s)[1]}. ${head(s)[2] || ''}`.trim();
  const cur = document.querySelector('.view:not([hidden])')?.dataset.view;
  $('licLock').hidden = cur === 'license';
  cur && cur !== 'license' && document.querySelector('[data-nav="license"]')?.click(); // no sidebar while locked
};
addEventListener('waai:view', e => {
  if (!document.body.classList.contains('lic-locked')) return;
  $('licLock').hidden = e.detail === 'license';
  e.detail !== 'license' && document.querySelector('[data-nav="license"]')?.click();
});
document.addEventListener('click', e => { const b = e.target.closest('[data-nav-to]'); b && document.querySelector(`[data-nav="${b.dataset.navTo}"]`)?.click(); });

// sidebar pill + dashboard banner, also used before the License page was opened
export const paintBadges = s => {
  if (!s?.state) return;
  lock(s);
  const soon = s.ok && s.days != null && s.days < SOON, bad = !s.ok, endsIn = s.trial ? `Free trial ends in ${left(s)}` : `Licence ends in ${s.days < 1 ? 'less than a day' : `${s.days} days`}`;
  $('pillLic') && ($('pillLic').hidden = !bad && !soon);
  const b = $('licBanner');
  if (!b) return;
  b.hidden = !bad && !soon;
  if (b.hidden) return;
  const [ic, title, line] = head(s);
  b.className = `lic-banner ${bad ? 'bad' : 'warn'}`;
  b.innerHTML = `<i class="fa-solid ${ic}"></i><div><b>${esc(bad ? (s.trial ? title : `Licence: ${title}`) : endsIn)}</b><span>${esc(bad ? `${line || ''} The bot stays off until the key is active.` : s.trial ? 'Add a licence key so replies do not stop.' : 'Renew it so replies do not stop.')}</span></div>
    <button class="btn btn-primary btn-sm" data-go="license"><i class="fa-solid fa-key"></i> ${bad ? 'Open License' : s.trial ? 'Add a key' : 'Renew'}</button>`;
};

const load = async (type, extra) => {
  const s = await bg({ type, ...extra });
  s.state ? paint(s) : toast(s.err || 'Could not check the key', true);
  return s;
};
export const licLoad = () => load('licGet');

$('licActivate').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  const key = $('licKey').value.trim();
  if (!key) { $('licKey').focus(); return toast('Paste your key first', true); }
  busy(btn, true);
  try {
    const s = await load('licActivate', { key });
    if (s.ok) {
      toast('Activated');
      $('licKey').value = '';
      dispatchEvent(new CustomEvent('waai:licensed')); // first run: setup comes next
    }
  } finally { busy(btn, false); }
};
$('licKey').addEventListener('keydown', e => e.key === 'Enter' && $('licActivate').click());
$('licCheck').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try { const s = await load('licCheck'); s.fail ? toast(s.fail, true) : toast(s.ok ? 'Checked: the key is active' : 'Checked'); }
  finally { busy(btn, false); }
};
$('licRelease').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  if (!(await confirmBox('Remove the key from this device?', `The bot turns off here, and you can activate the key on another device. ${last?.moves ?? 0} moves left.`, { ok: 'Remove', danger: true }))) return;
  busy(btn, true);
  try { const s = await load('licRelease'); s.done ? toast('Removed. Activate the key on your other device.') : s.fail && toast(s.fail, true); }
  finally { busy(btn, false); }
};
$('licForget').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try { await load('licForget'); $('licKey').value = ''; $('licKey').focus(); }
  finally { busy(btn, false); }
};

// Google: sign in, own Sheet, free trial on a new install
let gLast = null;
const gPaint = g => {
  if (!$('gCard')) return;
  const inn = !!g?.acct, trialOk = !!last && last.state === 'none' && !last.trialUsed;
  $('gBanner').hidden = !(inn && g.kind === 'login');
  $('gOut').hidden = inn;
  $('gIn').hidden = !inn;
  $('gTitle').textContent = trialOk ? 'Start free with Google' : 'Back up to Google Sheets';
  $('gLine').textContent = trialOk ? 'Free trial + your own Google Sheet for orders and customers.' : 'Orders, customers and bookings in your own Google Sheet, on any computer.';
  if (!inn) return;
  $('gAvatar').textContent = (g.acct.name || g.acct.email || 'G')[0].toUpperCase();
  $('gName').textContent = g.acct.name;
  $('gEmail').textContent = g.acct.email;
  $('gSheetName').textContent = g.sheet?.name || 'Google Sheet';
  $('gSheetWhen').textContent = g.busy ? 'Saving now…' : g.last ? `Saved ${ago(new Date(g.last).toISOString())}` : 'Not saved yet';
  $('gOpen').hidden = !g.sheet?.url;
  g.sheet?.url && ($('gOpen').href = g.sheet.url);
  $('gErr').hidden = !g.err;
  $('gErrText').textContent = g.err;
  $('gRelogin').hidden = g.kind !== 'login';
};
const gLoad = async () => gPaint(gLast = await bg({ type: 'gState' }));
const NOUN = { Orders: 'orders', Bookings: 'bookings', Customers: 'customers', 'Quick replies': 'quick replies', Knowledge: 'facts', 'Opted out': 'opt-outs' };
const brought = sum => { const p = Object.entries(sum || {}).filter(([t, n]) => NOUN[t] && n).map(([t, n]) => `${n} ${NOUN[t]}`); sum?.Settings && p.push('your settings'); sum?.Keys && p.push('your AI keys'); return p.join(', '); };
const gGo = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try {
    const r = await bg({ type: 'gLogin' });
    if (!r.acct) return toast(r.err || 'Google sign-in did not finish. Try again.', true);
    gPaint(gLast = r);
    const s = await licLoad(), back = brought(r.sync?.sum);
    r.sync?.sum?.Settings && dispatchEvent(new CustomEvent('waai:saved'));
    if (r.trial === 'started') toast(`Free trial started. Your Google Sheet is ready${back ? `. Brought back: ${back}` : ''}.`);
    else if (r.trial) toast(r.trial, true);
    else if (r.sync && !r.sync.ok) toast(r.sync.err, true);
    else toast(back ? `Signed in. Brought back from your Sheet: ${back}.` : 'Signed in. Your data is saved in your Google Sheet.');
    s.ok && r.trial === 'started' && dispatchEvent(new CustomEvent('waai:licensed')); // setup comes next
  } finally { busy(btn, false); }
};
$('gLogin').onclick = gGo;
$('licPlans').addEventListener('click', e => e.target.closest('[data-trial]') && $('gLogin').click()); // trial card = Continue with Google
$('gRelogin').onclick = gGo;
$('gSyncBtn').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try {
    const r = await bg({ type: 'gSync' });
    gPaint(gLast = r);
    const back = brought(r.sum);
    r.ok ? toast(back ? `Saved. Brought back: ${back}.` : 'Saved in your Google Sheet') : toast(r.err || 'Could not save', true);
  } finally { busy(btn, false); }
};
$('gLogout').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  if (!(await confirmBox('Sign out of Google?', 'Your data stays here and in your Google Sheet. New orders and customers are not saved to the Sheet until you sign in again.', { ok: 'Sign out', danger: true }))) return;
  busy(btn, true);
  try { await bg({ type: 'gLogout' }); await gLoad(); toast('Signed out of Google'); }
  finally { busy(btn, false); }
};

addEventListener('waai:view', e => { if (e.detail === 'license') loadPlans(); (e.detail === 'license' || e.detail === 'dashboard') && (licLoad(), gLoad()); });
chrome.storage.onChanged.addListener(c => {
  c.lic && last && bg({ type: 'licGet' }).then(s => s.state && paint(s));
  (c.gsync || c.gAcct) && gLoad();
});
loadPlans();
licLoad();
gLoad();
