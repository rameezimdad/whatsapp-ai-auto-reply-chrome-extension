/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
export const $ = id => document.getElementById(id);
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// background call; never throws, always {ok, err?}
const STALE = 'The extension was updated. Press reload ↻ on its card in chrome://extensions, then try again.';
export const bg = msg => chrome.runtime.sendMessage(msg)
  .then(r => r ?? { ok: false, err: STALE })
  .catch(e => ({ ok: false, err: /port closed|Receiving end|context invalidated/i.test(e?.message) ? STALE : String(e?.message || e) }));

let tt;
export const toast = (msg, err = false) => {
  const el = $('toast');
  el.innerHTML = `<i class="fa-solid ${err ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i> ${esc(msg)}`;
  el.classList.toggle('err', err);
  el.classList.add('show');
  clearTimeout(tt);
  tt = setTimeout(() => el.classList.remove('show'), 2800);
};

// button busy state
export const busy = (btn, on) => {
  const i = btn.querySelector('i');
  btn.disabled = on;
  if (!i) return;
  on ? (i.dataset.ic = i.className, i.className = 'fa-solid fa-spinner fa-spin') : (i.className = i.dataset.ic || i.className);
};

export const ago = iso => {
  const s = Math.round((Date.now() - new Date(iso)) / 1000);
  return s < 60 ? 'just now' : s < 3600 ? `${Math.floor(s / 60)} min ago` : s < 86400 ? `${Math.floor(s / 3600)} h ago` : iso.slice(0, 10);
};

// log status → [class, icon, label]
export const ST = {
  sent: ['c-sent', 'fa-paper-plane', 'Replied'],
  human: ['c-human', 'fa-user-clock', 'Needs you'],
  skip: ['c-skip', 'fa-forward', 'Skipped'],
  error: ['c-error', 'fa-triangle-exclamation', 'Error'],
  stop: ['c-skip', 'fa-hand', 'Opted out'],
  held: ['c-skip', 'fa-circle-pause', 'Not replied']
};
export const ENGINE = { claude: 'Claude', openai: 'ChatGPT', gemini: 'Gemini', grok: 'Grok', webhook: 'My server' };
export const WA = 'https://web.whatsapp.com/';

const empty = (ic, title, line) => `<div class="empty"><i class="${ic}"></i><b>${esc(title)}</b>${esc(line)}</div>`;

export const logHtml = (log, n = 15) => log.slice(0, n).map(l => {
  const [c, ic, lbl] = ST[l.st] || ST.error;
  return `<div class="item"><div class="head">
    <span class="name">${esc(l.name || l.phone || l.chatId)}</span>
    ${l.qr?.length ? `<span class="qr-pill" title="Quick reply"><i class="fa-solid fa-bolt"></i>/${esc(l.qr.join(' /'))}</span>` : ''}
    ${l.order ? '<span class="qr-pill" title="An order was taken"><i class="fa-solid fa-bag-shopping"></i>Order</span>' : ''}
    <span class="pill ${c}"><i class="fa-solid ${ic}"></i> ${lbl}</span><time title="${esc(l.at)}">${ago(l.at)}</time></div>
    ${l.in ? `<p><i class="fa-solid fa-arrow-down"></i> ${esc(l.in)}</p>` : ''}
    ${l.out ? `<p><i class="fa-solid fa-arrow-up"></i> ${esc(l.out)}</p>` : ''}
    ${l.err ? `<p><i class="fa-solid fa-bug"></i> ${esc(l.err)}</p>` : ''}</div>`;
}).join('') || empty('fa-regular fa-comments', 'No replies yet', 'Turn the bot on and messages show up here.');

export const pausedHtml = (paused, log) => {
  const names = Object.fromEntries([...log].reverse().map(l => [l.chatId, l.name || l.phone]));
  return Object.entries(paused).filter(([, t]) => t > Date.now()).map(([id, t]) => `<div class="item"><div class="head">
    <span class="name">${esc(names[id] || id.split('@')[0])}</span>
    <time>till ${new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>
    <button class="btn ghost sm" data-resume="${esc(id)}"><i class="fa-solid fa-play"></i> Resume</button></div></div>`).join('')
    || empty('fa-regular fa-circle-check', 'Nothing paused', 'Chats that need you, or that you replied to yourself, show here.');
};

export const optoutHtml = (optout, log) => {
  const names = Object.fromEntries([...log].reverse().map(l => [l.chatId, l.name || l.phone]));
  return Object.entries(optout).map(([id, t]) => `<div class="item"><div class="head">
    <span class="name">${esc(names[id] || id.split('@')[0])}</span>
    <time>since ${new Date(t).toISOString().slice(0, 10)}</time>
    <button class="btn ghost sm" data-optin="${esc(id)}"><i class="fa-solid fa-rotate-left"></i> Allow again</button></div></div>`).join('')
    || empty('fa-regular fa-hand', 'Nobody opted out', 'People who send a stop word show here.');
};

// WhatsApp tab state: [dotClass, text]
export const connState = async () => {
  const [tab] = await chrome.tabs.query({ url: WA + '*' });
  tab && chrome.tabs.sendMessage(tab.id, { type: 'ping' }).catch(() => {});
  const { status: s } = await chrome.storage.local.get('status');
  const live = tab && s && Date.now() - s.at < 70000;
  return !tab ? ['bad', 'WhatsApp Web is not open'] : !live ? ['wait', 'Waiting for WhatsApp Web…'] : s.auth ? ['ok', 'WhatsApp connected'] : ['bad', 'Scan the QR code in WhatsApp Web'];
};

export const openWa = async () => {
  const [tab] = await chrome.tabs.query({ url: WA + '*' });
  tab ? (chrome.tabs.update(tab.id, { active: true }), chrome.windows.update(tab.windowId, { focused: true })) : chrome.tabs.create({ url: WA });
};

// WhatsApp *bold* _italic_ ~strike~ ```mono``` → html (escaped first)
export const waFormat = s => esc(s)
  .replace(/```([\s\S]+?)```/g, '<code>$1</code>')
  .replace(/\*([^*\n]+)\*/g, '<b>$1</b>')
  .replace(/(^|\W)_([^_\n]+)_(?=\W|$)/g, '$1<i>$2</i>')
  .replace(/~([^~\n]+)~/g, '<s>$1</s>');

// in-page confirm, resolves true / false
export const confirmBox = (title, msg, { ok = 'Delete', danger = true } = {}) => new Promise(res => {
  const d = $('askDlg'), yes = d.querySelector('[data-ans="1"]');
  d.querySelector('h2 span').textContent = title;
  $('askMsg').textContent = msg;
  yes.className = `btn${danger ? ' danger' : ''}`;
  yes.innerHTML = `<i class="fa-solid ${danger ? 'fa-trash' : 'fa-check'}"></i> <span>${esc(ok)}</span>`;
  d.onclick = e => { const b = e.target.closest('[data-ans]'); b && (d.close(), res(b.dataset.ans === '1')); };
  d.oncancel = () => res(false);
  d.showModal();
  yes.focus();
});

// one value from the user, or null when cancelled (never the native prompt)
export const promptBox = (title, label, { ok = 'Save', placeholder = '', value = '' } = {}) => new Promise(res => {
  const d = $('inDlg'), inp = $('inVal'), yes = d.querySelector('[data-ans="1"]');
  d.querySelector('h2 span').textContent = title;
  $('inLabel').textContent = label;
  inp.value = value; inp.placeholder = placeholder;
  yes.querySelector('span').textContent = ok;
  d.onclick = e => { const b = e.target.closest('[data-ans]'); b && (d.close(), res(b.dataset.ans === '1' ? inp.value.trim() : null)); };
  d.oncancel = () => res(null);
  $('inForm').onsubmit = e => { e.preventDefault(); d.close(); res(inp.value.trim()); };
  d.showModal();
  inp.focus();
});

// RFC 4180 csv
export const parseCSV = txt => {
  const rows = [[]];
  let f = '', q = false;
  txt = txt.replace(/^\ufeff/, '');
  for (let i = 0; i < txt.length; i++) {
    const c = txt[i];
    if (q) c === '"' ? (txt[i + 1] === '"' ? (f += '"', i++) : (q = false)) : (f += c);
    else if (c === '"') q = true;
    else if (c === ',') rows.at(-1).push(f), f = '';
    else if (c === '\n' || c === '\r') { c === '\r' && txt[i + 1] === '\n' && i++; rows.at(-1).push(f); f = ''; rows.push([]); }
    else f += c;
  }
  rows.at(-1).push(f);
  return rows.filter(r => r.some(x => x.trim()));
};
export const toCSV = rows => rows.map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
export const download = (name, text) => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type: 'text/csv;charset=utf-8' }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};
