/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// orders page: Tabulator list, status pipeline, bulk bar, detail popup
import { $, esc, bg, toast, busy, confirmBox, toCSV, download, waFormat, userCell } from './ui.js';
import { getCfg } from './cfg.js';

const ST = {
  new: ['New', 'c-new', 'fa-circle-dot'], confirmed: ['Confirmed', 'c-human', 'fa-circle-check'],
  done: ['Done', 'c-sent', 'fa-truck'], cancelled: ['Cancelled', 'c-error', 'fa-ban']
};
let rows = [], table = null, built = false, stage = 'all', curId = null;

const money = n => (+n || 0).toLocaleString('en-US');
const no = o => `ORD-${o.at.slice(0, 4)}-${String(o.no).padStart(3, '0')}`;
const when = iso => new Date(iso).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
const itemsLine = o => o.items.map(i => `${i.qty} x ${i.name}`).join(', ');
const pill = s => { const [l, c, i] = ST[s] || ST.new; return `<span class="pill ${c}"><i class="fa-solid ${i}"></i> ${l}</span>`; };
const fill = (tpl, o) => tpl.replace(/\{(\w+)\}/g, (m, k) => ({ no: no(o), items: o.items.map(i => `${i.qty} x ${i.name}${i.price ? ` (Rs ${money(i.qty * i.price)})` : ''}`).join('\n'),
  total: money(o.total), name: o.name, phone: o.phone, city: o.city, address: o.address }[k] ?? o.extra?.[k] ?? m));

// table
const build = () => {
  table = new Tabulator($('ordTable'), {
    data: rows,
    layout: 'fitColumns',
    responsiveLayout: 'collapse',
    placeholder: 'No orders yet. When the AI takes an order it shows up here.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true,
    selectableRows: 'highlight',
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'Order', field: 'no', sorter: 'number', minWidth: 130, formatter: c => { const o = c.getData(); return `<b class="mono tb-no">${esc(no(o))}</b>${o.type === 'lead' ? ' <span class="pill c-skip">Lead</span>' : ''}`; } },
      { title: 'Date', field: 'at', minWidth: 130, formatter: c => esc(when(c.getValue())) },
      { title: 'Customer', field: 'name', minWidth: 180, formatter: c => { const o = c.getData(); return userCell(o.name || o.chatName || '-', o.phone || ''); } },
      { title: 'City', field: 'city', minWidth: 100, formatter: c => esc(c.getValue() || '-') },
      { title: 'Items', field: 'itemsLine', minWidth: 180, formatter: c => `<span class="clip">${esc(c.getValue() || '-')}</span>` },
      { title: 'Total', field: 'total', sorter: 'number', hozAlign: 'right', minWidth: 100, formatter: c => `<b class="num tb-money">Rs ${money(c.getValue())}</b>` },
      { title: 'Status', field: 'status', minWidth: 120, formatter: c => pill(c.getValue()) },
      { title: 'Sheet', field: 'hook', hozAlign: 'center', width: 76, headerSort: false, formatter: c => { const h = c.getValue() || '';
        return h === 'sent' ? '<i class="fa-solid fa-circle-check ok-ic" title="Sent"></i>' : h ? `<i class="fa-solid fa-circle-exclamation bad-ic" title="${esc(h)}"></i>` : '<span class="sub">-</span>'; } },
      { title: '', field: 'id', headerSort: false, download: false, width: 96, hozAlign: 'right', formatter: c => `<button class="nav-btn ic-view" data-act="view" aria-label="Open order" title="Open"><i class="fa-solid fa-eye"></i></button>${c.getData().status === 'new' ? '<button class="nav-btn ic-go" data-act="notify" aria-label="Confirm and message" title="Confirm and message"><i class="fa-solid fa-paper-plane"></i></button>' : ''}`,
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && (b.dataset.act === 'view' ? openOrder(c.getData().id) : notify(c.getData().id, b)); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('ordSel').textContent = d.length;
    document.querySelectorAll('[data-bulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};

const applyFilter = () => {
  if (!built) return;
  const k = $('ordSearch').value.trim().toLowerCase();
  table.setFilter(d => (stage === 'all' || d.status === stage) && (!k || `${d.name} ${d.phone} ${d.city} ${d.address} ${d.itemsLine} ${no(d)}`.toLowerCase().includes(k)));
};

const pipe = () => {
  const n = s => s === 'all' ? rows.length : rows.filter(r => r.status === s).length;
  $('ordPipe').innerHTML = ['all', 'new', 'confirmed', 'done', 'cancelled'].map(s => `<button role="tab" aria-selected="${s === stage}" class="${s === stage ? 'active' : ''}" data-stage="${s}">
    ${s === 'all' ? '<i class="fa-solid fa-layer-group"></i> All' : `<i class="fa-solid ${ST[s][2]}"></i> ${ST[s][0]}`} <b>${n(s)}</b></button>`).join('');
};

const load = async () => {
  rows = ((await chrome.storage.local.get('orders')).orders || []).map(o => ({ ...o, itemsLine: itemsLine(o) }));
  const fresh = rows.filter(r => r.status === 'new').length;
  $('pillOrders').hidden = !fresh;
  $('pillOrders').textContent = fresh > 99 ? '99+' : fresh;
  $('ordCount').textContent = rows.length;
  pipe();
  built && (table.replaceData(rows), applyFilter());
  curId && $('ordDlg').open && openOrder(curId);
};

// detail popup
const card = (title, ic, body) => `<div class="ord-card"><h4><i class="fa-solid ${ic}"></i> ${title}</h4>${body}</div>`;
const kv = (k, v) => v ? `<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>` : '';
const openOrder = async id => {
  const o = rows.find(r => r.id === id);
  if (!o) return $('ordDlg').open && $('ordDlg').close();
  curId = id;
  const cfg = await getCfg(), late = Date.now() - new Date(o.at) > 864e5;
  $('ordTitle').innerHTML = `<i class="fa-solid fa-bag-shopping"></i> ${esc(no(o))} ${pill(o.status)}${o.type === 'lead' ? ' <span class="pill c-skip">Lead</span>' : ''}`;
  $('ordInfo').innerHTML = `<div class="ord-cards">
    ${card('Customer', 'fa-user', kv('Name', o.name) + kv('Phone', o.phone) + kv('WhatsApp name', o.chatName))}
    ${card('Delivery', 'fa-truck', (kv('City', o.city) + kv('Address', o.address)) || '<p class="sub">Not given</p>')}
    </div>
    ${card('Items', 'fa-list', o.items.length ? `<table class="ord-items"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead><tbody>
      ${o.items.map(i => `<tr><td>${esc(i.name)}</td><td class="num">${i.qty}</td><td class="num">${i.price ? money(i.price) : '-'}</td><td class="num">${i.price ? money(i.qty * i.price) : '-'}</td></tr>`).join('')}
      </tbody><tfoot><tr><td colspan="3">Total</td><td class="num">Rs ${money(o.total)}</td></tr></tfoot></table>` : '<p class="sub">No items, this is a lead</p>')}
    ${Object.keys(o.extra || {}).length || o.notes ? card('More details', 'fa-note-sticky', Object.entries(o.extra || {}).map(([k, v]) => kv(k.replace(/_/g, ' '), v)).join('') + kv('Notes', o.notes)) : ''}
    ${card('History', 'fa-clock-rotate-left', kv('Taken', when(o.at)) + kv('Updated', o.upd && when(o.upd)) + kv('Customer messaged', o.notified && when(o.notified)) + kv('Sent to sheet', o.hook || (cfg.orderHook ? 'Not yet' : 'No URL set')))}`;
  $('ordSide').innerHTML = `<h3><i class="fa-brands fa-whatsapp"></i> Confirm and message</h3>
    <div class="wa-phone"><div class="bubble out">${waFormat(fill(cfg.orderMsg, o))}</div></div>
    ${late ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> More than 24 hours have passed. Message this customer yourself from WhatsApp.</p>' : ''}
    <div class="ord-acts">
      <button class="btn" data-o="notify" ${late || o.status !== 'new' ? 'disabled' : ''}><i class="fa-solid fa-paper-plane"></i> Confirm and message</button>
      <button class="btn ghost" data-o="confirmed" ${o.status === 'confirmed' ? 'disabled' : ''}><i class="fa-solid fa-circle-check"></i> Mark confirmed (no message)</button>
      <button class="btn ghost" data-o="done" ${o.status === 'done' ? 'disabled' : ''}><i class="fa-solid fa-truck"></i> Mark done</button>
      <button class="btn ghost" data-o="chat"><i class="fa-brands fa-whatsapp"></i> Open chat</button>
      <button class="btn ghost" data-o="push" ${cfg.orderHook ? '' : 'disabled title="Add a URL in Orders setup"'}><i class="fa-solid fa-table"></i> Send to sheet again</button>
      <button class="btn ghost" data-o="cancelled" ${o.status === 'cancelled' ? 'disabled' : ''}><i class="fa-solid fa-ban"></i> Cancel order</button>
      <button class="btn ghost del" data-o="delete"><i class="fa-solid fa-trash"></i> Delete</button>
    </div>`;
  $('ordDlg').open || $('ordDlg').showModal();
};

const notify = async (id, btn) => {
  busy(btn, true);
  const r = await bg({ type: 'orderNotify', id });
  busy(btn, false);
  r.ok ? toast('Order confirmed and the customer got the message') : toast(r.err, true);
};
const setStatus = async (ids, status) => {
  const r = await bg({ type: 'orderSet', ids, status });
  r.ok ? toast(`${ids.length > 1 ? `${ids.length} orders` : 'Order'} marked ${ST[status][0].toLowerCase()}`) : toast(r.err, true);
};
const remove = async ids => {
  if (!(await confirmBox(`Delete ${ids.length > 1 ? `${ids.length} orders` : 'this order'}?`, 'It is removed from this list. A copy already sent to your sheet stays there.'))) return false;
  const r = await bg({ type: 'orderDel', ids });
  r.ok ? toast('Deleted') : toast(r.err, true);
  return r.ok;
};

$('ordSide').addEventListener('click', async e => {
  const b = e.target.closest('[data-o]');
  if (!b || !curId) return;
  const a = b.dataset.o;
  if (a === 'notify') return notify(curId, b);
  if (a === 'chat') { await bg({ type: 'openChat', chatId: rows.find(r => r.id === curId)?.chatId }); return; }
  if (a === 'push') { busy(b, true); const r = await bg({ type: 'orderPush', id: curId }); busy(b, false); return r.ok ? toast('Sent to your sheet') : toast(r.err, true); }
  if (a === 'delete') return (await remove([curId])) && $('ordDlg').close();
  busy(b, true);
  await setStatus([curId], a);
});
$('ordDlg').addEventListener('click', e => e.target.closest('[data-close]') && $('ordDlg').close());
$('ordDlg').addEventListener('close', () => { curId = null; });

// pipeline, search, bulk, csv
$('ordPipe').addEventListener('click', e => { const b = e.target.closest('[data-stage]'); b && (stage = b.dataset.stage, pipe(), applyFilter()); });
$('ordSearch').oninput = applyFilter;
document.querySelectorAll('[data-bulk]').forEach(b => b.onclick = async () => {
  const ids = table.getSelectedData().map(d => d.id);
  if (!ids.length) return;
  b.dataset.bulk === 'delete' ? await remove(ids) : await setStatus(ids, b.dataset.bulk);
  table.deselectRow();
});
$('ordCsv').onclick = () => {
  const list = built ? table.getData('active') : rows;
  if (!list.length) return toast('No orders to export', true);
  download('orders.csv', toCSV([['Order', 'Date', 'Type', 'Status', 'Name', 'Phone', 'City', 'Address', 'Items', 'Total', 'Notes'],
    ...list.map(o => [no(o), o.at, o.type, o.status, o.name, o.phone, o.city, o.address, itemsLine(o), o.total, o.notes])]));
};

// Google Sheets receiver for "Send orders to"
$('gsCode').textContent = `/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// orders -> "Orders" sheet, bookings -> "Bookings" sheet
function doPost(e) {
  const o = JSON.parse(e.postData.contents);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (o.kind === 'booking') {
    const bs = ss.getSheetByName('Bookings') || ss.insertSheet('Bookings');
    if (bs.getLastRow() === 0) bs.appendRow(['Booking', 'Date', 'Time', 'Name', 'Phone', 'Service', 'Notes', 'Booked at', 'WhatsApp']);
    bs.appendRow([o.no, o.date, o.time, o.name, o.phone, o.service, o.notes, o.at, o.chatName]);
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  }
  const sh = ss.getSheetByName('Orders') || ss.insertSheet('Orders');
  if (sh.getLastRow() === 0) sh.appendRow(['Order', 'Date', 'Type', 'Name', 'Phone', 'City', 'Address', 'Items', 'Total', 'Notes', 'WhatsApp']);
  sh.appendRow([o.no, o.at, o.type, o.name, o.phone, o.city, o.address, o.itemsText, o.total, o.notes, o.chatName]);
  return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
}`;
$('gsCopy').onclick = async () => {
  try { await navigator.clipboard.writeText($('gsCode').textContent); toast('Code copied. Paste it in Apps Script.'); }
  catch { $('gsCode').hidden = false; toast('Select the code below and copy it by hand', true); }
};
$('gsShow').onclick = e => {
  const show = $('gsCode').hidden;
  $('gsCode').hidden = !show;
  e.currentTarget.setAttribute('aria-expanded', show);
  e.currentTarget.innerHTML = `<i class="fa-solid fa-code"></i> ${show ? 'Hide' : 'Show'} the code`;
};

// connection state: saved URL + last good test for that URL
const gsWorks = url => { try { return !!url && localStorage.getItem('waai_gs_ok') === url; } catch { return false; } };
const gsState = async () => {
  const url = (await getCfg()).orderHook.trim();
  $('gsState').innerHTML = gsWorks(url) ? '<span class="pill dot-l c-sent">Working</span>' : url ? '<span class="pill dot-l c-new">URL saved, not tested</span>' : '<span class="pill dot-l c-skip">Not connected</span>';
};
$('gsTest').onclick = async e => {
  const btn = e.currentTarget, msg = $('gsMsg');
  if (!$('orderHook').value.trim()) { $('orderHook').focus(); return toast('Paste the Web app URL first', true); }
  if ($('saveBar').classList.contains('show')) { // save the URL first (Chrome asks for access), wait until it is stored
    $('saveBtn').click();
    const want = $('orderHook').value.trim();
    for (let i = 0; i < 20 && (await getCfg()).orderHook.trim() !== want; i++) await new Promise(r => setTimeout(r, 250));
    if ((await getCfg()).orderHook.trim() !== want) return toast('Save did not finish. Fix the marked field, then try again.', true);
  }
  busy(btn, true);
  msg.className = 'gs-msg';
  msg.textContent = 'Sending a test order…';
  const r = await bg({ type: 'orderHookTest' });
  busy(btn, false);
  const url = (await getCfg()).orderHook.trim();
  try { r.ok ? localStorage.setItem('waai_gs_ok', url) : localStorage.removeItem('waai_gs_ok'); } catch {}
  msg.className = `gs-msg ${r.ok ? 'ok' : 'bad'}`;
  msg.innerHTML = r.ok ? '<i class="fa-solid fa-circle-check"></i> It works. Open your sheet: a row for "Test Customer" is in the Orders tab.'
    : `<i class="fa-solid fa-circle-exclamation"></i> ${esc(r.err)}`;
  gsState();
};
chrome.storage.onChanged.addListener(c => c.cfg && gsState());
gsState();

// build the first time the page is shown, Tabulator needs a visible box
addEventListener('waai:view', e => {
  if (e.detail !== 'orders') return;
  table ? built && table.redraw(true) : build();
});
chrome.storage.onChanged.addListener(c => c.orders && load());
load();
