/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// searchable model dropdown per engine
import { $, esc, bg, toast, busy } from './ui.js';
import { NEEDS } from './cfg.js';

// id, label, note
const KNOWN = {
  claude: [['claude-opus-5-5', 'Claude Opus 5.5', 'Best answers'], ['claude-sonnet-5-5', 'Claude Sonnet 5.5', 'Fast and smart'],
    ['claude-haiku-5-5', 'Claude Haiku 5.5', 'Cheapest and fastest'], ['claude-fable-5-1', 'Claude Fable 5.1', 'Most capable, highest cost']],
  openai: [['gpt-4.1-mini', 'GPT-4.1 mini', 'Fast and cheap'], ['gpt-4.1', 'GPT-4.1', 'Stronger'], ['gpt-5-mini', 'GPT-5 mini', 'Thinks first, slower'], ['gpt-5', 'GPT-5', 'Thinks first, slowest']],
  gemini: [['gemini-3.6-flash', 'Gemini 3.6 Flash', 'Fast'], ['gemini-3.5-flash-lite', 'Gemini 3.5 Flash-Lite', 'Cheapest']],
  grok: [['grok-4.3', 'Grok 4.3', '']]
};
const FIELD = { claude: 'claudeModel', openai: 'openaiModel', gemini: 'geminiModel', grok: 'grokModel' };
let live = {}; // loaded from the account
const dds = {};

const options = eng => {
  const notes = Object.fromEntries(KNOWN[eng].map(([id, , n]) => [id, n]));
  const base = live[eng]?.length ? live[eng].map(m => [m.id, m.name, notes[m.id] || '']) : KNOWN[eng];
  return base.map(([id, label, note]) => ({ id, label, note }));
};

const sdInit = (host, eng) => {
  const hidden = $(FIELD[eng]);
  let open = false, hi = -1, shown = [];
  host.classList.add('searchable-dropdown');
  host.innerHTML = `<button type="button" class="sd-trigger" aria-haspopup="listbox" aria-expanded="false"><span class="sd-label"></span><i class="fa-solid fa-chevron-down sd-arrow"></i></button>
    <div class="sd-panel" hidden><input class="sd-search" type="text" placeholder="Search or type a model name" aria-label="Search models" spellcheck="false"><div class="sd-list" role="listbox"></div></div>`;
  const trig = host.querySelector('.sd-trigger'), panel = host.querySelector('.sd-panel'), search = host.querySelector('.sd-search'),
    list = host.querySelector('.sd-list'), label = host.querySelector('.sd-label'), arrow = host.querySelector('.sd-arrow');

  const paint = () => {
    const v = hidden.value, o = options(eng).find(x => x.id === v);
    label.innerHTML = v ? `${esc(o?.label || v)}${o && o.label !== v ? ` <small>${esc(v)}</small>` : ''}` : 'Choose a model';
    label.classList.toggle('sd-placeholder', !v);
  };
  const draw = () => {
    const k = search.value.trim().toLowerCase(), all = options(eng);
    shown = all.filter(o => `${o.id} ${o.label}`.toLowerCase().includes(k));
    k && !all.some(o => o.id === k) && shown.push({ id: search.value.trim(), label: `Use "${search.value.trim()}"`, note: 'Model name typed by you', custom: true });
    hi = Math.min(Math.max(hi, 0), shown.length - 1);
    list.innerHTML = shown.map((o, i) => { const sel = o.id === hidden.value; return `<div class="sd-item${sel ? ' selected' : ''}${i === hi ? ' hi' : ''}" role="option" data-i="${i}" aria-selected="${sel}">
      <span class="sd-main"><b>${esc(o.label)}</b>${!o.custom && o.label !== o.id ? `<small>${esc(o.id)}</small>` : ''}</span>
      ${o.note ? `<em>${esc(o.note)}</em>` : ''}<i class="fa-solid fa-check sd-check"></i></div>`; }).join('')
      || '<div class="sd-empty">No models</div>';
    list.querySelector('.hi')?.scrollIntoView({ block: 'nearest' });
  };
  const toggle = s => {
    open = s ?? !open;
    panel.hidden = !open;
    host.classList.toggle('open', open);
    arrow.classList.toggle('open', open);
    trig.setAttribute('aria-expanded', open);
    if (open) { search.value = ''; hi = Math.max(0, options(eng).findIndex(o => o.id === hidden.value)); draw(); search.focus(); }
  };
  const pick = i => {
    const o = shown[i];
    if (!o) return;
    hidden.value = o.id;
    hidden.dispatchEvent(new Event('input', { bubbles: true })); // marks the form changed
    paint();
    toggle(false);
    trig.focus();
  };
  trig.addEventListener('click', () => toggle());
  search.addEventListener('input', () => { hi = 0; draw(); });
  search.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); hi = (hi + (e.key === 'ArrowDown' ? 1 : -1) + shown.length) % (shown.length || 1); draw(); }
    else if (e.key === 'Enter') { e.preventDefault(); pick(hi); }
    else if (e.key === 'Escape') { e.stopPropagation(); toggle(false); trig.focus(); }
  });
  list.addEventListener('click', e => { const it = e.target.closest('.sd-item'); it && pick(+it.dataset.i); });
  document.addEventListener('click', e => open && !host.contains(e.target) && toggle(false)); // outside click
  paint();
  return { paint, draw: () => open && draw() };
};

export const syncModels = () => Object.values(dds).forEach(d => d.paint());

document.querySelectorAll('[data-models]').forEach(h => dds[h.dataset.models] = sdInit(h, h.dataset.models));

// load the real list with the key in the form (saved or not)
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-load-models]');
  if (!b) return;
  const eng = b.dataset.loadModels;
  busy(b, true);
  try {
    const r = await bg({ type: 'models', engine: eng, key: $(NEEDS[eng]).value });
    if (!r.ok) return toast(r.err, true);
    live[eng] = r.list;
    syncModels();
    toast(`${r.list.length} models loaded from your account`);
    dds[eng].draw();
  } finally { busy(b, false); }
});

chrome.storage.local.get('models').then(r => { live = r.models || {}; syncModels(); });
