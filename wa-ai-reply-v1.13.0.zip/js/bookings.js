/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// bookings page: Tabulator list, pipeline, bulk bar, 360 popup, add/edit form, setup page free-time preview
import { $, esc, bg, toast, busy, confirmBox, toCSV, download, waFormat, userCell } from './ui.js';
import { getCfg, demoSeq } from './cfg.js';

const ST = {
  booked: ['Booked', 'c-human', 'fa-calendar-check'], done: ['Done', 'c-sent', 'fa-circle-check'],
  noshow: ['No-show', 'c-new', 'fa-user-slash'], cancelled: ['Cancelled', 'c-error', 'fa-ban']
};
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];
let rows = [], table = null, built = false, stage = 'today', curId = null, editId = null;

const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const no = b => `BK-${b.at.slice(0, 4)}-${String(b.no).padStart(3, '0')}`;
const dayOf = key => { const [y, m, d] = String(key).split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDay = key => /^\d{4}-\d{2}-\d{2}$/.test(key) ? dayOf(key).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }) : '';
const fmtTime = t => { const m = String(t || '').match(/^(\d{1,2}):(\d{2})/); if (!m) return ''; const n = +m[1] * 60 + +m[2], h = Math.floor(n / 60) % 12 || 12; return `${h}:${m[2]} ${n < 720 ? 'am' : 'pm'}`; };
const whenWord = key => { const diff = Math.round((dayOf(key) - dayOf(todayKey())) / 864e5); return diff === 0 ? 'today' : diff === 1 ? 'tomorrow' : `on ${fmtDay(key)}`; };
const when = iso => new Date(iso).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
const pill = s => { const [l, c, i] = ST[s] || ST.booked; return `<span class="pill ${c}"><i class="fa-solid ${i}"></i> ${l}</span>`; };
const fill = (tpl, b, cfg) => tpl.replace(/\{(\w+)\}/g, (m, k) => ({ no: b.at ? no(b) : 'BK-…', date: fmtDay(b.date), time: fmtTime(b.time), when: b.date ? whenWord(b.date) : '', service: b.service || '',
  name: b.name || '', phone: b.phone || '', what: cfg.bookWhat.trim() || 'appointment', notes: b.notes || '' }[k] ?? b.extra?.[k] ?? m)).replace(/\n{2,}/g, '\n').trim();
const inStage = (b, s) => {
  const t = todayKey();
  return s === 'all' ? true : s === 'today' ? b.date === t && b.status === 'booked' : s === 'upcoming' ? b.date > t && b.status === 'booked'
    : s === 'past' ? b.status === 'booked' && b.date < t : b.status === s;
};

// table
const build = () => {
  table = new Tabulator($('bookTable'), {
    data: rows,
    layout: 'fitColumns',
    responsiveLayout: 'collapse',
    placeholder: 'No bookings yet. When the AI books one, or you add one, it shows up here.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true,
    selectableRows: 'highlight',
    initialSort: [{ column: 'sortKey', dir: 'asc' }],
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'Booking', field: 'no', sorter: 'number', minWidth: 120, formatter: c => `<b class="mono tb-no">${esc(no(c.getData()))}</b>` },
      { title: 'When', field: 'sortKey', minWidth: 170, formatter: c => { const b = c.getData(); return `<b>${esc(fmtDay(b.date))}</b><small class="sub">${esc(fmtTime(b.time))}${b.date === todayKey() ? ' · today' : ''}</small>`; } },
      { title: 'Customer', field: 'name', minWidth: 180, formatter: c => { const b = c.getData(); return userCell(b.name || b.chatName || '-', b.phone || ''); } },
      { title: 'Service', field: 'service', minWidth: 140, formatter: c => c.getValue() ? `<span class="tb-pill role">${esc(c.getValue())}</span>` : '<span class="sub">-</span>' },
      { title: 'Status', field: 'status', minWidth: 120, formatter: c => pill(c.getValue()) },
      { title: 'Reminder', field: 'remind', hozAlign: 'center', width: 96, headerSort: false, formatter: c => c.getValue() ? '<i class="fa-solid fa-bell ok-ic" title="Reminder sent"></i>' : '<span class="sub">-</span>' },
      { title: 'Sheet', field: 'hook', hozAlign: 'center', width: 76, headerSort: false, formatter: c => { const h = c.getValue() || '';
        return h === 'sent' ? '<i class="fa-solid fa-circle-check ok-ic" title="Sent"></i>' : h ? `<i class="fa-solid fa-circle-exclamation bad-ic" title="${esc(h)}"></i>` : '<span class="sub">-</span>'; } },
      { title: '', field: 'id', headerSort: false, download: false, width: 96, hozAlign: 'right', formatter: c => `<button class="nav-btn ic-view" data-act="view" aria-label="Open booking" title="Open"><i class="fa-solid fa-eye"></i></button>${c.getData().status === 'booked' ? '<button class="nav-btn ic-go" data-act="done" aria-label="Mark done" title="Mark done"><i class="fa-solid fa-circle-check"></i></button>' : ''}`,
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && (b.dataset.act === 'view' ? openBooking(c.getData().id) : setStatus([c.getData().id], 'done')); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('bookSel').textContent = d.length;
    document.querySelectorAll('[data-bbulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};
const applyFilter = () => {
  if (!built) return;
  const k = $('bookSearch').value.trim().toLowerCase();
  table.setFilter(d => inStage(d, stage) && (!k || `${d.name} ${d.phone} ${d.service} ${d.notes} ${no(d)}`.toLowerCase().includes(k)));
};
const pipe = () => {
  const n = s => rows.filter(r => inStage(r, s)).length;
  const L = { today: ['Today', 'fa-sun'], upcoming: ['Upcoming', 'fa-calendar-day'], past: ['Not marked', 'fa-hourglass-end'], done: ['Done', 'fa-circle-check'], cancelled: ['Cancelled', 'fa-ban'], all: ['All', 'fa-layer-group'] };
  $('bookPipe').innerHTML = Object.entries(L).map(([s, [l, i]]) => `<button role="tab" aria-selected="${s === stage}" class="${s === stage ? 'active' : ''}" data-stage="${s}"><i class="fa-solid ${i}"></i> ${l} <b>${n(s)}</b></button>`).join('');
};
const load = async () => {
  const cfg = await getCfg();
  rows = ((await chrome.storage.local.get('bookings')).bookings || []).map(b => ({ ...b, sortKey: `${b.date} ${b.time}` }));
  const todayN = rows.filter(r => inStage(r, 'today')).length;
  $('pillBook').hidden = !todayN;
  $('pillBook').textContent = todayN > 99 ? '99+' : todayN;
  $('bookCount').textContent = rows.length;
  $('bookOff').hidden = !!cfg.bookOn;
  pipe();
  built && (table.replaceData(rows), applyFilter());
  curId && $('bookDlg').open && openBooking(curId);
};

// 360 popup
const card = (title, ic, body) => `<div class="ord-card"><h4><i class="fa-solid ${ic}"></i> ${title}</h4>${body}</div>`;
const kv = (k, v) => v ? `<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>` : '';
const openBooking = async id => {
  const b = rows.find(r => r.id === id);
  if (!b) return $('bookDlg').open && $('bookDlg').close();
  curId = id;
  const cfg = await getCfg(), late = Date.now() - new Date(b.at) > 864e5, chat = /@(c\.us|lid)$/.test(b.chatId || '');
  $('bookTitle').innerHTML = `<i class="fa-solid fa-calendar-check"></i> ${esc(no(b))} ${pill(b.status)}`;
  $('bookInfo').innerHTML = `<div class="ord-cards">
    ${card('When', 'fa-clock', kv('Day', fmtDay(b.date)) + kv('Time', fmtTime(b.time)) + kv('Service', b.service))}
    ${card('Customer', 'fa-user', kv('Name', b.name) + kv('Phone', b.phone) + kv('WhatsApp name', b.chatName))}
    </div>
    ${Object.keys(b.extra || {}).length || b.notes ? card('More details', 'fa-note-sticky', Object.entries(b.extra || {}).map(([k, v]) => kv(k.replace(/_/g, ' '), v)).join('') + kv('Notes', b.notes)) : ''}
    ${card('History', 'fa-clock-rotate-left', kv('Booked', when(b.at)) + kv('Updated', b.upd && when(b.upd)) + kv('Confirmation sent', b.notified && when(b.notified)) + kv('Reminder sent', b.remind && when(b.remind)) + kv('Sent to sheet', b.hook || (cfg.orderHook ? 'Not yet' : 'No URL set')))}`;
  $('bookSide').innerHTML = `<h3><i class="fa-brands fa-whatsapp"></i> Confirmation message</h3>
    <div class="wa-phone"><div class="bubble out">${waFormat(fill(cfg.bookMsg, b, cfg))}</div></div>
    ${!chat ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> No WhatsApp chat on this booking. Message the customer yourself.</p>' : late ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> More than 24 hours since it was booked. Message this customer yourself from WhatsApp.</p>' : ''}
    <div class="ord-acts">
      <button class="btn" data-b="notify" ${late || !chat || b.notified || b.status !== 'booked' ? 'disabled' : ''}><i class="fa-solid fa-paper-plane"></i> Send confirmation</button>
      <button class="btn ghost" data-b="remind" ${!chat || b.status !== 'booked' ? 'disabled' : ''}><i class="fa-solid fa-bell"></i> Send reminder now</button>
      <button class="btn ghost" data-b="edit"><i class="fa-solid fa-pen"></i> Edit</button>
      <button class="btn ghost" data-b="done" ${b.status === 'done' ? 'disabled' : ''}><i class="fa-solid fa-circle-check"></i> Mark done</button>
      <button class="btn ghost" data-b="noshow" ${b.status === 'noshow' ? 'disabled' : ''}><i class="fa-solid fa-user-slash"></i> Mark no-show</button>
      <button class="btn ghost" data-b="chat" ${chat ? '' : 'disabled'}><i class="fa-brands fa-whatsapp"></i> Open chat</button>
      <button class="btn ghost" data-b="push" ${cfg.orderHook ? '' : 'disabled title="Add a URL in Orders › Google Sheets"'}><i class="fa-solid fa-table"></i> Send to sheet again</button>
      <button class="btn ghost" data-b="cancelled" ${b.status === 'cancelled' ? 'disabled' : ''}><i class="fa-solid fa-ban"></i> Cancel booking</button>
      <button class="btn ghost del" data-b="delete"><i class="fa-solid fa-trash"></i> Delete</button>
    </div>`;
  $('bookDlg').open || $('bookDlg').showModal();
};
const setStatus = async (ids, status) => {
  const r = await bg({ type: 'bookSet', ids, status });
  r.ok ? toast(`${ids.length > 1 ? `${ids.length} bookings` : 'Booking'} marked ${ST[status][0].toLowerCase()}`) : toast(r.err, true);
};
const remove = async ids => {
  if (!(await confirmBox(`Delete ${ids.length > 1 ? `${ids.length} bookings` : 'this booking'}?`, 'It is removed from this list and its time becomes free again. A copy already sent to your sheet stays there.'))) return false;
  const r = await bg({ type: 'bookDel', ids });
  r.ok ? toast('Deleted') : toast(r.err, true);
  return r.ok;
};
$('bookSide').addEventListener('click', async e => {
  const btn = e.target.closest('[data-b]');
  if (!btn || !curId) return;
  const a = btn.dataset.b, b = rows.find(r => r.id === curId);
  if (a === 'notify' || a === 'remind') { busy(btn, true); const r = await bg({ type: 'bookNotify', id: curId, kind: a }); busy(btn, false); return r.ok ? toast(a === 'remind' ? 'Reminder sent' : 'Confirmation sent') : toast(r.err, true); }
  if (a === 'chat') return void bg({ type: 'openChat', chatId: b?.chatId });
  if (a === 'push') { busy(btn, true); const r = await bg({ type: 'bookPush', id: curId }); busy(btn, false); return r.ok ? toast('Sent to your sheet') : toast(r.err, true); }
  if (a === 'edit') return openForm(b);
  if (a === 'delete') return (await remove([curId])) && $('bookDlg').close();
  busy(btn, true);
  await setStatus([curId], a);
});
$('bookDlg').addEventListener('click', e => e.target.closest('[data-close]') && $('bookDlg').close());
$('bookDlg').addEventListener('close', () => { curId = null; });

// add / edit form: form LEFT, the booking + its message RIGHT
const f = $('bookForm'), fdlg = $('bookFormDlg');
const pane = p => {
  fdlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  fdlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const formRow = () => ({ at: new Date().toISOString(), no: 0, date: f.date.value, time: f.time.value, name: f.name.value.trim(), phone: f.phone.value.replace(/\D/g, ''), service: f.service.value.trim(), notes: f.notes.value.trim() });
const preview = async () => {
  const cfg = await getCfg(), b = formRow();
  $('bkPreview').innerHTML = card('Booking', 'fa-calendar-check', (kv('Day', fmtDay(b.date)) + kv('Time', fmtTime(b.time)) + kv('Service', b.service) + kv('Name', b.name) + kv('Phone', b.phone) + kv('Notes', b.notes)) || '<p class="sub">Fill the form</p>')
    + `<p class="sub need">${[!b.date && 'date', !b.time && 'time', !b.name && 'name'].filter(Boolean).map(x => `Still needed: ${x}`).join(' · ') || 'Ready to save'}</p>`;
  $('bkMsgPrev').innerHTML = waFormat(fill(cfg.bookMsg, b, cfg));
};
const slotsFor = async () => { // free times of the picked day as buttons; any other time can still be typed
  const date = f.date.value, box = $('bkSlots');
  if (!date) return void (box.innerHTML = '');
  const r = await bg({ type: 'bookFree', days: 90 }), day = (r.free || []).find(x => x.date === date);
  const times = (day?.times || []).filter(t => editId ? true : t);
  box.innerHTML = times.length ? times.map(t => `<button type="button" class="slot${f.time.value === t ? ' on' : ''}" data-t="${t}">${esc(fmtTime(t))}</button>`).join('') : '<span class="sub">No free times that day. You can still type a time.</span>';
};
$('bkSlots').addEventListener('click', e => { const b = e.target.closest('[data-t]'); if (!b) return; f.time.value = b.dataset.t; slotsFor(); preview(); });
const openForm = b => {
  editId = b?.id || null;
  $('bookFormTitle').innerHTML = `<i class="fa-solid ${editId ? 'fa-pen' : 'fa-calendar-plus'}"></i> ${editId ? `Edit ${esc(no(b))}` : 'Add booking'}`;
  f.date.value = b?.date || ''; f.time.value = b?.time || ''; f.name.value = b?.name || ''; f.phone.value = b?.phone || ''; f.service.value = b?.service || ''; f.notes.value = b?.notes || '';
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  pane('form'); slotsFor(); preview();
  $('bookDlg').open && $('bookDlg').close();
  fdlg.showModal();
  setTimeout(() => f.date.focus(), 50);
};
fdlg.addEventListener('click', e => { e.target.closest('[data-close]') && fdlg.close(); const t = e.target.closest('[data-pane]'); t && pane(t.dataset.pane); });
f.addEventListener('input', e => { e.target === f.date && slotsFor(); preview(); });
f.onsubmit = async e => {
  e.preventDefault();
  const b = formRow(), bad = !b.date ? f.date : !b.time ? f.time : !b.name ? f.name : null;
  if (bad) { bad.classList.add('bad'); bad.focus(); return toast(`Add the ${bad.name}`, true); }
  const btn = $('bookSave');
  busy(btn, true);
  try {
    const r = await bg({ type: 'bookPut', id: editId, ...b });
    if (!r.ok) return toast(r.err, true);
    fdlg.close();
    toast(editId ? 'Booking updated' : r.dup ? 'That customer already has this time' : 'Booking added');
  } finally { busy(btn, false); }
};
$('bookDemo').onclick = () => { // demo set #n for testing
  const n = demoSeq('book'), d = new Date(); d.setDate(d.getDate() + 1 + (n % 5));
  const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  f.date.value = key; f.time.value = `${String(10 + (n % 7)).padStart(2, '0')}:${n % 2 ? '30' : '00'}`;
  f.name.value = `Client ${n}`; f.phone.value = String(923001000000 + n); f.service.value = ['Haircut', 'Check-up', 'Consultation', 'Facial', 'Viewing'][n % 5]; f.notes.value = '';
  slotsFor(); preview();
};
$('bookAdd').onclick = () => openForm(null);

// pipeline, search, bulk, csv
$('bookPipe').addEventListener('click', e => { const b = e.target.closest('[data-stage]'); b && (stage = b.dataset.stage, pipe(), applyFilter()); });
$('bookSearch').oninput = applyFilter;
document.querySelectorAll('[data-bbulk]').forEach(b => b.onclick = async () => {
  const ids = table.getSelectedData().map(d => d.id);
  if (!ids.length) return;
  b.dataset.bbulk === 'delete' ? await remove(ids) : await setStatus(ids, b.dataset.bbulk);
  table.deselectRow();
});
$('bookCsv').onclick = () => {
  const list = built ? table.getData('active') : rows;
  if (!list.length) return toast('No bookings to export', true);
  download('bookings.csv', toCSV([['Booking', 'Date', 'Time', 'Status', 'Name', 'Phone', 'Service', 'Notes', 'Booked at', 'WhatsApp'],
    ...list.map(b => [no(b), b.date, b.time, b.status, b.name, b.phone, b.service, b.notes, b.at, b.chatName])]));
};

// setup page: day chips write the hidden field; free-time preview from the saved settings
const chips = () => {
  const on = new Set($('bookDays').value.split(',').map(s => s.trim()));
  $('bookDayChips').innerHTML = DAYS.map(([k, l]) => `<button type="button" class="chip${on.has(k) ? ' on' : ''}" data-day="${k}" aria-pressed="${on.has(k)}">${l}</button>`).join('');
};
$('bookDayChips').addEventListener('click', e => {
  const b = e.target.closest('[data-day]');
  if (!b) return;
  const on = new Set($('bookDays').value.split(',').map(s => s.trim()).filter(Boolean));
  on.has(b.dataset.day) ? on.delete(b.dataset.day) : on.add(b.dataset.day);
  $('bookDays').value = DAYS.map(([k]) => k).filter(k => on.has(k)).join(',');
  $('bookDays').dispatchEvent(new Event('input', { bubbles: true })); // the settings page sees the change
  chips();
});
const freeList = async () => {
  const r = await bg({ type: 'bookFree', days: 7 });
  $('bookFreeList').innerHTML = (r.free || []).length ? r.free.map(x => `<div class="slot-day"><b>${esc(fmtDay(x.date))}</b><span>${x.times.slice(0, 12).map(t => esc(fmtTime(t))).join(' · ')}${x.times.length > 12 ? ` · +${x.times.length - 12}` : ''}</span></div>`).join('')
    : '<span class="sub">No free times in the next 7 days with these settings.</span>';
};
addEventListener('waai:saved', () => { chips(); freeList(); });
addEventListener('waai:view', e => {
  if (e.detail === 'bookset') { chips(); freeList(); }
  if (e.detail !== 'bookings') return;
  table ? built && table.redraw(true) : build();
});
chrome.storage.onChanged.addListener(c => { c.bookings && load(); c.cfg && (load(), freeList()); });
load();
chips();
