/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// screening: list (Tabulator, status tabs, KPIs, bulk, csv, row actions), add / edit form, setup page + live preview
import { $, esc, bg, toast, busy, confirmBox, toCSV, download, waFormat, userCell } from './ui.js';
import { getCfg, demoSeq, screenNo as no, fillScreen } from './cfg.js';
import { list, paintPicks, paintTags, extraTags } from './setup.js';
import { openMsg } from './msg.js';

const ST = {
  new: ['New', 'c-new', 'fa-star'], qualified: ['Qualified', 'c-sent', 'fa-circle-check'],
  contacted: ['Contacted', 'c-human', 'fa-comment-dots'], nofit: ['Not a fit', 'c-skip', 'fa-ban']
};
let rows = [], table = null, built = false, stage = 'all', editId = null;

const when = iso => iso ? new Date(iso).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
const pill = s => { const [l, c, i] = ST[s] || ST.new; return `<span class="pill ${c}"><i class="fa-solid ${i}"></i> ${l}</span>`; };
const label = k => k.replace(/_/g, ' ');
const details = x => Object.entries(x.fields || {}).filter(([k]) => k !== 'name' && k !== 'phone').map(([k, v]) => `${label(k)}: ${v}`).join(' · ');
const keysOf = cfg => list(cfg.screenFields).map(f => f.toLowerCase().replace(/\W+/g, '_')).filter(k => k !== 'name' && k !== 'phone');

// table
const ACT_ICONS = '<button class="nav-btn ic-edit" data-act="edit" aria-label="Edit" title="Edit"><i class="fa-solid fa-pen"></i></button>'
  + '<button class="nav-btn ic-msg" data-act="msg" aria-label="Send a message" title="Send a message"><i class="fa-brands fa-whatsapp"></i></button>'
  + '<button class="nav-btn ic-go" data-act="chat" aria-label="Open chat" title="Open chat"><i class="fa-solid fa-comments"></i></button>'
  + '<button class="nav-btn ic-del" data-act="del" aria-label="Delete" title="Delete"><i class="fa-solid fa-trash"></i></button>';
const build = () => {
  table = new Tabulator($('scrTable'), {
    data: rows,
    layout: 'fitColumns',
    responsiveLayout: 'collapse',
    placeholder: 'Nobody screened yet. Turn Screening on and the AI fills this list from your chats.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true,
    selectableRows: 'highlight',
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'No', field: 'no', sorter: 'number', minWidth: 120, formatter: c => `<b class="mono tb-no">${esc(no(c.getData()))}</b>` },
      { title: 'Customer', field: 'name', minWidth: 180, formatter: c => { const x = c.getData(); return userCell(x.name || x.chatName || '-', x.phone || ''); } },
      { title: 'Details', field: 'detailLine', minWidth: 220, formatter: c => `<span class="clip">${esc(c.getValue() || '-')}</span>` },
      { title: 'What they want', field: 'summary', minWidth: 180, formatter: c => `<span class="clip">${esc(c.getValue() || '-')}</span>` },
      { title: 'Status', field: 'status', minWidth: 120, formatter: c => pill(c.getValue()) },
      { title: 'Updated', field: 'sortAt', minWidth: 130, formatter: c => esc(when(c.getValue())) },
      { title: 'Actions', field: 'id', headerSort: false, download: false, width: 168, hozAlign: 'right', formatter: () => ACT_ICONS,
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && rowAct(b.dataset.act, c.getData()); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('scrSel').textContent = d.length;
    document.querySelectorAll('[data-sbulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};
const rowAct = (a, x) => a === 'edit' ? openForm(x) : a === 'msg' ? message(x) : a === 'chat' ? bg({ type: 'openChat', chatId: x.chatId }) : remove([x.id]);
const applyFilter = () => {
  if (!built) return;
  const k = $('scrSearch').value.trim().toLowerCase();
  table.setFilter(d => (stage === 'all' || d.status === stage) && (!k || `${d.name} ${d.phone} ${d.detailLine} ${d.summary} ${d.notes} ${no(d)}`.toLowerCase().includes(k)));
};
const pipe = () => {
  const n = s => s === 'all' ? rows.length : rows.filter(r => r.status === s).length;
  $('scrPipe').innerHTML = ['all', 'new', 'qualified', 'contacted', 'nofit'].map(s => `<button role="tab" aria-selected="${s === stage}" class="${s === stage ? 'active' : ''}" data-stage="${s}">
    ${s === 'all' ? '<i class="fa-solid fa-layer-group"></i> All' : `<i class="fa-solid ${ST[s][2]}"></i> ${ST[s][0]}`} <b>${n(s)}</b></button>`).join('');
};
const kpiBox = ([cls, val, lbl, ic, st, more]) => `<div class="small-box ${cls}"><div class="inner"><h3>${val}</h3><p>${lbl}</p></div><i class="icon fa-solid ${ic}"></i>
  <button type="button" class="small-box-footer" data-kstage="${st}">${more} <i class="fa-solid fa-circle-arrow-right"></i></button></div>`;
const kpis = () => {
  const n = s => rows.filter(r => r.status === s).length;
  $('scrKpis').innerHTML = [['bg-info', n('new'), 'New, to look at', 'fa-star', 'new', 'See new'], ['bg-success', n('qualified'), 'Qualified', 'fa-circle-check', 'qualified', 'See qualified'],
    ['bg-navy', n('contacted'), 'Contacted', 'fa-comment-dots', 'contacted', 'See contacted'], ['bg-danger', n('nofit'), 'Not a fit', 'fa-ban', 'nofit', 'See them']].map(kpiBox).join('');
};
$('scrKpis').addEventListener('click', e => { const b = e.target.closest('[data-kstage]'); if (!b) return; stage = b.dataset.kstage; pipe(); applyFilter(); $('scrPipe').scrollIntoView({ behavior: 'smooth', block: 'start' }); });

const load = async () => {
  const cfg = await getCfg();
  rows = ((await chrome.storage.local.get('screens')).screens || []).map(x => ({ ...x, detailLine: details(x), sortAt: x.upd || x.last || x.at }));
  const fresh = rows.filter(r => r.status === 'new').length;
  $('pillScreen').hidden = !fresh;
  $('pillScreen').textContent = fresh > 99 ? '99+' : fresh;
  $('scrCount').textContent = rows.length;
  $('scrOff').hidden = !!cfg.screenOn;
  pipe();
  kpis();
  built && (table.replaceData(rows), applyFilter());
};

const message = async x => {
  const cfg = await getCfg(), f = t => fillScreen(t, x, cfg);
  openMsg({ kind: 'screen', id: x.id, chatId: x.chatId, since: x.last || x.at, who: x.name || x.chatName, phone: x.phone, list: [
    ['Thank you', 'fa-heart', f(cfg.screenMsg)],
    ['Next step', 'fa-circle-check', f('Hi {name}, thank you. You are a good fit. When can we call you to take this forward?')],
    ['Need more', 'fa-circle-question', f('Hi {name}, thank you for your details. Could you share a little more about what you are looking for?')],
    ['Not a fit', 'fa-hand', f('Hi {name}, thank you for your interest. This is not the right match for now, but we will keep your details and contact you if that changes.')]] });
};
const setStatus = async (ids, status) => {
  const r = await bg({ type: 'screenSet', ids, status });
  r.ok ? toast(`${ids.length > 1 ? `${ids.length} rows` : 'Row'} marked ${ST[status][0].toLowerCase()}`) : toast(r.err, true);
};
const remove = async ids => {
  if (!(await confirmBox(`Delete ${ids.length > 1 ? `${ids.length} rows` : 'this row'}?`, 'It is removed from this list. A copy already in your Google Sheet stays there.'))) return false;
  const r = await bg({ type: 'screenDel', ids });
  r.ok ? toast('Deleted') : toast(r.err, true);
  return r.ok;
};

// add / edit: one box per detail from the setup (plus any the row already has)
const f = $('scrForm'), fdlg = $('scrFormDlg');
const pane = p => {
  fdlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  fdlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const formRow = () => ({ at: new Date().toISOString(), no: editId ? rows.find(r => r.id === editId)?.no || 0 : 0, status: f.status.value, name: f.name.value.trim(), phone: f.phone.value.replace(/\D/g, ''),
  fields: Object.fromEntries([...$('sfFields').querySelectorAll('[data-fk]')].map(i => [i.dataset.fk, i.value.trim()]).filter(([, v]) => v)), summary: f.summary.value.trim(), notes: f.notes.value.trim() });
const card = (title, ic, body) => `<div class="ord-card"><h4><i class="fa-solid ${ic}"></i> ${title}</h4>${body}</div>`;
const kv = (k, v) => v ? `<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>` : '';
const preview = async () => {
  const cfg = await getCfg(), x = formRow();
  fdlg.querySelectorAll('[data-st]').forEach(b => b.classList.toggle('on', b.dataset.st === x.status));
  $('sfPreview').innerHTML = card(ST[x.status]?.[0] || 'New', 'fa-user-check', (kv('Name', x.name) + kv('Phone', x.phone) + Object.entries(x.fields).map(([k, v]) => kv(label(k), v)).join('') + kv('What they want', x.summary) + kv('My notes', x.notes)) || '<p class="sub">Fill the form</p>')
    + `<p class="sub need">${!x.name && !x.phone ? 'Still needed: a name or a WhatsApp number' : 'Ready to save'}</p>`;
  $('sfMsgPrev').innerHTML = waFormat(fillScreen(cfg.screenMsg, { ...x, fields: { ...x.fields, name: x.name, phone: x.phone } }, cfg));
};
const openForm = async x => {
  editId = x?.id || null;
  const cfg = await getCfg(), keys = [...new Set([...keysOf(cfg), ...Object.keys(x?.fields || {}).filter(k => k !== 'name' && k !== 'phone')])];
  $('scrFormTitle').innerHTML = `<i class="fa-solid ${editId ? 'fa-pen' : 'fa-user-plus'}"></i> ${editId ? `Edit ${esc(no(x))}` : `Add ${esc(cfg.screenWhat || 'lead')}`}`;
  $('sfFields').innerHTML = keys.map(k => `<div class="fg"><label for="sf_${esc(k)}"><i class="fa-solid fa-tag"></i> ${esc(label(k))}</label><input class="field" id="sf_${esc(k)}" data-fk="${esc(k)}" maxlength="300" value="${esc(x?.fields?.[k] || '')}" autocomplete="off"></div>`).join('');
  f.status.value = x?.status || 'new'; f.name.value = x?.name || ''; f.phone.value = x?.phone || ''; f.summary.value = x?.summary || ''; f.notes.value = x?.notes || '';
  f.querySelectorAll('.bad').forEach(i => i.classList.remove('bad'));
  pane('form'); preview();
  fdlg.showModal();
  setTimeout(() => f.name.focus(), 50);
};
fdlg.addEventListener('click', e => {
  e.target.closest('[data-close]') && fdlg.close();
  const t = e.target.closest('[data-pane]'); t && pane(t.dataset.pane);
  const s = e.target.closest('[data-st]'); s && (f.status.value = s.dataset.st, preview());
});
f.addEventListener('input', preview);
f.onsubmit = async e => {
  e.preventDefault();
  const x = formRow();
  if (!x.name && !x.phone) { f.name.classList.add('bad'); f.name.focus(); return toast('Add a name or a WhatsApp number', true); }
  busy($('scrSave'), true);
  try {
    const r = await bg({ type: 'screenPut', id: editId, ...x });
    if (!r.ok) return toast(r.err, true);
    fdlg.close();
    toast(editId ? 'Saved' : 'Added');
  } finally { busy($('scrSave'), false); }
};
$('scrDemo').onclick = () => { // demo set #n for testing
  const n = demoSeq('screen');
  f.name.value = `Client ${n}`; f.phone.value = String(923001000000 + n); f.summary.value = 'Wants a quote for the standard package'; f.notes.value = '';
  $('sfFields').querySelectorAll('[data-fk]').forEach(i => i.value = { city: 'Demo City', budget: `${(n % 5 + 1) * 10000}`, email: `client${n}@demo.com`, experience: `${n % 6} years` }[i.dataset.fk] ?? `Demo ${label(i.dataset.fk)} ${n}`);
  preview();
};
$('scrAdd').onclick = () => openForm(null);

// pipeline, search, bulk, csv
$('scrPipe').addEventListener('click', e => { const b = e.target.closest('[data-stage]'); b && (stage = b.dataset.stage, pipe(), applyFilter()); });
$('scrSearch').oninput = applyFilter;
document.querySelectorAll('[data-sbulk]').forEach(b => b.onclick = async () => {
  const ids = table.getSelectedData().map(d => d.id);
  if (!ids.length) return;
  b.dataset.sbulk === 'delete' ? await remove(ids) : await setStatus(ids, b.dataset.sbulk);
  table.deselectRow();
});
$('scrCsv').onclick = async () => {
  const lst = built ? table.getData('active') : rows, keys = [...new Set([...keysOf(await getCfg()), ...lst.flatMap(x => Object.keys(x.fields || {}))])].filter(k => k !== 'name' && k !== 'phone');
  if (!lst.length) return toast('Nothing to export', true);
  download('screening.csv', toCSV([['No', 'Date', 'Status', 'Name', 'Phone', ...keys.map(label), 'What they want', 'Notes', 'WhatsApp'],
    ...lst.map(x => [no(x), x.at, ST[x.status]?.[0] || x.status, x.name, x.phone, ...keys.map(k => x.fields?.[k] || ''), x.summary, x.notes, x.chatName])]));
};

// setup page: field picks, mode, live preview of a demo chat + the saved row
const FIELDS = ['name', 'phone', 'city', 'budget', 'email', 'experience', 'age', 'service', 'timeline', 'notes'];
const TAGS = ['no', 'name', 'phone', 'what', 'summary'];
const DEMO = { name: 'Client 1', phone: '03001000001', city: 'Demo City', budget: '50,000', email: 'client1@demo.com', experience: '3 years', age: '28', service: 'Standard package', timeline: 'This month', notes: 'Prefers a call' };
const val = k => DEMO[k] ?? `[${label(k)}]`;
const and = a => a.length > 1 ? `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}` : a[0] || '';
const setupPreview = () => {
  const fl = list($('screenFields').value).map(x => x.toLowerCase()), keys = fl.map(k => k.replace(/\W+/g, '_')), ask = $('screenMode').value !== 'read', what = $('screenWhat').value.trim() || 'lead';
  const goal = $('screenGoal').value.trim(), say = (who, t) => `<div class="bubble ${who}">${waFormat(t)}</div>`;
  const told = keys.slice(0, Math.ceil(keys.length / 2)), missing = keys.filter(k => !told.includes(k));
  $('scrChat').innerHTML = [say('in', `Hi, I am ${val('name')}${told.includes('city') ? ` from ${val('city')}` : ''}. I want to know more.`),
    ask && missing.length ? say('out', `Happy to help! Could you share your ${and(missing.slice(0, 2).map(label))}?`) : say('out', 'Happy to help! Here is what we offer…'),
    ask && missing.length ? say('in', missing.slice(0, 2).map(val).join(', ')) : ''].join('');
  const saved = ask ? [...told, ...missing.slice(0, 2)] : told;
  $('scrRowPrev').innerHTML = `<div class="scr-row-h">${pill(goal ? 'qualified' : 'new')}<b>${esc(no({ at: new Date().toISOString(), no: 1 }))}</b></div>`
    + keys.map(k => `<div class="kv"><span>${esc(label(k))}</span><b class="${saved.includes(k) ? '' : 'sub'}">${esc(saved.includes(k) ? val(k) : 'not told yet')}</b></div>`).join('');
  const x = { at: new Date().toISOString(), no: 1, name: DEMO.name, phone: DEMO.phone, summary: 'Wants to know more', fields: Object.fromEntries(keys.map(k => [k, val(k)])) };
  $('scrMsgPrev').innerHTML = waFormat(fillScreen($('screenMsg').value, x, { screenWhat: what })) || '<span class="sub">No message</span>';
  $('scrSum').innerHTML = [
    ['fa-route', ask ? 'The AI <b>asks</b> for what is missing' : 'The AI <b>only reads</b>, no extra questions'],
    ['fa-clipboard-list', `Saves <b>${fl.length}</b> ${fl.length === 1 ? 'detail' : 'details'} per ${esc(what)}`],
    ['fa-bullseye', goal ? 'Marks <b>Qualified</b> or <b>Not a fit</b> from your rule' : 'Every row stays <b>New</b> until you mark it', goal ? '' : 'warn'],
    ['fa-table', 'Synced to the <b>Screening</b> tab of your Google Sheet']
  ].map(([i, t, c]) => `<li class="${c || ''}"><i class="fa-solid ${i}"></i><span>${t}</span></li>`).join('');
};
const paintSetup = () => {
  const root = $('scrSetup'), fl = list($('screenFields').value).map(x => x.toLowerCase());
  $('scrFieldPre').innerHTML = [...new Set([...FIELDS, ...fl])].map(x => `<button type="button" class="bk-pre" data-pre-for="screenFields" data-v="${esc(x)}"><i class="fa-solid fa-plus"></i> ${esc(x)}</button>`).join('');
  $('scrFieldN').textContent = fl.length;
  paintTags(root, [...TAGS, ...extraTags($('screenFields').value, TAGS)]);
  paintPicks(root);
  $('scrOnTxt').textContent = $('screenOn').checked ? 'On' : 'Off';
  root.classList.toggle('bk-paused', !$('screenOn').checked);
  setupPreview();
};
$('scrSetup').addEventListener('input', paintSetup);
$('scrSetup').addEventListener('change', paintSetup);
addEventListener('waai:saved', () => { paintSetup(); load(); });
addEventListener('waai:view', e => {
  e.detail === 'screenset' && paintSetup();
  if (e.detail !== 'screening') return;
  table ? built && table.redraw(true) : build();
});
chrome.storage.onChanged.addListener(c => (c.screens || c.cfg) && load());
load();
