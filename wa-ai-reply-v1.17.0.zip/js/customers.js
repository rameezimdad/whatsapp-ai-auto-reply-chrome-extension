/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// customers page: what the AI remembers per chat, my own notes, tags, language
import { $, esc, bg, toast, busy, ago, confirmBox, promptBox, toCSV, download, userCell } from './ui.js';

let rows = [], table = null, built = false, curId = null;
const dlg = $('custDlg'), f = $('custForm');
const when = ms => ms ? ago(new Date(ms).toISOString()) : 'never';
const tagHtml = t => t.length ? t.map(x => `<span class="tb-pill role"><i></i>${esc(x)}</span>`).join('') : '<span class="sub">-</span>';
const count = (n, tone) => `<span class="tb-pill ${+n ? tone : 'zero'}">${+n || 0}</span>`;
const who = r => r.name || (r.phone ? `+${r.phone}` : 'WhatsApp user');

const build = () => {
  table = new Tabulator($('custTable'), {
    data: rows, index: 'id', layout: 'fitColumns', responsiveLayout: 'collapse',
    placeholder: 'No customers remembered yet. The AI adds one the first time it answers a chat, or press Add customer.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true, initialSort: [{ column: 'at', dir: 'desc' }],
    selectableRows: 'highlight',
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'Customer', field: 'name', minWidth: 190, cssClass: 'tb-click', formatter: c => { const r = c.getData(); return userCell(who(r), r.phone ? `+${r.phone}` : r.id.endsWith('@g.us') ? 'Group' : 'Hidden number'); },
        cellClick: (e, c) => openCust(c.getData().id) },
      { title: 'Tags', field: 'tags', minWidth: 120, headerSort: false, formatter: c => tagHtml(c.getValue() || []), accessorDownload: v => (v || []).join(', ') },
      { title: 'Your notes', field: 'o', minWidth: 180, formatter: c => `<span class="clip2">${esc(c.getValue() || '-')}</span>` },
      { title: 'AI notes', field: 's', minWidth: 220, formatter: c => `<span class="clip2">${esc(c.getValue() || '-')}</span>${c.getData().freeze ? ' <span class="pill c-sent"><i class="fa-solid fa-lock"></i> Kept</span>' : ''}` },
      { title: 'Language', field: 'lang', minWidth: 110, formatter: c => c.getValue() ? `<span class="tb-pill role"><i class="fa-solid fa-language"></i>${esc(c.getValue())}</span>` : '<span class="sub">Auto</span>' },
      { title: 'Replies', field: 'sent', sorter: 'number', hozAlign: 'center', width: 90, formatter: c => count(c.getValue(), 'role') },
      { title: 'Orders', field: 'orders', sorter: 'number', hozAlign: 'center', width: 90, formatter: c => count(c.getValue(), 'ok') },
      { title: 'Updated', field: 'at', sorter: 'number', minWidth: 110, formatter: c => esc(when(c.getValue())), accessorDownload: v => v ? new Date(v).toISOString() : '' },
      { title: '', field: 'id', headerSort: false, download: false, width: 96, hozAlign: 'right',
        formatter: () => '<button class="nav-btn ic-edit" data-act="open" aria-label="Open" title="Open"><i class="fa-solid fa-pen"></i></button><button class="nav-btn ic-go" data-act="chat" aria-label="Open chat" title="Open chat"><i class="fa-brands fa-whatsapp"></i></button>',
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && (b.dataset.act === 'open' ? openCust(c.getData().id) : bg({ type: 'openChat', chatId: c.getData().id })); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('custSel').textContent = d.length;
    document.querySelectorAll('[data-cbulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};
const applyFilter = () => {
  if (!built) return;
  const k = $('custSearch').value.trim().toLowerCase();
  table.setFilter(d => !k || `${d.name} ${d.phone} ${d.tags.join(' ')} ${d.o} ${d.s} ${d.lang}`.toLowerCase().includes(k));
};
$('custSearch').addEventListener('input', applyFilter);
const load = async () => {
  const r = await bg({ type: 'custList' });
  rows = r.rows || [];
  built && (table.replaceData(rows), applyFilter());
  curId && dlg.open && fillDlg(curId);
};

// editor
const pane = p => {
  dlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  dlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const tags = () => [...new Set(f.tags.value.split(',').map(t => t.trim()).filter(Boolean))];
const preview = () => {
  const parts = [];
  f.s.value.trim() && parts.push(`What you know about this customer from earlier chats:\n${f.s.value.trim()}`);
  f.o.value.trim() && parts.push(`The owner's own notes about this customer (follow them):\n${f.o.value.trim()}`);
  tags().length && parts.push(`Customer tags: ${tags().join(', ')}.`);
  f.lang.value.trim() && parts.push(`Always reply to this customer in ${f.lang.value.trim()}.`);
  $('custPreview').textContent = parts.join('\n\n') || 'Nothing yet. Whatever you write here is read before every reply to this customer.';
};
const fillDlg = id => {
  const r = rows.find(x => x.id === id) || {};
  f.name.value = r.name || ''; f.o.value = r.o || ''; f.tags.value = (r.tags || []).join(', '); f.lang.value = r.lang || ''; f.s.value = r.s || ''; f.freeze.checked = !!r.freeze;
  $('custMeta').innerHTML = id ? `<span><i class="fa-brands fa-whatsapp"></i>${esc(r.phone ? `+${r.phone}` : 'Hidden number')}</span><span><i class="fa-solid fa-paper-plane"></i>${r.sent || 0} replies</span><span><i class="fa-solid fa-bag-shopping"></i>${r.orders || 0} orders</span><span><i class="fa-regular fa-clock"></i>Updated ${esc(when(r.at))}</span>` : '';
  preview();
};
const openCust = id => {
  curId = id || null;
  $('custPhoneRow').hidden = !!id;
  $('custForget').hidden = !id;
  f.phone.value = '';
  fillDlg(id);
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  $('custDlgTitle').innerHTML = `<i class="fa-solid fa-user"></i> ${id ? esc(who(rows.find(x => x.id === id) || {})) : 'Add customer'}`;
  pane('form');
  dlg.showModal();
  setTimeout(() => (id ? f.o : f.phone).focus(), 50);
};
dlg.addEventListener('click', e => {
  e.target.closest('[data-close]') && dlg.close();
  const t = e.target.closest('[data-pane]');
  t && pane(t.dataset.pane);
});
f.addEventListener('input', preview);
f.onsubmit = async e => {
  e.preventDefault();
  if (!curId && f.phone.value.replace(/\D/g, '').length < 7) { f.phone.classList.add('bad'); f.phone.focus(); return toast('Add the WhatsApp number with the country code', true); }
  const btn = $('custSave');
  busy(btn, true);
  try {
    const r = await bg({ type: 'custPut', id: curId, phone: f.phone.value, name: f.name.value, o: f.o.value, tags: tags(), lang: f.lang.value, s: f.s.value, freeze: f.freeze.checked });
    if (!r.ok) return toast(r.err, true);
    dlg.close();
    toast('Saved. The AI reads it on the next reply.');
  } finally { busy(btn, false); }
};
$('custForget').onclick = async e => {
  if (!curId || !(await confirmBox('Forget this customer?', 'All notes, tags and the language for this chat are deleted. Their orders stay.'))) return;
  busy(e.currentTarget, true);
  await bg({ type: 'custDel', ids: [curId] });
  dlg.close();
  toast('Forgotten');
};
$('custAdd').onclick = () => openCust(null);

// bulk
document.querySelectorAll('[data-cbulk]').forEach(b => b.onclick = async () => {
  const sel = table ? table.getSelectedData() : [];
  if (!sel.length) return;
  const act = b.dataset.cbulk;
  if (act === 'del') {
    if (!(await confirmBox(`Forget ${sel.length} ${sel.length === 1 ? 'customer' : 'customers'}?`, 'Their notes, tags and language are deleted. Orders stay.'))) return;
    await bg({ type: 'custDel', ids: sel.map(r => r.id) });
    return toast('Forgotten');
  }
  const v = act === 'tag' ? await promptBox(`Add a tag to ${sel.length}`, 'Tag', { ok: 'Add tag', placeholder: 'VIP' })
    : await promptBox(`Language for ${sel.length}`, 'Always reply to them in (empty = same as they write)', { ok: 'Set language', placeholder: 'Roman Urdu' });
  if (v === null || (act === 'tag' && !v)) return;
  busy(b, true);
  for (const r of sel) await bg({ type: 'custPut', id: r.id, ...(act === 'tag' ? { tags: [...r.tags, v] } : { lang: v }) });
  busy(b, false);
  table.deselectRow();
  toast(act === 'tag' ? `Tag added to ${sel.length}` : `Language set for ${sel.length}`);
});
$('custCsv').onclick = () => {
  if (!rows.length) return toast('No customers to export', true);
  download(`customers-${new Date().toISOString().slice(0, 10)}.csv`, toCSV([['name', 'phone', 'tags', 'your_notes', 'ai_notes', 'language', 'replies', 'orders'],
    ...rows.map(r => [r.name, r.phone, r.tags.join(', '), r.o, r.s, r.lang, r.sent, r.orders])]));
};

addEventListener('waai:view', e => { if (e.detail !== 'customers') return; table ? built && table.redraw(true) : build(); });
chrome.storage.onChanged.addListener(c => (c.memo || c.orders || c.log) && load());
load();
