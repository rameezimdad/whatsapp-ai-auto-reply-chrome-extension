/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// orders setup page: field picks, tags, areas, live preview of a demo order (unsaved edits included)
import { $, esc, waFormat } from './ui.js';
import { fillOrder } from './cfg.js';
import { list, paintChips, paintPicks, paintTags, extraTags } from './setup.js';

const FIELDS = ['name', 'phone', 'city', 'address', 'items', 'email', 'size', 'colour', 'delivery date', 'notes'];
const TAGS = ['no', 'name', 'phone', 'city', 'address', 'items', 'delivery', 'total', 'cur', 'pay'];
const DEMO = { name: 'Client 1', phone: '03001000001', city: 'Demo City', address: 'House 1, Street 1', email: 'client1@demo.com', size: 'M', colour: 'Blue', delivery_date: 'Saturday' };
const ITEMS = [{ name: 'Product A', qty: 2, price: 1000 }, { name: 'Product B', qty: 1, price: 1500 }];
const amt = n => (+n || 0).toLocaleString('en-US');
const and = a => a.length > 1 ? `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}` : a[0] || '';

const preview = () => {
  const cur = $('orderCur').value.trim() || 'Rs', m = n => `${cur} ${amt(n)}`;
  const fields = list($('orderFields').value).map(f => f.toLowerCase()), ask = fields.filter(f => f !== 'items');
  const areas = list($('orderAreas').value), pay = $('orderPay').value.split('\n').map(x => x.trim()).filter(Boolean);
  const del = +$('orderDelivery').value || 0, free = +$('orderFreeOver').value || 0, min = +$('orderMin').value || 0;
  const sub = ITEMS.reduce((t, i) => t + i.qty * i.price, 0), delivery = del && !(free && sub >= free) ? del : 0;
  const city = areas.length && !areas.some(a => a.toLowerCase() === 'demo city') ? areas[0] : DEMO.city;
  const val = f => f === 'city' ? city : DEMO[f.replace(/\W+/g, '_')] ?? `[${f}]`;
  // the chat, step by step
  const say = (who, t) => `<div class="bubble ${who}">${waFormat(t)}</div>`;
  const chat = [say('in', 'Hi, I want 2 Product A and 1 Product B')];
  ask.length && chat.push(say('out', `Sure! Please send your ${and(ask)}.`), say('in', ask.map(val).join('\n')));
  if (min && sub < min) chat.push(say('out', `Sorry, the minimum order is *${m(min)}*. Would you like to add something?`));
  else {
    chat.push(say('out', `Here is your order:\n${ITEMS.map(i => `${i.qty} x ${i.name} (${m(i.qty * i.price)})`).join('\n')}\nDelivery: ${delivery ? m(delivery) : 'Free'}\n*Total: ${m(sub + delivery)}*\n\nShall I confirm it?`), say('in', 'Yes'));
    chat.push(say('out', `Thank you, ${DEMO.name}! Your order is placed.${pay.length ? `\n\nHow to pay:\n${pay.join('\n')}` : ''}`));
  }
  $('ordChat').innerHTML = chat.join('');
  const o = { at: new Date().toISOString(), no: 1, items: ITEMS, delivery, total: sub + delivery, cur, name: DEMO.name, phone: DEMO.phone, city, address: DEMO.address,
    extra: Object.fromEntries(extraTags($('orderFields').value, TAGS).map(k => [k, DEMO[k] ?? `[${k}]`])) };
  $('ordMsgPrev').innerHTML = waFormat(fillOrder($('orderMsg').value, o, { orderPay: pay.join('\n'), orderCur: cur })) || '<span class="sub">No message</span>';
  // what the AI will do, in one list
  $('ordSum').innerHTML = [
    ['fa-clipboard-list', `Asks for <b>${fields.length}</b> ${fields.length === 1 ? 'detail' : 'details'}`],
    ['fa-truck', del ? `Delivery <b>${esc(m(del))}</b>${free ? `, free from <b>${esc(m(free))}</b>` : ''}` : '<b>Free</b> delivery'],
    ['fa-scale-balanced', min ? `Minimum order <b>${esc(m(min))}</b>` : 'No minimum order', min && sub < min ? 'warn' : ''],
    ['fa-wallet', pay.length ? `<b>${pay.length}</b> ${pay.length === 1 ? 'way' : 'ways'} to pay` : 'Payment is not mentioned'],
    ['fa-location-dot', areas.length ? `Delivers to <b>${areas.length}</b> ${areas.length === 1 ? 'area' : 'areas'}` : 'Delivers <b>everywhere</b>'],
    ['fa-user-plus', $('leadsOn').checked ? 'Saves leads too' : 'Orders only, no leads']
  ].map(([i, t, c]) => `<li class="${c || ''}"><i class="fa-solid ${i}"></i><span>${t}</span></li>`).join('');
};

const paint = () => {
  const root = $('ordSetup'), fl = list($('orderFields').value).map(f => f.toLowerCase());
  $('ordFieldPre').innerHTML = [...new Set([...FIELDS, ...fl])].map(f => `<button type="button" class="bk-pre" data-pre-for="orderFields" data-v="${esc(f)}"${f === 'items' ? ' disabled title="Always collected"' : ''}><i class="fa-solid fa-plus"></i> ${esc(f)}</button>`).join('');
  $('ordFieldN').textContent = fl.length;
  root.querySelectorAll('.cur-u').forEach(u => u.textContent = $('orderCur').value.trim() || 'Rs');
  paintTags(root, [...TAGS, ...extraTags($('orderFields').value, TAGS)]);
  paintPicks(root);
  paintChips(root);
  $('ordOnTxt').textContent = $('ordersOn').checked ? 'On' : 'Off';
  root.classList.toggle('bk-paused', !$('ordersOn').checked);
  preview();
};

$('ordSetup').addEventListener('input', paint);
$('ordSetup').addEventListener('change', paint);
addEventListener('waai:saved', paint);
addEventListener('waai:view', e => e.detail === 'ordset' && paint());
