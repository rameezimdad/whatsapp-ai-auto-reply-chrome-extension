@echo off
rem Developed by Mohammad Rameez Imdad (Rameez Scripts)
rem WhatsApp: https://wa.me/923435347417 (For Custom Projects)
rem YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
rem WA AI Reply: stop the automatic update check
schtasks /Delete /F /TN "WA AI Reply Update" >nul 2>&1
del "%~dp0status.json" >nul 2>&1
echo Auto update is OFF. Download new versions yourself from GitHub.
pause
