/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// reply rules page: number chips, working days, summary, "would the bot reply?" check (unsaved edits included)
import { $, esc } from './ui.js';
import { numList } from './cfg.js';
import { list, setVal, paintChips, paintPicks } from './setup.js';

const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];
const DOW = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

// same order as the service worker: group → blocked → only-reply-to → working hours
const check = () => {
  const ph = $('rcNum').value.replace(/\D/g, ''), group = $('rcGroup').checked, day = $('rcDay').value, t = $('rcTime').value || '12:00';
  const allow = numList($('allow').value), block = numList($('block').value), days = list($('hoursDays').value), f = $('hoursFrom').value, z = $('hoursTo').value;
  const night = f > z && t < z, dayOk = !days.length || days.includes(night ? DOW[(DOW.indexOf(day) + 6) % 7] : day);
  const inHours = dayOk && (f <= z ? t >= f && t < z : t >= f || t < z);
  const steps = [
    group ? [$('groupsOn').checked, $('groupsOn').checked ? 'Groups are allowed' : 'Groups are off'] : null,
    ph ? [!block.has(ph), block.has(ph) ? 'This number is on Never reply to' : 'Not blocked'] : null,
    ph || allow.size ? [!allow.size || allow.has(ph), !allow.size ? 'Everyone may get a reply' : allow.has(ph) ? 'On the Only reply to list' : 'Not on the Only reply to list'] : null,
    $('hoursOn').checked ? [inHours, inHours ? 'Inside working hours' : !dayOk ? 'Not a working day' : 'Outside working hours'] : [true, 'Replies at any time']
  ].filter(Boolean);
  const ok = steps.every(([y]) => y), quick = ph && $('qrAuto').checked && numList($('autoNums').value).has(ph);
  $('rcOut').innerHTML = steps.map(([y, w]) => `<li class="${y ? 'ok' : 'no'}"><i class="fa-solid ${y ? 'fa-check' : 'fa-xmark'}"></i><span>${esc(w)}</span></li>`).join('')
    + `<li class="rc-end ${ok ? 'ok' : 'no'}"><i class="fa-solid ${ok ? 'fa-robot' : 'fa-hand'}"></i><span>${ok ? `<b>Yes, it replies.</b> ${quick ? 'A saved quick reply goes out by itself; anything else waits for your Send.' : 'The reply waits for your Send.'}` : '<b>No reply.</b> The chat waits for you.'}</span></li>`
    + `<li class="rc-note"><i class="fa-solid fa-circle-info"></i><span>${$('savedOnly').checked ? 'Only if the number is saved in your contacts. ' : ''}The bot must be on, and the daily limits, budget and paused chats still apply.</span></li>`;
};

const paint = () => {
  const root = $('rulesSetup'), on = new Set(list($('hoursDays').value));
  $('hoursDayChips').innerHTML = DAYS.map(([k, l]) => `<button type="button" class="chip${on.has(k) ? ' on' : ''}" data-hday="${k}" aria-pressed="${on.has(k)}">${l}</button>`).join('');
  paintPicks(root);
  paintChips(root);
  $('hoursBox').classList.toggle('off', !$('hoursOn').checked);
  const allow = numList($('allow').value).size, block = numList($('block').value).size, hours = $('hoursOn').checked;
  const dayTxt = on.size === 7 ? 'every day' : on.size ? DAYS.filter(([k]) => on.has(k)).map(([, l]) => l).join(', ') : 'no days';
  $('rulesLine').textContent = `Replies to ${allow ? plural(allow, 'number') : 'everyone'}${block ? `, never to ${plural(block, 'number')}` : ''} · ${hours ? `${$('hoursFrom').value} to ${$('hoursTo').value}, ${dayTxt}` : 'any time'} · ${$('groupsOn').checked ? 'groups too' : 'no groups'}`;
  $('rulesState').innerHTML = hours ? '<i class="fa-solid fa-clock"></i> Working hours' : '<i class="fa-solid fa-infinity"></i> Any time';
  $('rulesSum').innerHTML = [
    ['fa-user-check', allow ? `Only <b>${plural(allow, 'number')}</b> get replies` : 'Replies to <b>everyone</b>'],
    ['fa-ban', block ? `<b>${plural(block, 'number')}</b> never get a reply` : 'Nobody blocked'],
    ['fa-users', $('groupsOn').checked ? 'Replies in <b>groups</b> too' : 'Groups left alone'],
    ['fa-clock', hours ? `<b>${esc($('hoursFrom').value)} to ${esc($('hoursTo').value)}</b>, ${esc(dayTxt)}` : 'Replies <b>any time</b>', hours && !on.size ? 'warn' : ''],
    ['fa-paper-plane', $('autoSend')?.checked ? 'AI replies go out <b>without review</b>' : 'Every AI reply <b>waits for your Send</b>', $('autoSend')?.checked ? 'warn' : ''],
    ['fa-bolt', $('qrAuto').checked ? `Quick replies by themselves to <b>${plural(numList($('autoNums').value).size, 'number')}</b>` : 'Quick replies wait for you too'],
    ['fa-address-book', $('savedOnly').checked ? 'Only <b>saved contacts</b> get replies' : 'Saved and unsaved numbers'],
    ['fa-clock-rotate-left', +$('maxAge').value ? `Leaves messages older than <b>${esc($('maxAge').value)} min</b>` : 'Answers old messages too']
  ].map(([i, t, c]) => `<li class="${c || ''}"><i class="fa-solid ${i}"></i><span>${t}</span></li>`).join('');
  check();
};

$('rulesSetup').addEventListener('click', e => {
  const b = e.target.closest('[data-hday]');
  if (!b) return;
  const on = new Set(list($('hoursDays').value));
  on.has(b.dataset.hday) ? on.delete(b.dataset.hday) : on.add(b.dataset.hday);
  setVal('hoursDays', DAYS.map(([k]) => k).filter(k => on.has(k)).join(','));
});
$('rulesSetup').addEventListener('input', paint);
$('rulesSetup').addEventListener('change', paint);
addEventListener('waai:saved', paint);
addEventListener('waai:view', e => e.detail === 'rules' && paint());
// the check starts at this moment
$('rcDay').value = DOW[new Date().getDay()];
$('rcTime').value = new Date().toTimeString().slice(0, 5);
