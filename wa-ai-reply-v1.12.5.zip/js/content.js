/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// isolated world: page <-> background bridge, per-chat debounce, on-page pill
(() => {
  const ORIGIN = location.origin;
  // after an extension update this tab is cut off until it reloads
  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  const bg = msg => alive() ? chrome.runtime.sendMessage(msg).catch(() => (alive() || state('stale'), null)) : (state('stale'), Promise.resolve(null));
  const STR = v => typeof v === 'string';
  const CHAT = v => STR(v) && /@(c\.us|lid|g\.us)$/.test(v);
  const timers = new Map(), busy = new Map(); // chatId -> timer / rerun flag
  const typing = new Map(), since = new Map(); // chatId -> last typing seen / first unanswered msg
  let lastUse = 0; // owner's last key / click on the page
  ['keydown', 'mousedown', 'touchstart'].forEach(t => addEventListener(t, () => { lastUse = Date.now(); }, { capture: true, passive: true }));
  const waits = new Map(); // rid -> resolve
  let seq = 0;

  // ask page world, await its reply
  const page = (type, data = {}, ms = 30000) => new Promise((res, rej) => {
    const rid = ++seq;
    const to = setTimeout(() => { waits.delete(rid); rej(new Error('WhatsApp tab did not answer')); }, ms);
    waits.set(rid, d => { clearTimeout(to); d.ok ? res(d) : rej(new Error(d.err)); });
    window.postMessage({ waai: 'ext', type, rid, ...data }, ORIGIN);
  });

  const rand = (a, b) => Math.round((a + Math.random() * Math.max(0, b - a)) * 1000);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // new customer msgs: voice → words, newest photos → image input
  const enrich = async (chat, items) => {
    let imgs = 0;
    for (const m of items.slice(items.findLastIndex(x => x.me) + 1).reverse()) {
      if ((m.type === 'ptt' || m.type === 'audio') && chat.voice) {
        let r = await bg({ type: 'tx', id: m.id });
        if (!r?.text) {
          const md = await page('media', { id: m.id }, 60000).catch(() => null);
          r = md && await bg({ type: 'tx', id: m.id, mime: md.mime, data: md.data, chat: { chatId: chat.chatId, name: chat.name, phone: chat.phone } });
        }
        r?.text && (m.text = `[voice note] ${r.text}`);
      } else if (m.type === 'image' && chat.photo && imgs < 3) {
        const md = await page('media', { id: m.id }, 60000).catch(() => null);
        md && (m.img = { mime: md.mime, data: md.data }, imgs++);
      }
    }
  };

  // quick reply files + pin after the text
  const sendExtras = async (chatId, res) => {
    for (const f of res.files || []) {
      const d = await bg({ type: 'qrFile', id: f.id });
      if (!d?.ok) continue;
      await sleep(900);
      await send('sendFile', { chatId, dataUrl: d.dataUrl, name: d.name, mime: d.mime }, 120000).catch(() => {});
    }
    if (res.loc) { await sleep(900); await page('sendPin', { chatId, loc: res.loc }).catch(() => {}); }
  };

  // a reply I approved: text, then its files / pin
  // every message and file this tab sends asks the licence first
  const send = async (type, args, ms) => {
    const g = await bg({ type: 'licOk' });
    if (!g?.ok) throw new Error(g?.err || 'The licence key is not active');
    return page(type, args, ms);
  };

  const sendDraft = async d => {
    try {
      await send('send', { chatId: d.chatId, text: d.text, typingMs: Math.min(4000, 800 + d.text.length * 20), read: true }, 60000);
      await sendExtras(d.chatId, d);
      return { ok: true };
    } catch (e) { return { ok: false, err: e.message }; }
  };

  const run = async chat => {
    if (busy.has(chat.chatId)) return void busy.set(chat.chatId, true); // reply in flight, go again after
    busy.set(chat.chatId, false);
    try {
      // one read: older part feeds the customer notes, the newest part is the reply context
      const ms = await bg({ type: 'memoState', chatId: chat.chatId });
      const { items: all } = await page('history', { chatId: chat.chatId, count: ms?.on ? Math.max(ms.depth, chat.history) : chat.history }, 60000);
      const items = all.slice(-chat.history);
      if (ms?.on) {
        const older = all.slice(0, Math.max(0, all.length - chat.history))
          .filter(m => (+m.t || 0) > ms.upto && !/^\[(image|video|sticker|document|location|contact card|voice note|audio)\]$/.test(m.text));
        (older.length >= 10 || (!ms.upto && older.length >= 3)) && await bg({ type: 'memo', chat, items: older.map(({ me, t, text }) => ({ me, t, text })) });
      }
      await enrich(chat, items);
      const first = !all.some(m => m.me) && all.length <= 3; // never answered before → the introduction
      const res = await bg({ type: 'ask', chat: { ...chat, first }, items });
      if (res?.retryIn) return void setTimeout(() => schedule(chat), res.retryIn); // per-minute limit, try later
      if (busy.get(chat.chatId) || timers.has(chat.chatId)) return; // more msgs came while the AI wrote: one reply for all, from the next run
      if (res?.text) {
        let ok = true, err = '';
        await send('send', { chatId: chat.chatId, text: res.text, typingMs: res.typingMs, read: res.read }).catch(e => { ok = false; err = e.message; });
        ok && await sendExtras(chat.chatId, res);
        await bg({ type: 'done', chat, inText: res.inText, outText: res.text, ok, err, qr: res.qr, order: res.order });
      }
    } catch (e) {
      await bg({ type: 'done', chat, ok: false, err: e.message });
    } finally {
      const again = busy.get(chat.chatId);
      busy.delete(chat.chatId);
      again && schedule(chat);
    }
  };

  const schedule = async chat => {
    const res = await bg({ type: 'check', chat });
    if (res?.notice) await send('send', { chatId: chat.chatId, text: res.notice, typingMs: 1500, read: true }).catch(() => {}); // stop note, no-review mode only
    if (!res?.ok) return;
    clearTimeout(timers.get(chat.chatId));
    since.has(chat.chatId) || since.set(chat.chatId, Date.now());
    timers.set(chat.chatId, setTimeout(() => fire(chat, res), rand(res.delayMin, res.delayMax)));
  };
  // every new msg restarts the wait; while the customer types it keeps waiting, a minute at most from their first msg
  const typingNow = id => Date.now() - (typing.get(id) || 0) < 25000;
  const fire = (chat, res) => {
    const id = chat.chatId;
    if (res.typingWait && typingNow(id) && Date.now() - (since.get(id) || 0) < 60000) return void timers.set(id, setTimeout(() => fire(chat, res), 2500));
    timers.delete(id); since.delete(id);
    run({ ...chat, history: res.history, voice: res.voice, photo: res.photo });
  };

  window.addEventListener('message', e => {
    const d = e.data;
    if (e.source !== window || e.origin !== ORIGIN || d?.waai !== 'page') return;
    if (d.type === 'reply') return waits.has(d.rid) && (waits.get(d.rid)(d), waits.delete(d.rid));
    if (d.type === 'msg' && CHAT(d.chatId)) return schedule({ chatId: d.chatId, isGroup: !!d.isGroup, name: STR(d.name) ? d.name : '', phone: STR(d.phone) ? d.phone : '', t: +d.t || 0, saved: !!d.saved, text: STR(d.text) ? d.text.slice(0, 4000) : '', kind: d.kind === 'audio' || d.kind === 'image' ? d.kind : '' });
    if (d.type === 'typing' && CHAT(d.chatId)) return void (d.on ? typing.set(d.chatId, Date.now()) : typing.delete(d.chatId));
    if (d.type === 'human' && CHAT(d.chatId)) { clearTimeout(timers.get(d.chatId)); timers.delete(d.chatId); since.delete(d.chatId); return bg({ type: 'human', chatId: d.chatId, text: STR(d.text) ? d.text.slice(0, 4000) : '', prev: STR(d.prev) ? d.prev.slice(0, 1000) : '' }); }
    if (d.type === 'status') {
      ready = true;
      d.fail ? state('lib') : d.auth ? state(on ? 'on' : 'off') : state('login');
      bg({ type: 'status', auth: !!d.auth, me: STR(d.me) ? d.me : '', wpp: STR(d.wpp) ? d.wpp : '', wa: STR(d.wa) ? d.wa : '', fail: d.fail || '' });
    }
  });

  // popup / background requests
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m?.type === 'ping') return void window.postMessage({ waai: 'ext', type: 'status' }, ORIGIN);
    const job = { idle: async () => ({ idle: !busy.size && !timers.size && (document.hidden || Date.now() - lastUse > 60000) }), scan: () => page('scan', {}, 90000), bizProfile: () => page('bizProfile', {}, 60000), qrList: () => page('qrList'), open: () => page('open', { chatId: m.chatId }),
      sendText: () => send('send', { chatId: m.chatId, text: m.text, typingMs: 1200, read: true }),
      sendDraft: () => sendDraft(m.draft).then(r => { if (!r.ok) throw new Error(r.err); return {}; }) }[m?.type];
    if (!job) return;
    job().then(d => reply({ ok: true, ...d }), e => reply({ ok: false, err: e.message }));
    return true; // async reply
  });

  // on-page bot button + review panel: AI replies wait here for my Send
  const host = document.createElement('div');
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
    * { box-sizing: border-box; font-family: -apple-system, 'Segoe UI', Roboto, sans-serif; }
    .pill { all: unset; position: fixed; left: 12px; bottom: 12px; z-index: 2147483000; display: flex; align-items: center; gap: 8px; padding: 8px 14px; border-radius: 999px; font-size: 13px; font-weight: 600; color: #fff; background: #001f3f; box-shadow: 0 2px 10px rgba(0,0,0,.25); cursor: pointer; }
    .pill:focus-visible, .rv button:focus-visible, .rv textarea:focus-visible { outline: 2px solid #0074D9; outline-offset: 2px; }
    .pill i { width: 8px; height: 8px; border-radius: 50%; background: #8f8f8f; }
    .pill.on i { background: #34a853; }
    .pill.login, .pill.wait { background: #8a5300; } .pill.login i, .pill.wait i { background: #fbbc04; }
    .pill.lib, .pill.stale { background: #a8232a; } .pill.lib i, .pill.stale i { background: #fff; }
    .pill b { padding: 1px 8px; border-radius: 999px; background: #fbbc04; color: #1f1400; font-size: 11px; }
    .pill b[hidden], .rv[hidden], .in[hidden] { display: none; }
    .rv { position: fixed; left: 12px; bottom: 58px; z-index: 2147483000; width: 340px; max-width: calc(100vw - 24px); background: #fff; color: #333; border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.25); overflow: hidden; font-size: 13px; }
    .rh { display: flex; align-items: center; gap: 8px; padding: 10px 12px; background: #001f3f; color: #fff; cursor: pointer; }
    .rh b { flex: 1; }
    .rh span { font-size: 12px; opacity: .8; }
    .rh button { all: unset; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; border-radius: 6px; cursor: pointer; font-size: 15px; }
    .rh button:hover { background: rgba(255,255,255,.15); }
    .rb { padding: 12px; display: flex; flex-direction: column; gap: 8px; }
    .rv.min .rb { display: none; }
    .to { font-weight: 600; }
    .in { color: #555; background: #f3f3f3; border-radius: 10px; padding: 8px 10px; max-height: 84px; overflow: auto; white-space: pre-wrap; word-break: break-word; unicode-bidi: plaintext; text-align: start; }
    textarea { unicode-bidi: plaintext; text-align: start; width: 100%; min-height: 100px; max-height: 240px; resize: vertical; padding: 8px 10px; border: 1px solid #d0d0d0; border-radius: 10px; font-size: 14px; line-height: 1.45; color: #222; background: #fff; }
    .att { font-size: 12px; color: #666; } .att:empty, .err:empty { display: none; }
    .err { font-size: 12px; color: #a8232a; }
    .act { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
    .act button { all: unset; padding: 7px 12px; border-radius: 999px; font-weight: 600; font-size: 12.5px; cursor: pointer; border: 1px solid #d0d0d0; color: #333; }
    .act .send { background: #0074D9; border-color: #0074D9; color: #fff; }
    .act button:disabled { opacity: .45; cursor: default; }
    .act .nav { margin-left: auto; display: flex; gap: 2px; }
    .act .nav button { padding: 4px 10px; }
    @media (prefers-color-scheme: dark) { .rv { background: #1e1e1e; color: #eee; } .in { background: #2a2a2a; color: #bbb; } textarea { background: #2a2a2a; color: #eee; border-color: #3a3a3a; } .act button { color: #eee; border-color: #3a3a3a; } .att { color: #9a9a9a; } .err { color: #ff8d92; } }
  </style>
  <div class="rv" hidden role="region" aria-label="Replies to check">
    <div class="rh"><b>Reply to check</b><span class="n"></span><button type="button" class="mn" aria-label="Minimise or open" title="Minimise or open">&#8211;</button></div>
    <div class="rb">
      <div class="to"></div>
      <div class="in"></div>
      <textarea dir="auto" aria-label="Reply text, you can change it before sending"></textarea>
      <div class="att"></div><div class="err" role="alert"></div>
      <div class="act"><button type="button" class="send">Send</button><button type="button" class="skip">Skip</button><button type="button" class="open">Open chat</button>
        <span class="nav"><button type="button" class="prev" aria-label="Previous reply">&#8249;</button><button type="button" class="next" aria-label="Next reply">&#8250;</button></span></div>
    </div>
  </div>
  <button type="button" class="pill" aria-label="Turn AI replies on or off"><i></i><span>AI Reply OFF</span><b hidden></b></button>`;
  const $r = q => root.querySelector(q);
  const btn = $r('.pill'), rv = $r('.rv'), ta = $r('textarea');
  // pill states: on / off / login / wait / lib / stale
  const STATES = {
    on: ['AI Reply ON', 'Click to turn AI replies off'], off: ['AI Reply OFF', 'Click to turn AI replies on'],
    login: ['AI Reply: log in first', 'Scan the QR code to log in to WhatsApp Web'],
    wait: ['AI Reply: not connected', 'WhatsApp Web is still loading or the extension could not connect. Click to reload this tab.'],
    lib: ['AI Reply: update needed', 'WhatsApp Web changed and the bot could not start. Update the extension, then click to reload.'],
    stale: ['AI Reply: reload this tab', 'The extension was updated. Click to reload WhatsApp Web.']
  };
  let on = false, cur = 'off', ready = false;
  function state(s) {
    if (cur === 'stale') return; // only a reload fixes it
    cur = s;
    btn.className = `pill ${s}`;
    btn.querySelector('span').textContent = STATES[s][0];
    btn.title = STATES[s][1];
  }
  btn.addEventListener('click', () => ['stale', 'wait', 'lib'].includes(cur) ? location.reload() : bg({ type: 'toggle' }));

  // review panel
  let drafts = [], di = 0, shownId = '', panel = true;
  const paintRv = () => {
    const n = drafts.length, badge = btn.querySelector('b');
    badge.hidden = !n;
    badge.textContent = `${n} to check`;
    rv.hidden = !panel || !n;
    if (!n) return;
    di = Math.min(di, n - 1);
    const d = drafts[di];
    $r('.n').textContent = `${di + 1} of ${n}`;
    $r('.to').textContent = `To ${d.name || d.phone || 'customer'}${d.kind === 'optout' ? ' · stop note' : d.kind === 'payment' ? ' · payment reply' : ''}`;
    $r('.in').textContent = d.inText || '';
    $r('.in').hidden = !d.inText;
    if (shownId !== d.id) { ta.value = d.text; shownId = d.id; $r('.err').textContent = ''; } // keep my edits
    $r('.att').textContent = [(d.files || []).length ? `+ ${d.files.length} file${d.files.length > 1 ? 's' : ''}` : '', d.loc ? '+ map pin' : ''].filter(Boolean).join(' · ');
    $r('.prev').disabled = di === 0;
    $r('.next').disabled = di === n - 1;
  };
  const load = (list, cfg) => {
    drafts = (list || []).filter(d => Date.now() - new Date(d.at) < 864e5);
    if (cfg) panel = cfg.reviewPanel !== false;
    paintRv();
  };
  const hold = b => root.querySelectorAll('.act button').forEach(x => x.disabled = b);
  $r('.rh').addEventListener('click', () => rv.classList.toggle('min'));
  $r('.send').addEventListener('click', async () => {
    const d = drafts[di], text = ta.value.trim();
    if (!d || !text) return;
    hold(true);
    const r = await sendDraft({ ...d, text });
    await bg({ type: 'draftDone', id: d.id, ok: r.ok, err: r.err, text });
    hold(false);
    r.ok || ($r('.err').textContent = `Not sent: ${r.err}`);
    paintRv();
  });
  $r('.skip').addEventListener('click', async () => { const d = drafts[di]; if (!d) return; hold(true); await bg({ type: 'draftSkip', id: d.id }); hold(false); paintRv(); });
  $r('.open').addEventListener('click', () => drafts[di] && page('open', { chatId: drafts[di].chatId }).catch(() => {}));
  $r('.prev').addEventListener('click', () => { di--; paintRv(); });
  $r('.next').addEventListener('click', () => { di++; paintRv(); });

  chrome.storage.local.get(['cfg', 'drafts']).then(r => { on = !!r.cfg?.enabled; state(cur === 'off' || cur === 'on' ? (on ? 'on' : 'off') : cur); load(r.drafts, r.cfg); });
  chrome.storage.onChanged.addListener(c => {
    if (c.cfg) { on = !!c.cfg.newValue?.enabled; (cur === 'on' || cur === 'off') && state(on ? 'on' : 'off'); }
    (c.drafts || c.cfg) && chrome.storage.local.get(['drafts', 'cfg']).then(r => load(r.drafts, r.cfg));
  });
  setInterval(() => drafts.length && load(drafts), 600000); // drop drafts older than a day
  setTimeout(() => ready || state('wait'), 90000); // nothing heard from WhatsApp
  document.documentElement.appendChild(host);
})();
