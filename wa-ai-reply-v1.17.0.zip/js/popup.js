/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
import { getCfg, today, ready } from './cfg.js';
import { $, esc, bg, toast, busy, ago, logHtml, pausedHtml, connState, openWa, ENGINE } from './ui.js';
import { licState, PLANS_URL } from './license.js';
import { startLanguage } from './translate.js';

const safeRenew = s => !s.trial && /^https:\/\//i.test(s.renew || '') ? s.renew : PLANS_URL; // trial: the plans page

// licence not active (or ending soon): one line + a way to fix it
const licPaint = async () => {
  const s = await licState(), soon = s.ok && s.days != null && s.days < 7;
  document.body.classList.toggle('lic-locked', !s.ok);   // locked: the popup shows only this card
  $('licCard').hidden = s.ok && !soon;
  if ($('licCard').hidden) return s;
  $('licLine').className = `lic-banner ${s.ok ? 'warn' : 'bad'}`;
  $('licLine').innerHTML = `<i class="fa-solid fa-key"></i><div><b>${s.ok ? (s.trial ? `Free trial ends in ${Math.max(0, Math.ceil((s.exp - Date.now()) / 36e5))} hours` : `Licence ends in ${s.days < 1 ? 'less than a day' : `${s.days} days`}`) : s.trial && s.state === 'expired' ? 'Free trial ended: add a licence key' : s.state === 'none' ? 'WA AI Reply is locked: sign in with Google for the free trial, or add a key' : 'WA AI Reply is locked'}</b>
    <span>${esc(s.ok ? (s.trial ? 'Add a licence key so replies do not stop.' : 'Renew it so replies do not stop.') : s.trial ? 'The bot stays off until a key is active.' : s.msg || 'The bot needs an active key to reply.')}</span></div><button class="btn btn-primary btn-sm" data-open="license">Open</button>
    <button class="btn btn-sm btn-secondary" data-buy><i class="fa-solid fa-cart-shopping"></i> ${s.ok && !s.trial ? 'Renew' : 'Get a key'}</button>`;
  $('licLine').querySelector('[data-open]').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('options.html#license') });
  $('licLine').querySelector('[data-buy]').onclick = () => chrome.tabs.create({ url: safeRenew(s) });
  return s;
};

// Google sign-in + Sheet: who is signed in, is the Sheet saving
const gPaint = async () => {
  const { gAcct, gsync = {} } = await chrome.storage.local.get(['gAcct', 'gsync']);
  const lic = () => chrome.tabs.create({ url: chrome.runtime.getURL('options.html#license') });
  if (!gAcct?.email) {
    $('gPopAcct').innerHTML = `<span class="g-pop-ic off"><i class="fa-brands fa-google"></i></span><div><b>Google not connected</b><span>Sign in to save your data in Google Sheets</span></div><button class="btn btn-primary btn-sm" id="gPopGo">Sign in</button>`;
    $('gPopSheet').hidden = true;
    $('gPopGo').onclick = lic;
    return;
  }
  const bad = !!gsync.err, login = gsync.kind === 'login';
  $('gPopAcct').innerHTML = `<span class="g-pop-ic"><i class="fa-brands fa-google"></i></span><div><b>Signed in with Google</b><span>${esc(gAcct.email)}</span></div><span class="g-pop-ok" title="Signed in"><i class="fa-solid fa-circle-check"></i></span>`;
  $('gPopSheet').hidden = false;
  $('gPopSheet').innerHTML = `<span class="g-pop-ic sheet${bad ? ' bad' : ''}"><i class="fa-solid fa-table-cells"></i></span>
    <div><b>${!gsync.sheet ? 'Google Sheet not made yet' : bad ? 'Google Sheet not saving' : 'Google Sheet connected'}</b><span>${esc(bad ? (login ? 'Sign-in expired: sign in again' : gsync.err) : gsync.last ? `Saved ${ago(new Date(gsync.last).toISOString())}` : 'Saving soon')}</span></div>
    ${bad ? '<button class="btn btn-primary btn-sm" id="gPopFix">Fix</button>' : gsync.url ? '<button class="nav-btn" id="gPopOpen" aria-label="Open Google Sheet" title="Open Google Sheet"><i class="fa-solid fa-arrow-up-right-from-square"></i></button>' : ''}`;
  $('gPopFix') && ($('gPopFix').onclick = lic);
  $('gPopOpen') && ($('gPopOpen').onclick = () => /^https:\/\/docs\.google\.com\//.test(gsync.url) && chrome.tabs.create({ url: gsync.url }));
};

const conn = async () => {
  const [cls, txt] = await connState();
  $('conn').innerHTML = `<span class="dot ${cls}"></span><span>${esc(txt)}</span>`;
};

const render = async () => {
  const cfg = await getCfg();
  const { stats, log = [], paused = {} } = await chrome.storage.local.get(['stats', 'log', 'paused']);
  const st = stats?.day === today() ? stats : {};
  $('enabled').checked = cfg.enabled;
  $('engineLine').textContent = `AI: ${ENGINE[cfg.engine] || 'Claude'}`;
  $('whyOff').textContent = ready(cfg) ? (cfg.enabled ? 'Replying to new WhatsApp messages' : 'Turn on to start replying') : 'Add an API key in Settings first';
  [['sSent', 'sent'], ['sHuman', 'human'], ['sSkip', 'skip'], ['sError', 'error']].forEach(([id, k]) => $(id).textContent = st[k] || 0);
  $('pausedCard').hidden = !Object.values(paused).some(t => t > Date.now());
  $('paused').innerHTML = pausedHtml(paused, log);
  $('log').innerHTML = logHtml(log, 15);
  // replies waiting for my Send
  const { drafts: dl = [] } = await chrome.storage.local.get('drafts'), drafts = dl.filter(d => Date.now() - new Date(d.at) < 864e5);
  $('draftCard').hidden = !drafts.length;
  $('drafts').innerHTML = drafts.slice(0, 5).map(d => `<div class="item"><div class="head"><span class="name">${esc(d.name || d.phone || 'Customer')}</span><time>${ago(d.at)}</time></div>
    <p><i class="fa-solid fa-arrow-up"></i> ${esc(d.text)}</p>
    <div class="btn-row"><button class="btn btn-primary btn-sm" data-dsend="${esc(d.id)}"><i class="fa-solid fa-paper-plane"></i> Send</button><button class="btn btn-secondary btn-sm" data-dskip="${esc(d.id)}"><i class="fa-solid fa-forward"></i> Skip</button></div></div>`).join('')
    + (drafts.length > 5 ? `<span class="sub">${drafts.length - 5} more on the Dashboard</span>` : '');
};
$('drafts').addEventListener('click', async e => {
  const s = e.target.closest('[data-dsend]'), k = e.target.closest('[data-dskip]'), b = s || k;
  if (!b) return;
  busy(b, true);
  const r = await bg(s ? { type: 'draftSend', id: s.dataset.dsend } : { type: 'draftSkip', id: k.dataset.dskip });
  busy(b, false);
  r.ok === false ? toast(r.err, true) : toast(s ? 'Sent' : 'Skipped');
});

$('enabled').addEventListener('change', async e => {
  const cfg = await getCfg();
  if (e.target.checked && !(await licState()).ok) {
    e.target.checked = false;
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html#license') });
    return toast('Activate your licence key first', true);
  }
  if (e.target.checked && (!ready(cfg) || !cfg.consent)) {
    e.target.checked = false;
    if (!ready(cfg)) return toast('Add an API key in Settings first', true);
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html#dashboard') });
    return toast('Agree to the notice on the Dashboard first', true); // consent lives on the bot switch there
  }
  await bg({ type: 'toggle' });
  toast(e.target.checked ? 'Auto-reply is ON' : 'Auto-reply is OFF');
});
$('paused').addEventListener('click', async e => {
  const b = e.target.closest('[data-resume]');
  if (!b) return;
  busy(b, true);
  await bg({ type: 'resume', chatId: b.dataset.resume });
  toast('Chat resumed');
});
document.querySelectorAll('[data-open]').forEach(b => b.onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL(`options.html#${b.dataset.open}`) }));
$('openWa').onclick = openWa;

chrome.storage.onChanged.addListener(c => {
  (c.cfg || c.stats || c.log || c.paused || c.drafts) && render();
  c.lic && licPaint();
gPaint();
  (c.gAcct || c.gsync) && gPaint();
  c.status && conn();
});
render();
conn();
licPaint();
startLanguage();
