/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
export const DEFAULTS = {
  enabled: false,
  engine: 'claude', // claude | openai | gemini | grok | webhook
  claudeKey: '', claudeModel: 'claude-opus-5-5',
  openaiKey: '', openaiModel: 'gpt-4.1-mini',
  geminiKey: '', geminiModel: 'gemini-3.6-flash',
  grokKey: '', grokModel: 'grok-4.3',
  prompt: 'You are the WhatsApp assistant for Demo Store.\nWe sell demo products. Shop hours: 10am to 9pm, Monday to Saturday.\nDelivery all over the country in 2-4 days. Payment: cash on delivery or bank transfer.\nBe friendly and short. Ask for name and address when someone wants to order.',
  mcpOn: false, mcpLabel: 'business', mcpUrl: '', mcpToken: '', mcpTools: '',
  hookUrl: '', hookSecret: '',
  groups: false,
  delayMin: 3, delayMax: 8,
  typingWait: true, // hold the reply while the customer is still typing
  history: 12,
  humanPause: 30, // min
  hourCap: 20,
  hoursOn: false, hoursFrom: '09:00', hoursTo: '21:00',
  allow: '', block: '',
  // safety
  dayCap: 300, minuteCap: 6, maxAge: 10, errStop: 5,
  savedOnly: false, markRead: true, noLinks: true, footer: '',
  stopWords: 'stop, unsubscribe, band karo, mat bhejo',
  stopReply: 'Okay, you will not get automatic replies anymore. Our team can still reply to you here.',
  // quick replies
  qrOn: true, qrLearn: true, qrCode: true,
  // voice + photos
  voiceOn: true, voiceVia: 'auto', // auto | gemini | openai
  photoOn: true,
  payAck: 'Thank you, we got your payment screenshot. Our team will check it and confirm shortly.',
  // orders
  ordersOn: true, orderFields: 'name, phone, city, address, items', orderHook: '',
  orderMsg: 'Your order {no} is confirmed ✅\n{items}\nTotal: Rs {total}\nWe will deliver to {address}, {city}. Thank you, {name}!',
  // appointments: the AI books only into free times it was given
  bookOn: false, bookWhat: 'appointment', bookDays: 'mon,tue,wed,thu,fri,sat', bookFrom: '10:00', bookTo: '18:00', bookSlot: 30, bookCap: 1, bookAhead: 14, bookBreak: '',
  bookFields: 'name, phone, service',
  bookMsg: 'Your {what} is booked ✅\n{date} at {time}\n{service}\nSee you then, {name}!',
  bookRemind: true, bookRemindMsg: 'Reminder: your {what} is {when} at {time}. Reply here if you need to change it.',
  // alerts
  alertOn: true, alertSound: true,
  // look
  shape: 'rounded', // rounded | squared
  // easy setup
  setupDone: false,
  // sending (Chrome Web Store: the user confirms content + recipient)
  consent: false, reviewPanel: true, qrAuto: false, autoNums: '',
  autoSend: false, // direct build only: AI replies go without review
  // customer memory: notes from older chats + past orders
  memoryOn: true, memoryDepth: 300,
  // monthly AI budget (USD)
  budgetOn: false, budget: 10, priceIn: 0, priceOut: 0, fxCode: '', fxRate: 0,
  // how it writes
  replyLen: 'medium', // short | medium | long
  emoji: 'some', // none | some | match
  useName: true, replyLang: '', creativity: 'normal', // low | normal | high
  agentName: '', intro: '', avoidWords: '', useWords: '',
  noRepeat: true, // never the same reply twice in a chat
  qrStyle: 'exact', // exact | personal: saved replies sent word for word, or rewritten for the customer
  // knowledge base + learning from my own answers
  kbOn: true, kbLearn: true,
  bizMode: '', // form | text, '' = decide from the saved text
  bizType: 'shop', bizName: '', bizAbout: '', bizProducts: '', bizHours: '', bizAddress: '', bizDelivery: '', bizPayment: '',
  bizReturns: '', bizOrder: '', bizTone: 'friendly and short', bizExtra: ''
};

// business types: label, icon, products label, placeholders, extra rules for the AI
export const BIZ = {
  shop: { label: 'Shop', ic: 'fa-shop', products: 'Products and prices', ph: 'Rice 5 kg: Rs 1,500\nCooking oil 1 L: Rs 650', rules: ['If you are not sure something is in stock, say you will check.'] },
  restaurant: { label: 'Restaurant', ic: 'fa-utensils', products: 'Menu and prices', ph: 'Chicken biryani: Rs 450\nZinger burger: Rs 550', rules: ['For delivery orders ask for the items, quantity, address and phone, and say how long delivery takes.'] },
  clinic: { label: 'Clinic', ic: 'fa-stethoscope', products: 'Services, doctors and fees', ph: 'General check-up: Rs 1,000\nDr. Demo (Mon to Fri, 5 to 9 pm)', rules: ['Never give medical advice, a diagnosis or medicine names.', 'If someone mentions pain, bleeding, breathing trouble or an emergency, tell them to go to the nearest hospital now, then reply with exactly: [HUMAN]', 'Help book appointments: name, phone, preferred day and time.'] },
  salon: { label: 'Salon', ic: 'fa-scissors', products: 'Services and prices', ph: 'Haircut: Rs 800\nFacial: Rs 2,500', rules: ['Help book appointments: service, day, time and name.'] },
  online: { label: 'Online store', ic: 'fa-cart-shopping', products: 'Products and prices', ph: 'T-shirt (S, M, L): Rs 1,200\nHoodie: Rs 2,800', rules: ['Share delivery charges and time when someone wants to order.'] },
  property: { label: 'Property', ic: 'fa-house', products: 'Properties and prices', ph: '5 marla house, Demo Town: Rs 1.5 crore\n2 bed flat for rent: Rs 45,000 a month', rules: ['Never agree a price or a deal. Collect name, budget, area and a good time to visit, then reply with exactly: [HUMAN] when they want to negotiate.'] },
  pharmacy: { label: 'Pharmacy', ic: 'fa-prescription-bottle-medical', products: 'Items and prices', ph: 'Paracetamol 500 mg (10 tabs): Rs 50\nDigital thermometer: Rs 900', rules: ['Never suggest a medicine, a dose or a substitute. Only say whether an item is listed and its price.', 'Prescription items need a prescription: ask them to send a photo of it, then reply with exactly: [HUMAN]', 'If someone describes an emergency, tell them to go to the nearest hospital now, then reply with exactly: [HUMAN]'] },
  electronics: { label: 'Electronics', ic: 'fa-mobile-screen', products: 'Products and prices', ph: 'Demo Phone 128 GB: Rs 85,000\nWireless earbuds: Rs 4,500', rules: ['Ask for the exact model, variant and colour before quoting a price.', 'Mention warranty and PTA / tax status only as written in the business info.'] },
  grocery: { label: 'Grocery', ic: 'fa-basket-shopping', products: 'Items and prices', ph: 'Rice 5 kg: Rs 1,500\nEggs (dozen): Rs 350', rules: ['Take the shopping list with quantities and read it back. Delivery area and minimum order only as written.'] },
  bakery: { label: 'Bakery', ic: 'fa-cake-candles', products: 'Items and prices', ph: 'Chocolate cake 1 kg: Rs 2,200\nCupcakes (6): Rs 900', rules: ['For cakes ask the flavour, size, date and time needed, and any message on the cake. Lead time only as written.'] },
  gym: { label: 'Gym', ic: 'fa-dumbbell', products: 'Plans and fees', ph: 'Monthly: Rs 5,000\nQuarterly: Rs 13,500', rules: ['Share plans and timings. Book a free trial or visit: name, phone and a preferred time. Never give diet or medical advice.'] },
  education: { label: 'Education', ic: 'fa-graduation-cap', products: 'Classes and fees', ph: 'O Level Maths (Mon, Wed, Fri 5-6 pm): Rs 8,000 a month\nIELTS 6 weeks: Rs 25,000', rules: ['For admission collect the student name, class or level, phone and preferred timing. Never promise grades or results.'] },
  travel: { label: 'Travel', ic: 'fa-plane', products: 'Packages and prices', ph: 'Umrah 15 days: Rs 350,000\nDubai 4 nights: Rs 180,000', rules: ['Never confirm a seat, a visa or a date. Collect destination, dates, number of travellers and phone, then reply with exactly: [HUMAN] when they want to book or pay.'] },
  hotel: { label: 'Hotel', ic: 'fa-hotel', products: 'Rooms and rates', ph: 'Deluxe room: Rs 9,000 a night\nFamily suite: Rs 15,000 a night', rules: ['Collect check-in and check-out dates, guests and room type. Never confirm availability unless the business info says so; reply with exactly: [HUMAN] to confirm a booking.'] },
  auto: { label: 'Auto', ic: 'fa-car', products: 'Services, parts and prices', ph: 'Oil change (with filter): Rs 3,500\nAC service: Rs 4,000', rules: ['Ask the car make, model, year and the problem. Never diagnose or quote a repair cost that is not in the business info; offer a visit or a call instead.'] },
  tailor: { label: 'Tailor', ic: 'fa-shirt', products: 'Services and prices', ph: 'Shalwar kameez stitching: Rs 2,500\n3-piece suit: Rs 12,000', rules: ['Ask what to stitch, the fabric, measurements or a sample and the date needed. Stitching time only as written.'] },
  services: { label: 'Home services', ic: 'fa-screwdriver-wrench', products: 'Services and charges', ph: 'AC service: Rs 3,000\nPlumber visit: Rs 1,500 + parts', rules: ['Collect the area, the problem, a preferred time and phone. Visit charge only as written; never quote a repair cost before the visit.'] },
  freelancer: { label: 'Freelancer', ic: 'fa-laptop-code', products: 'Services and prices', ph: 'Logo design: Rs 8,000\n5-page website: Rs 60,000', rules: ['Collect what they need, the deadline and the budget. Never promise a delivery date or a custom price that is not written; reply with exactly: [HUMAN] for custom quotes.'] },
  courier: { label: 'Courier', ic: 'fa-truck-fast', products: 'Services and rates', ph: 'Within city (up to 1 kg): Rs 150\nNationwide (up to 1 kg): Rs 300', rules: ['Collect the pickup and delivery cities, the weight and what is being sent. Rates only as written. Tracking only from your tools or the business info, never guessed.'] },
  events: { label: 'Events', ic: 'fa-champagne-glasses', products: 'Packages and prices', ph: 'Wedding photography (1 day): Rs 80,000\nBirthday decor: Rs 25,000', rules: ['Collect the event type, date, venue and number of guests. Packages only as written; reply with exactly: [HUMAN] for custom pricing or to confirm a date.'] },
  legal: { label: 'Legal', ic: 'fa-scale-balanced', products: 'Services and fees', ph: 'Consultation (30 min): Rs 5,000\nAgreement drafting: from Rs 15,000', rules: ['Never give legal advice or predict an outcome. Book a consultation: name, phone, the type of matter and a preferred time.'] },
  other: { label: 'Other', ic: 'fa-briefcase', products: 'Products or services and prices', ph: 'Service A: Rs 2,000\nService B: Rs 3,500', rules: [] }
};
// creativity → model temperature
export const TEMPS = { low: 0.3, normal: 0.7, high: 1 };
export const TONES = { 'friendly and short': 'Friendly', 'polite and formal': 'Formal', 'friendly, in Roman Urdu when the customer writes Urdu': 'Roman Urdu' };

// form fields → the text the AI reads
export const buildPrompt = c => {
  const t = BIZ[c.bizType] || BIZ.other, v = x => String(x || '').trim();
  const line = (k, x) => v(x) ? `${k}: ${v(x)}` : '';
  return [
    `You are the WhatsApp assistant for ${v(c.bizName) || 'our business'}${c.bizType !== 'other' ? ` (${t.label.toLowerCase()})` : ''}.`,
    line('About us', c.bizAbout), v(c.bizProducts) ? `${t.products}:\n${v(c.bizProducts)}` : '',
    line('Timings', c.bizHours), line('Address', c.bizAddress), line('Delivery', c.bizDelivery), line('Payment', c.bizPayment),
    line('Returns and refunds', c.bizReturns), line('To order or book, ask for', c.bizOrder), line('More', c.bizExtra),
    `Tone: ${v(c.bizTone) || 'friendly and short'}.`, ...t.rules
  ].filter(Boolean).join('\n');
};

// demo business for testing, set #n, by type
const DEMO_HOURS = ['10am to 9pm, Monday to Saturday. Sunday closed', '9am to 6pm, every day', '11am to 11pm, Monday to Sunday'];
const DEMO_DELIVERY = ['All over the country in 2-4 days, Rs 200, free above Rs 5,000', 'Demo City same day, Rs 150', 'Pickup only from the shop'];
const DEMO_PAY = ['Cash on delivery or bank transfer', 'Bank transfer or mobile wallet', 'Cash at the counter or card'];
export const bizDemo = (type, n) => {
  const t = BIZ[type] || BIZ.other, i = (n - 1) % 3;
  return { bizType: BIZ[type] ? type : 'other', bizName: `Demo ${t.label} ${n}`, bizAbout: `${t.label} in Demo City`, bizProducts: t.ph,
    bizHours: DEMO_HOURS[i], bizAddress: `House ${n}, Street ${n}, Demo City`, bizDelivery: DEMO_DELIVERY[i], bizPayment: DEMO_PAY[i],
    bizReturns: 'Unused items within 7 days with the receipt', bizOrder: 'Name, full address, phone and the items' };
};
export const demoSeq = key => { let n = 1; try { n = (+localStorage.getItem(`rsDemoSeq_${key}`) || 0) + 1; localStorage.setItem(`rsDemoSeq_${key}`, n); } catch {} return n; };

// safety presets → the numbers they set
export const PRESETS = {
  careful: { label: 'Careful', note: 'New number or first weeks', ic: 'fa-shield-heart', set: { delayMin: 5, delayMax: 12, minuteCap: 3, dayCap: 150, hourCap: 10, humanPause: 60, maxAge: 10 } },
  normal: { label: 'Normal', note: 'Most businesses', ic: 'fa-shield-halved', set: { delayMin: 3, delayMax: 8, minuteCap: 6, dayCap: 300, hourCap: 20, humanPause: 30, maxAge: 10 } },
  busy: { label: 'Busy', note: 'Old number, many chats', ic: 'fa-bolt', set: { delayMin: 2, delayMax: 6, minuteCap: 10, dayCap: 600, hourCap: 30, humanPause: 20, maxAge: 15 } }
};
export const presetOf = c => Object.keys(PRESETS).find(k => Object.entries(PRESETS[k].set).every(([f, n]) => +c[f] === n)) || 'custom';

// field that must be filled per engine
export const NEEDS = { claude: 'claudeKey', openai: 'openaiKey', gemini: 'geminiKey', grok: 'grokKey', webhook: 'hookUrl' };
export const ready = cfg => !!String(cfg[NEEDS[cfg.engine]] || '').trim();

export const getCfg = async () => ({ ...DEFAULTS, ...(await chrome.storage.local.get('cfg')).cfg });
export const setCfg = async patch => chrome.storage.local.set({ cfg: { ...(await getCfg()), ...patch } });

// numbers list → digits set
export const numList = s => new Set(String(s || '').split(/[\s,;]+/).map(n => n.replace(/\D/g, '')).filter(Boolean));
export const today = () => new Date().toISOString().slice(0, 10);

// usual price, USD per 1M tokens [input, output]; Claude from Anthropic's list, others may be out of date
export const PRICES = [
  [/^claude-opus-5-5/, 4, 20], [/^claude-opus-(5|4)/, 5, 25], [/^claude-sonnet-5/, 2, 10], [/^claude-sonnet-4/, 3, 15],
  [/^claude-haiku-5/, 0.1, 0.5], [/^claude-haiku-4/, 1, 5], [/^claude-(fable|mythos)/, 10, 50],
  [/^gpt-4\.1-nano/, 0.1, 0.4], [/^gpt-4\.1-mini/, 0.4, 1.6], [/^gpt-4\.1/, 2, 8], [/^gpt-5-nano/, 0.05, 0.4], [/^gpt-5-mini/, 0.25, 2], [/^gpt-5/, 1.25, 10],
  [/^gpt-4o-mini/, 0.15, 0.6], [/^gpt-4o/, 2.5, 10],
  [/^gemini-.*flash-lite/, 0.1, 0.4], [/^gemini-.*flash/, 0.3, 2.5], [/^gemini-.*pro/, 1.25, 10],
  [/^grok/, 3, 15]
];
export const usualPrice = model => { const p = PRICES.find(([rx]) => rx.test(model || '')); return p ? [p[1], p[2]] : null; };
// own price wins when set
export const priceFor = (c, model) => (+c.priceIn > 0 || +c.priceOut > 0) ? [+c.priceIn || 0, +c.priceOut || 0] : usualPrice(model);
export const month = () => new Date().toISOString().slice(0, 7);
export const money = (usd, c) => `$${(+usd || 0).toFixed(2)}${c?.fxCode && +c.fxRate > 0 ? ` · ${c.fxCode} ${Math.round(usd * c.fxRate).toLocaleString('en-US')}` : ''}`;
