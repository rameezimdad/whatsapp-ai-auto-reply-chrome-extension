/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// quick replies page
import { $, esc, bg, toast, busy, ago, waFormat, confirmBox, parseCSV, toCSV, download } from './ui.js';

let list = [], sugs = [], editId = null, fromSug = -1, pend = []; // pend = files in the open editor
const picked = new Set(); // ticked in the list, for many at once
const MAX_MB = 10, MAX_FILES = 5;
const OK_TYPE = /^(image\/|video\/mp4$|application\/pdf$|text\/(plain|csv)$|application\/(msword|vnd\.openxmlformats-officedocument\.|vnd\.ms-(excel|powerpoint)))/;
const fileIc = m => m.startsWith('image/') ? 'fa-file-image' : m.startsWith('video/') ? 'fa-file-video' : m === 'application/pdf' ? 'fa-file-pdf'
  : /word/.test(m) ? 'fa-file-word' : /excel|sheet|csv/.test(m) ? 'fa-file-excel' : /powerpoint|presentation/.test(m) ? 'fa-file-powerpoint' : 'fa-file-lines';
const size = b => b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`;
// Maps link / "lat, lng" → {lat, lng}; null = empty, false = unreadable
const parseLoc = s => {
  s = s.trim();
  if (!s) return null;
  const m = s.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/) || s.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/)
    || s.match(/[?&](?:q|ll|query|destination|center)=(-?\d+\.\d+)(?:,|%2C)\s*(-?\d+\.\d+)/i) || s.match(/^(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)$/);
  return m && Math.abs(+m[1]) <= 90 && Math.abs(+m[2]) <= 180 ? { lat: +m[1], lng: +m[2] } : false;
};
const lines = s => s.split('\n').map(x => x.trim()).filter(Boolean);
const COLS = ['code', 'message', 'when', 'examples'];

const ex = q => q.examples?.length
  ? `<div class="qr-ex">${q.examples.slice(0, 4).map(e => `<span title="${esc(e)}">${esc(e)}</span>`).join('')}${q.examples.length > 4 ? `<span>+${q.examples.length - 4} more</span>` : ''}</div>` : '';

const card = (q, i, sug) => `<div class="qr-item${q.on === false ? ' off' : ''}${sug ? '' : ' pickable'}">
  ${sug ? '' : `<input type="checkbox" class="qr-pick" data-pick="${esc(q.id)}" ${picked.has(q.id) ? 'checked' : ''} aria-label="Select /${esc(q.code)}">`}
  <div class="qr-main">
    <div class="qr-top"><span class="qr-code">/${esc(q.code)}</span>${q.when ? `<span class="qr-when">${esc(q.when)}</span>` : ''}</div>
    <div class="qr-text">${waFormat(q.text)}</div>
    ${ex(q)}
    ${sug ? '' : `<div class="qr-meta">${q.files?.length ? `<span><i class="fa-solid fa-paperclip"></i>${q.files.length} ${q.files.length === 1 ? 'file' : 'files'}</span>` : ''}${q.loc ? '<span><i class="fa-solid fa-location-dot"></i>Map pin</span>' : ''}<span><i class="fa-solid fa-paper-plane"></i>Used ${q.uses || 0} ${q.uses === 1 ? 'time' : 'times'}</span>${q.learned ? `<span class="learned"><i class="fa-solid fa-graduation-cap"></i>Learned from ${q.learned} of your replies</span>` : ''}${q.lastAt ? `<span><i class="fa-regular fa-clock"></i>Last used ${ago(q.lastAt)}</span>` : ''}</div>`}
  </div>
  <div class="qr-act">${sug
    ? `<button class="btn btn-secondary btn-sm" data-sug-edit="${i}"><i class="fa-solid fa-pen"></i> Edit</button>
       <button class="btn btn-primary btn-sm" data-sug-add="${i}"><i class="fa-solid fa-plus"></i> Add</button>
       <button class="nav-btn" data-sug-drop="${i}" aria-label="Dismiss" title="Dismiss"><i class="fa-solid fa-xmark"></i></button>`
    : `<input type="checkbox" class="toggle" data-on="${esc(q.id)}" ${q.on === false ? '' : 'checked'} aria-label="Use /${esc(q.code)}" title="${q.on === false ? 'Off' : 'On'}">
       <button class="btn btn-secondary btn-sm" data-edit="${esc(q.id)}" aria-label="Edit /${esc(q.code)}"><i class="fa-solid fa-pen"></i> Edit</button>
       <button class="btn btn-secondary btn-sm del" data-del="${esc(q.id)}" aria-label="Delete /${esc(q.code)}"><i class="fa-solid fa-trash"></i> Delete</button>`}
  </div></div>`;

const render = () => {
  const k = $('qrSearch').value.trim().toLowerCase();
  const rows = k ? list.filter(q => `${q.code} ${q.text} ${q.when} ${(q.examples || []).join(' ')}`.toLowerCase().includes(k)) : list;
  $('qrCount').textContent = list.length;
  $('qrList').innerHTML = rows.map((q, i) => card(q, i)).join('') || (list.length
    ? `<div class="empty"><i class="fa-solid fa-magnifying-glass"></i><b>No match</b>Nothing has "${esc(k)}" in it.</div>`
    : `<div class="empty"><i class="fa-solid fa-bolt"></i><b>No quick replies yet</b>Save answers you send again and again, like prices, location or bank details.<br>
       <span class="btn-row empty-acts"><button class="btn btn-primary" data-first><i class="fa-solid fa-plus"></i> Add the first one</button>
       <button class="btn btn-secondary" data-demo="rs"><i class="fa-solid fa-flask"></i> Rameez Scripts demo</button>
       <button class="btn btn-secondary" data-demo="shop"><i class="fa-solid fa-store"></i> Shop demo</button></span></div>`);
  paintPick(rows);
  $('qrSuggest').hidden = !sugs.length;
  $('qrSuggestList').innerHTML = sugs.map((q, i) => card(q, i, true)).join('');
};

const load = async () => {
  list = (await chrome.storage.local.get('qr')).qr || [];
  [...picked].forEach(id => list.some(q => q.id === id) || picked.delete(id));   // deleted ones drop out
  render();
};

// many at once: tick, then on / off / delete
const paintPick = rows => {
  $('qrBulk').hidden = !list.length;
  $('qrSel').textContent = picked.size;
  $('qrPickAll').checked = !!rows?.length && rows.every(q => picked.has(q.id));
  document.querySelectorAll('[data-qbulk]').forEach(b => { b.disabled = !picked.size; });
};
const shown = () => { const k = $('qrSearch').value.trim().toLowerCase(); return k ? list.filter(q => `${q.code} ${q.text} ${q.when} ${(q.examples || []).join(' ')}`.toLowerCase().includes(k)) : list; };
$('qrPickAll').addEventListener('change', e => { shown().forEach(q => e.target.checked ? picked.add(q.id) : picked.delete(q.id)); render(); });
document.querySelectorAll('[data-qbulk]').forEach(b => b.addEventListener('click', async () => {
  const act = b.dataset.qbulk, n = picked.size;
  if (!n) return;
  if (act === 'del' && !(await confirmBox(`Delete ${n} quick ${n === 1 ? 'reply' : 'replies'}?`, 'The bot stops using them. Their files are deleted too. This cannot be undone.'))) return;
  busy(b, true);
  try {
    const r = await bg({ type: 'qrMany', ids: [...picked], act });
    if (!r.ok) return toast(r.err, true);
    act === 'del' && picked.clear();
    toast(act === 'del' ? `${r.n} deleted` : `${r.n} turned ${act}`);
  } finally { busy(b, false); }
}));

// editor
const dlg = $('qrDlg'), f = $('qrForm');
const preview = () => {
  const code = f.code.value.trim(), text = f.text.value.trim(), exs = lines(f.examples.value);
  $('qrPrev').innerHTML = `<div class="bubble in${exs[0] ? '' : ' ghost'}">${esc(exs[0] || 'Customer question…')}</div>
    <div class="bubble out${text ? '' : ' ghost'}">${text ? waFormat(text) : 'Your saved reply shows here'}</div>
    ${pend.length ? `<div class="att">${pend.map(p => `<span><i class="fa-solid ${fileIc(p.mime)}"></i>${esc(p.name)}</span>`).join('')}</div>` : ''}
    ${parseLoc(f.loc.value) ? `<div class="att"><span><i class="fa-solid fa-location-dot"></i>${esc(f.locName.value.trim() || 'Map pin')}</span></div>` : ''}
    ${code ? `<div class="bubble note">Customer can also type <b>${esc(code)}</b> or <b>/${esc(code)}</b></div>` : ''}`;
  const loc = parseLoc(f.loc.value);
  $('qrLocHint').className = loc === false ? 'drop-err' : 'hint';
  $('qrLocHint').textContent = loc === false ? 'Could not read this. Open the place in Google Maps on a computer and copy the link from the address bar, or type the numbers like 31.5204, 74.3587.'
    : loc ? `Pin at ${loc.lat}, ${loc.lng}, sent after the message.` : 'Optional. Sent as a map pin after the message.';
  const need = [[code, 'Code'], [text, 'Message'], [f.when.value.trim(), 'When to use (helps the AI)'], [exs.length, 'At least one customer question (helps the AI)']];
  $('qrNeed').innerHTML = need.map(([ok, t]) => `<li class="${ok ? 'done' : ''}"><i class="fa-solid ${ok ? 'fa-circle-check' : 'fa-circle-exclamation'}"></i>${esc(t)}</li>`).join('');
};
const pane = p => {
  dlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  dlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const open = (q = {}, sugIdx = -1) => {
  editId = q.id || null;
  fromSug = sugIdx;
  f.code.value = q.code || '';
  f.text.value = q.text || '';
  f.when.value = q.when || '';
  f.examples.value = (q.examples || []).join('\n');
  f.loc.value = q.loc ? `${q.loc.lat}, ${q.loc.lng}` : '';
  f.locName.value = q.loc?.name || '';
  pend = (q.files || []).map(x => ({ ...x }));
  $('qrDropErr').hidden = true;
  drawFiles();
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  $('qrDlgTitle').innerHTML = `<i class="fa-solid fa-bolt"></i> ${editId ? `Edit /${esc(q.code)}` : 'Add quick reply'}`;
  pane('form');
  preview();
  dlg.showModal();
  f.code.focus();
};
f.addEventListener('input', e => { e.target.classList.remove('bad'); preview(); });
f.code.addEventListener('input', () => { f.code.value = f.code.value.toLowerCase().replace(/^\//, '').replace(/[^a-z0-9-]/g, '-'); });
dlg.addEventListener('click', e => {
  e.target.closest('[data-close]') && dlg.close();
  const t = e.target.closest('[data-pane]');
  t && pane(t.dataset.pane);
});
f.onsubmit = async e => {
  e.preventDefault();
  const loc = parseLoc(f.loc.value);
  const item = { id: editId, code: f.code.value, text: f.text.value, when: f.when.value, examples: lines(f.examples.value),
    files: pend.map(({ id, name, mime, size }) => ({ id, name, mime, size })), loc: loc ? { ...loc, name: f.locName.value.trim() } : null };
  const miss = [!item.text.trim() && f.text, !item.code.trim() && f.code].filter(Boolean);
  if (miss.length) { miss.forEach(x => x.classList.add('bad')); pane('form'); miss.at(-1).focus(); return toast('Code and message are both needed', true); }
  if (loc === false) { f.loc.classList.add('bad'); pane('form'); f.loc.focus(); return toast('The location could not be read', true); }
  busy($('qrSave'), true);
  const fresh = pend.filter(p => p.dataUrl);
  try {
    fresh.length && await chrome.storage.local.set(Object.fromEntries(fresh.map(p => [`qrf:${p.id}`, { name: p.name, mime: p.mime, dataUrl: p.dataUrl }])));
    const r = await bg({ type: 'qrPut', item: editId ? { ...list.find(q => q.id === editId), ...item } : item });
    if (!r.ok) { fresh.length && chrome.storage.local.remove(fresh.map(p => `qrf:${p.id}`)); f.code.classList.add('bad'); return toast(r.err, true); }
    fromSug >= 0 && sugs.splice(fromSug, 1);
    dlg.close();
    toast(editId ? `/${r.row.code} updated` : `/${r.row.code} saved`);
  } finally { busy($('qrSave'), false); }
};

// attachments
const drawFiles = () => {
  $('qrFileList').innerHTML = pend.map((p, i) => `<div class="file">
    ${p.dataUrl && p.mime.startsWith('image/') ? `<img class="th" src="${esc(p.dataUrl)}" alt="">` : `<span class="th"><i class="fa-solid ${fileIc(p.mime)}"></i></span>`}
    <div><b>${esc(p.name)}</b><small>${size(p.size)}</small></div>
    <button type="button" class="nav-btn" data-unfile="${i}" aria-label="Remove ${esc(p.name)}" title="Remove"><i class="fa-solid fa-xmark"></i></button></div>`).join('');
  preview();
};
const readUrl = file => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
const addFiles = async picked => {
  const err = [];
  for (const file of picked) {
    if (pend.length >= MAX_FILES) { err.push(`Only ${MAX_FILES} files per quick reply`); break; }
    if (!OK_TYPE.test(file.type)) { err.push(`${file.name}: this file type can't be sent`); continue; }
    if (file.size > MAX_MB * 1048576) { err.push(`${file.name}: bigger than ${MAX_MB} MB`); continue; }
    pend.push({ id: crypto.randomUUID(), name: file.name, mime: file.type, size: file.size, dataUrl: await readUrl(file) });
  }
  $('qrDropErr').hidden = !err.length;
  $('qrDropErr').textContent = err.join(' · ');
  drawFiles();
};
$('qrFilesIn').onchange = e => { addFiles([...e.target.files]); e.target.value = ''; };
['dragenter', 'dragover'].forEach(t => $('qrDrop').addEventListener(t, e => { e.preventDefault(); $('qrDrop').classList.add('over'); }));
['dragleave', 'drop'].forEach(t => $('qrDrop').addEventListener(t, () => $('qrDrop').classList.remove('over')));
$('qrDrop').addEventListener('drop', e => { e.preventDefault(); addFiles([...e.dataTransfer.files]); });
$('qrFileList').addEventListener('click', e => { const b = e.target.closest('[data-unfile]'); b && (pend.splice(+b.dataset.unfile, 1), drawFiles()); });

// demo record, set N+1 each click
$('qrDemo').onclick = () => {
  let n = 1;
  try { n = +localStorage.getItem('rsDemoSeq_qr') + 1 || 1; localStorage.setItem('rsDemoSeq_qr', n); } catch {}
  f.code.value = `demo-${n}`;
  f.text.value = `*Price list ${n}*\nProduct A: Rs ${(n * 1000).toLocaleString()}\nProduct B: Rs ${(n * 1500).toLocaleString()}\nDelivery all over the country in 2-4 days.`;
  f.when.value = 'Customer asks about prices or rates';
  f.examples.value = 'price kya hai?\nrate list bhej dein\nhow much is product A';
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  preview();
};

// list actions
$('qrAdd').onclick = () => open();
$('qrSearch').oninput = render;
$('qrList').addEventListener('click', async e => {
  if (e.target.closest('[data-first]')) return open();
  if (e.target.closest('[data-demo]')) return addDemo(e.target.closest('[data-demo]'), e.target.closest('[data-demo]').dataset.demo || 'rs');
  const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
  if (ed) return open(list.find(q => q.id === ed.dataset.edit));
  if (!del) return;
  const q = list.find(x => x.id === del.dataset.del);
  if (!(await confirmBox(`Delete /${q.code}?`, 'The bot will stop using this reply. This cannot be undone.'))) return;
  busy(del, true);
  await bg({ type: 'qrDel', id: q.id });
  toast(`/${q.code} deleted`);
});
$('qrList').addEventListener('change', async e => {
  const pk = e.target.closest('[data-pick]');
  if (pk) return void (pk.checked ? picked.add(pk.dataset.pick) : picked.delete(pk.dataset.pick), paintPick(shown()));
  const t = e.target.closest('[data-on]');
  if (!t) return;
  const q = list.find(x => x.id === t.dataset.on);
  t.disabled = true;
  const r = await bg({ type: 'qrPut', item: { ...q, on: t.checked } });
  r.ok ? toast(`/${q.code} ${t.checked ? 'on' : 'off'}`) : (t.checked = !t.checked, t.disabled = false, toast(r.err, true));
});

// AI suggestions from my chats
$('qrScan').onclick = async e => {
  const btn = e.currentTarget;
  busy(btn, true);
  toast('Reading your recent chats…');
  try {
    const r = await bg({ type: 'qrScan' });
    if (!r.ok) return toast(r.err, true);
    sugs = r.list;
    $('qrSuggestNote').textContent = sugs.length
      ? `From ${r.read} of your own replies. Check each one before adding; nothing is used until you add it.`
      : '';
    render();
    toast(sugs.length ? `${sugs.length} suggestions ready` : 'No new quick replies found in your chats', !sugs.length);
    sugs.length && $('qrSuggest').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } finally { busy(btn, false); }
};
$('qrSuggestList').addEventListener('click', async e => {
  const b = e.target.closest('[data-sug-add], [data-sug-edit], [data-sug-drop]');
  if (!b) return;
  const i = +(b.dataset.sugAdd ?? b.dataset.sugEdit ?? b.dataset.sugDrop);
  if (b.dataset.sugEdit !== undefined) return open(sugs[i], i);
  if (b.dataset.sugAdd !== undefined) {
    busy(b, true);
    const r = await bg({ type: 'qrPut', item: sugs[i] });
    if (!r.ok) { busy(b, false); return toast(r.err, true); }
    toast(`/${r.row.code} saved`);
  }
  sugs.splice(i, 1);
  render();
});
$('qrSuggestAll').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  const r = await bg({ type: 'qrBulk', items: sugs });
  busy(btn, false);
  if (!r.ok) return toast(r.err, true);
  sugs = [];
  render();
  toast(`${r.added} added${r.skipped ? `, ${r.skipped} skipped (code already used)` : ''}`);
};
$('qrSuggestClose').onclick = () => { sugs = []; render(); };

// demo set: price, location, bank, delivery, order, return
const addDemo = async (b, set = 'rs') => {
  busy(b, true);
  const r = await bg({ type: 'qrDemo', set });
  busy(b, false);
  if (!r.ok) return toast(r.err, true);
  if (r.added) return toast(`${r.added} ${set === 'shop' ? 'shop' : 'Rameez Scripts'} demo quick replies added`);
  toast('That demo set is already in your list');
  $('qrSearch').value = '';
  render();
};
$('qrDemoSet').onclick = e => addDemo(e.currentTarget);

// import from WhatsApp Business
$('qrFromWA').onclick = async e => {
  const btn = e.currentTarget;
  busy(btn, true);
  try {
    const r = await bg({ type: 'qrFromWA' });
    r.ok ? toast(`${r.added} imported${r.skipped ? `, ${r.skipped} skipped (code already used)` : ''}`) : toast(r.err, true);
  } finally { busy(btn, false); }
};

// csv
$('qrExport').onclick = () => list.length
  ? download('quick-replies.csv', toCSV([[...COLS, 'used'], ...list.map(q => [q.code, q.text, q.when, (q.examples || []).join(' | '), q.uses || 0])]))
  : toast('No quick replies to export yet', true);
$('qrTemplate').onclick = () => download('quick-replies-template.csv', toCSV([COLS, ['price', '*Price list*\nProduct A: Rs 1,000\nProduct B: Rs 1,500', 'Customer asks about prices', 'price kya hai? | rate list bhej dein']]));
$('qrImport').onclick = () => $('qrFile').click();
$('qrFile').onchange = async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const [head = [], ...rows] = parseCSV(await file.text());
  const ix = Object.fromEntries(COLS.map(c => [c, head.findIndex(h => h.trim().toLowerCase() === c)]));
  if (ix.code < 0 || ix.message < 0) return toast('The file needs "code" and "message" columns. Download the template.', true);
  const items = rows.map(r => ({ code: r[ix.code], text: r[ix.message], when: ix.when < 0 ? '' : r[ix.when], examples: ix.examples < 0 ? [] : String(r[ix.examples] || '').split('|') }));
  if (!items.length) return toast('The file has no rows', true);
  if (!(await confirmBox(`Import ${items.length} quick replies?`, 'Rows whose code already exists are skipped.', { ok: 'Import', danger: false }))) return;
  busy($('qrImport'), true);
  const r = await bg({ type: 'qrBulk', items });
  busy($('qrImport'), false);
  r.ok ? toast(`${r.added} imported${r.skipped ? `, ${r.skipped} skipped` : ''}`) : toast(r.err, true);
};

chrome.storage.onChanged.addListener(c => c.qr && load());
load();
