@echo off
rem Developed by Mohammad Rameez Imdad (Rameez Scripts)
rem WhatsApp: https://wa.me/923435347417 (For Custom Projects)
rem YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
rem WA AI Reply: look for a new version on GitHub every 6 hours and put it in this folder
title WA AI Reply - auto update
set "PS1=%~dp0auto-update.ps1"
schtasks /Create /F /TN "WA AI Reply Update" /SC HOURLY /MO 6 /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%PS1%\"" >nul
if errorlevel 1 (
  echo Auto update could not be turned on. Move the WA AI Reply folder to a short path like D:\WA AI Reply and try again.
  pause
  exit /b 1
)
echo Auto update is ON. WA AI Reply checks for a new version every 6 hours.
echo Checking now...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
type "%~dp0status.json" 2>nul
echo.
echo Done. You can close this window. To stop it, run "Turn off auto update.bat".
pause
