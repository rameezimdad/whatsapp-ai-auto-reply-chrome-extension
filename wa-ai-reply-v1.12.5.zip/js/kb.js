/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// knowledge page: facts the AI quotes, import / export, facts learned from my own answers
import { $, esc, bg, toast, busy, ago, waFormat, confirmBox, parseCSV, toCSV, download } from './ui.js';

let list = [], sugs = [], editId = null, fromSug = -1, queue = 0;
const dlg = $('kbDlg'), f = $('kbForm');

const card = (k, i, sug) => `<div class="qr-item${k.on === false ? ' off' : ''}">
  <div class="qr-main">
    <div class="qr-top"><span class="qr-code">${esc(k.title)}</span>${k.pinned ? '<span class="pill c-sent"><i class="fa-solid fa-thumbtack"></i> Always read</span>' : ''}${k.tags ? `<span class="qr-when">${esc(k.tags)}</span>` : ''}</div>
    <div class="qr-text">${waFormat(k.text)}</div>
    ${sug ? '' : `<div class="qr-meta">${k.learned ? '<span class="learned"><i class="fa-solid fa-graduation-cap"></i>From your own answers</span>' : ''}<span><i class="fa-regular fa-clock"></i>Added ${ago(new Date(k.at).toISOString())}</span></div>`}
  </div>
  <div class="qr-act">${sug
    ? `<button class="btn ghost sm" data-sug-edit="${i}"><i class="fa-solid fa-pen"></i> Edit</button>
       <button class="btn sm" data-sug-add="${i}"><i class="fa-solid fa-plus"></i> Add</button>
       <button class="nav-btn" data-sug-drop="${i}" aria-label="Dismiss" title="Dismiss"><i class="fa-solid fa-xmark"></i></button>`
    : `<input type="checkbox" class="toggle" data-on="${esc(k.id)}" ${k.on === false ? '' : 'checked'} aria-label="Use ${esc(k.title)}" title="${k.on === false ? 'Off' : 'On'}">
       <button class="nav-btn" data-pin="${esc(k.id)}" aria-label="${k.pinned ? 'Unpin' : 'Always read'}" title="${k.pinned ? 'Unpin' : 'Always read'}"><i class="fa-solid fa-thumbtack${k.pinned ? '' : ' dim'}"></i></button>
       <button class="nav-btn" data-edit="${esc(k.id)}" aria-label="Edit" title="Edit"><i class="fa-solid fa-pen"></i></button>
       <button class="nav-btn del" data-del="${esc(k.id)}" aria-label="Delete" title="Delete"><i class="fa-solid fa-trash"></i></button>`}
  </div>
</div>`;

const render = () => {
  const q = $('kbSearch').value.trim().toLowerCase();
  const rows = list.filter(k => !q || `${k.title} ${k.tags} ${k.text}`.toLowerCase().includes(q));
  $('kbCount').textContent = list.length;
  $('kbList').innerHTML = rows.length ? rows.map((k, i) => card(k, i, false)).join('')
    : `<div class="empty"><i class="fa-solid fa-book-open"></i><p>${q ? 'No fact matches that' : 'No facts yet. Add prices, policies and how things work, or let the AI learn them from your own answers.'}</p></div>`;
  $('kbSugs').innerHTML = sugs.map((k, i) => card(k, i, true)).join('');
  $('kbLearnQueue').disabled = queue < 3;
  $('kbLearnNote').textContent = sugs.length ? `${sugs.length} suggested ${sugs.length === 1 ? 'fact' : 'facts'}. Add the ones that are right.`
    : queue ? `${queue} of your own ${queue === 1 ? 'answer is' : 'answers are'} waiting${queue < 3 ? ', 3 needed' : ''}. Make facts turns them into entries you approve.`
    : 'Answer a few customers yourself, then press Make facts. Or read your recent chats now.';
  $('pillKb').hidden = queue < 3 && !sugs.length;
  $('pillKb').textContent = sugs.length || queue;
};
const load = async () => {
  const s = await chrome.storage.local.get(['kb', 'kbQueue']);
  list = s.kb || [];
  queue = (s.kbQueue || []).length;
  render();
};

// editor
const pane = p => {
  dlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  dlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const preview = () => {
  const t = f.title.value.trim(), x = f.text.value.trim();
  $('kbPreview').textContent = t || x ? `## ${t || 'Title'}\n${x || 'The fact'}` : '';
  $('kbPreviewNote').textContent = f.pinned.checked ? 'Pinned: goes with every reply.' : `Read when the customer's message shares words with the title, the tags or the text${f.tags.value.trim() ? '' : '. Add tags so it is found in more ways'}.`;
};
const open = (k = {}, sugIdx = -1) => {
  editId = k.id && sugIdx < 0 ? k.id : null;
  fromSug = sugIdx;
  f.title.value = k.title || '';
  f.text.value = k.text || '';
  f.tags.value = k.tags || '';
  f.pinned.checked = !!k.pinned;
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  $('kbDlgTitle').innerHTML = `<i class="fa-solid fa-book-open"></i> ${editId ? 'Edit fact' : 'Add fact'}`;
  pane('form');
  preview();
  dlg.showModal();
  setTimeout(() => f.title.focus(), 50);
};
dlg.addEventListener('click', e => {
  e.target.closest('[data-close]') && dlg.close();
  const t = e.target.closest('[data-pane]');
  t && pane(t.dataset.pane);
});
f.addEventListener('input', preview);
f.onsubmit = async e => {
  e.preventDefault();
  const miss = [f.title, f.text].filter(x => !x.value.trim());
  if (miss.length) { miss.forEach(x => x.classList.add('bad')); pane('form'); miss[0].focus(); return toast('A title and the text are both needed', true); }
  const btn = $('kbSave');
  busy(btn, true);
  try {
    const r = await bg({ type: 'kbPut', item: { id: editId, title: f.title.value, text: f.text.value, tags: f.tags.value, pinned: f.pinned.checked, learned: fromSug >= 0 } });
    if (!r.ok) return toast(r.err, true);
    fromSug >= 0 && sugs.splice(fromSug, 1);
    dlg.close();
    toast(editId ? 'Fact saved' : 'Fact added');
  } finally { busy(btn, false); }
};
$('kbAdd').onclick = () => open();
$('kbDemo').onclick = () => {
  const n = (+localStorage.getItem('rsDemoSeq_kb') || 0) + 1;
  try { localStorage.setItem('rsDemoSeq_kb', n); } catch {}
  const demo = [
    ['Delivery charges', 'Delivery is Rs 200 anywhere in the country, free on orders above Rs 5,000. Demo City same day, other cities 2-4 days.', 'delivery, shipping, charges, courier'],
    ['Return policy', 'Unused items can be returned within 7 days with the receipt. Refund by bank transfer within 3 working days.', 'return, refund, exchange, warranty'],
    ['Bank details', 'Bank transfer to Demo Bank, account title Demo Store, account 0000-1234567. Send the screenshot after paying.', 'payment, bank, account, transfer'],
    ['Opening hours', 'Open 10 am to 9 pm, Monday to Saturday. Sunday closed. Orders placed on Sunday ship Monday.', 'timing, hours, open, closed, sunday']
  ][(n - 1) % 4];
  f.title.value = `${demo[0]}${n > 4 ? ` ${n}` : ''}`; f.text.value = demo[1]; f.tags.value = demo[2];
  preview();
  toast(`Demo set #${n}`);
};

// list actions
$('kbList').addEventListener('click', async e => {
  const b = e.target.closest('[data-edit], [data-del], [data-pin]');
  if (!b) return;
  if (b.dataset.edit) return open(list.find(k => k.id === b.dataset.edit));
  if (b.dataset.pin) { const k = list.find(x => x.id === b.dataset.pin); return void (k && (await bg({ type: 'kbPut', item: { ...k, pinned: !k.pinned } }), toast(k.pinned ? 'Unpinned' : 'Pinned: read with every reply'))); }
  const k = list.find(x => x.id === b.dataset.del);
  if (!k || !(await confirmBox(`Delete "${k.title}"?`, 'The AI stops using this fact.'))) return;
  busy(b, true);
  await bg({ type: 'kbDel', ids: [k.id] });
  toast('Deleted');
});
$('kbList').addEventListener('change', async e => {
  const t = e.target.closest('[data-on]');
  if (!t) return;
  const k = list.find(x => x.id === t.dataset.on);
  k && await bg({ type: 'kbPut', item: { ...k, on: t.checked } });
});
$('kbSearch').addEventListener('input', render);

// suggestions from my own answers
$('kbSugs').addEventListener('click', async e => {
  const b = e.target.closest('[data-sug-edit], [data-sug-add], [data-sug-drop]');
  if (!b) return;
  const i = +(b.dataset.sugEdit ?? b.dataset.sugAdd ?? b.dataset.sugDrop);
  if (b.dataset.sugEdit != null) return open(sugs[i], i);
  if (b.dataset.sugDrop != null) { sugs.splice(i, 1); return render(); }
  busy(b, true);
  const r = await bg({ type: 'kbPut', item: { ...sugs[i], id: null, learned: true } });
  busy(b, false);
  if (!r.ok) return toast(r.err, true);
  sugs.splice(i, 1);
  render();
  toast('Fact added');
});
const learn = async (btn, source) => {
  busy(btn, true);
  try {
    const r = await bg({ type: 'kbScan', source });
    if (!r.ok) return toast(r.err, true);
    sugs = [...r.list, ...sugs].slice(0, 30);
    render();
    toast(r.list.length ? `${r.list.length} ${r.list.length === 1 ? 'fact' : 'facts'} found in ${r.read} of your answers` : `Read ${r.read} answers, nothing new to add`);
  } finally { busy(btn, false); }
};
$('kbLearnQueue').onclick = e => learn(e.currentTarget, 'queue');
$('kbLearnChats').onclick = e => learn(e.currentTarget, 'chats');

// import: .csv (title, text, tags) or .txt / .md (one fact per paragraph, first line = title)
$('kbImport').onclick = () => $('kbFile').click();
$('kbFile').onchange = async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const text = (await file.text()).replace(/\r\n?/g, '\n');
  let items = [];
  if (/\.csv$/i.test(file.name)) {
    const rows = parseCSV(text), head = rows[0].map(h => h.trim().toLowerCase());
    const ti = head.indexOf('title'), xi = head.indexOf('text'), gi = head.indexOf('tags');
    if (ti < 0 || xi < 0) return toast('The CSV needs title and text columns', true);
    items = rows.slice(1).map(r => ({ title: r[ti], text: r[xi], tags: gi >= 0 ? r[gi] : '' }));
  } else {
    items = text.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean).map(p => {
      const [first, ...rest] = p.split('\n'), title = first.replace(/^#+\s*|:$/g, '').trim();
      return rest.length ? { title, text: rest.join('\n').trim() } : { title: title.slice(0, 60), text: p };
    });
  }
  items = items.filter(i => i.title?.trim() && i.text?.trim());
  if (!items.length) return toast('No facts found in that file', true);
  if (!(await confirmBox(`Import ${items.length} ${items.length === 1 ? 'fact' : 'facts'}?`, 'Facts with a title that already exists are skipped.', { ok: 'Import', danger: false }))) return;
  const r = await bg({ type: 'kbBulk', items });
  toast(r.ok ? `${r.added} added, ${r.skipped} skipped` : r.err, !r.ok);
};
$('kbExport').onclick = () => {
  if (!list.length) return toast('No facts to export', true);
  download(`knowledge-${new Date().toISOString().slice(0, 10)}.csv`, toCSV([['title', 'text', 'tags', 'pinned', 'on'], ...list.map(k => [k.title, k.text, k.tags, k.pinned ? 1 : 0, k.on === false ? 0 : 1])]));
};

chrome.storage.onChanged.addListener(c => (c.kb || c.kbQueue) && load());
load();
