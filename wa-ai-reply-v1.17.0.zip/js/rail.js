/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// icon rail before paint (desktop only)
try { localStorage.getItem('waai_rail') === '1' && innerWidth > 768 && document.getElementById('sidebar').classList.add('collapsed'); } catch {}
