/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// look flags before first paint: shape (rounded default) · style · sidebar colour
(() => {
  const h = document.documentElement, g = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };
  h.dataset.shape = g('waai_shape', 'rounded');
  h.dataset.ui = g('waai_ui', 'soft');
  h.dataset.sb = g('waai_sb', 'navy');
  h.dataset.glass = 'frosted';
})();
