/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// page world: talks to WhatsApp via WPP, relays to content.js
(() => {
  const ORIGIN = location.origin;
  const post = (type, data = {}) => window.postMessage({ waai: 'page', type, ...data }, ORIGIN);
  const sid = w => w?._serialized || String(w || '');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const SKIP = /@(broadcast|newsletter)$/; // status + channels
  const KEEP = { chat: 1, image: 1, video: 1, document: 1, ptt: 1, audio: 1, sticker: 1, location: 1, vcard: 1 };
  const LABEL = { ptt: 'voice note', vcard: 'contact card' };
  const pending = new Map(); // chatId -> text bot is sending
  const files = new Map(); // chatId -> file / pin echoes still to come
  const MEDIA = { ptt: 'audio', audio: 'audio', image: 'image' };
  const textOf = m => ((m.type === 'chat' ? m.body : m.caption) || '').trim();

  const phoneOf = async id => {
    if (id.endsWith('@c.us')) return id.split('@')[0];
    try { return (await WPP.contact.getPnLidEntry(id))?.phoneNumber?.id || ''; } catch { return ''; }
  };
  const nameOf = (id, m) => WPP.chat.get(id)?.formattedTitle || m?.notifyName || id.split('@')[0];
  if (typeof WPP === 'undefined') return void post('status', { fail: 'lib' }); // library did not load
  const status = () => post('status', { auth: !!WPP.conn.isAuthenticated?.(), me: sid(WPP.conn.getMyUserId?.()), wpp: WPP.version || '', wa: window.Debug?.VERSION || '' });

  const onMsg = async m => {
    if (!m?.isNewMsg || !KEEP[m.type]) return;
    const id = sid(m.id?.remote);
    if (!id || SKIP.test(id)) return;
    const text = textOf(m);
    if (m.id.fromMe) { // own msg: bot echo or a real human reply
      if (text && pending.get(id) === text) return void pending.delete(id);
      if (!text && files.get(id) > 0) return void files.set(id, files.get(id) - 1);
      return post('human', { chatId: id, text, prev: await lastIn(id) });
    }
    const kind = MEDIA[m.type] || '';
    if (!text && !kind) return; // video, sticker, file without caption
    post('msg', {
      chatId: id, isGroup: id.endsWith('@g.us'), name: nameOf(id, m), phone: await phoneOf(id),
      t: m.t || 0, saved: !!WPP.chat.get(id)?.contact?.isMyContact, text, kind
    });
  };

  // last customer text in a chat
  const lastIn = async id => {
    try { const m = (await WPP.chat.getMessages(id, { count: 10 })).reverse().find(x => !x.id?.fromMe && KEEP[x.type]); return m ? textOf(m) : ''; }
    catch { return ''; }
  };

  // WhatsApp Business saved quick replies
  const qrList = () => {
    const s = WPP.whatsapp.QuickReplyStore;
    return (s?.getModelsArray?.() || s?.models || []).map(q => ({ code: q.shortcut, text: q.message, keywords: [].concat(q.keywords || []) }));
  };

  // customer msg → my reply pairs from recent private chats
  const scan = async () => {
    const pairs = [];
    for (const c of await WPP.chat.list({ count: 30, onlyUsers: true })) {
      const id = sid(c.id);
      if (SKIP.test(id)) continue;
      let q = '';
      for (const m of await WPP.chat.getMessages(id, { count: 40 }).catch(() => [])) {
        const t = m.type === 'chat' ? textOf(m) : '';
        if (!t) continue;
        if (!m.id?.fromMe) q = t;
        else if (q) { pairs.push({ q: q.slice(0, 400), a: t.slice(0, 600) }); q = ''; }
      }
      if (pairs.length >= 200) break;
    }
    return pairs;
  };

  const history = async (chatId, count) => (await WPP.chat.getMessages(chatId, { count }))
    .filter(m => KEEP[m.type])
    .map(m => ({ id: sid(m.id), type: m.type, me: !!m.id?.fromMe, t: m.t, who: m.notifyName || '', text: textOf(m) || `[${LABEL[m.type] || m.type}]` }));

  // media → base64; photos shrunk to 1280 px jpeg
  const b64 = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
  const shrink = async blob => {
    const bmp = await createImageBitmap(blob), k = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
    const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    return c.convertToBlob({ type: 'image/jpeg', quality: 0.8 });
  };
  const media = async id => {
    let blob = await WPP.chat.downloadMedia(id);
    if (blob.size > 12e6) throw new Error('Media is too big');
    if (blob.type.startsWith('image/')) blob = await shrink(blob);
    return { mime: (blob.type || 'application/octet-stream').split(';')[0], data: await b64(blob) };
  };
  // bot file / pin; its echo must not count as my reply
  const echo = chatId => { files.set(chatId, (files.get(chatId) || 0) + 1); setTimeout(() => files.get(chatId) > 0 && files.set(chatId, files.get(chatId) - 1), 60000); };
  const sendFile = (chatId, { dataUrl, name, mime }) => {
    echo(chatId);
    const type = mime.startsWith('image/') ? 'image' : mime.startsWith('video/') ? 'video' : 'document';
    return WPP.chat.sendFileMessage(chatId, dataUrl, { type, filename: name, mimetype: mime });
  };
  const sendPin = (chatId, loc) => { echo(chatId); return WPP.chat.sendLocationMessage(chatId, { lat: loc.lat, lng: loc.lng, name: loc.name || '', address: loc.address || '' }); };

  const send = async (chatId, text, typingMs, read) => {
    read && await WPP.chat.markIsRead(chatId).catch(() => {});
    await WPP.chat.markIsComposing(chatId, typingMs).catch(() => {});
    await sleep(typingMs);
    pending.set(chatId, text.trim());
    setTimeout(() => pending.get(chatId) === text.trim() && pending.delete(chatId), 15000); // echo never came
    return WPP.chat.sendTextMessage(chatId, text);
  };

  // requests from content.js
  window.addEventListener('message', async e => {
    const d = e.data;
    if (e.source !== window || d?.waai !== 'ext') return;
    try {
      if (d.type === 'history') post('reply', { rid: d.rid, ok: true, items: await history(d.chatId, d.count) });
      else if (d.type === 'send') { await send(d.chatId, d.text, d.typingMs, d.read); post('reply', { rid: d.rid, ok: true }); }
      else if (d.type === 'status') status();
      else if (d.type === 'qrList') post('reply', { rid: d.rid, ok: true, items: qrList() });
      else if (d.type === 'scan') post('reply', { rid: d.rid, ok: true, pairs: await scan() });
      else if (d.type === 'media') post('reply', { rid: d.rid, ok: true, ...(await media(d.id)) });
      else if (d.type === 'sendFile') { await sendFile(d.chatId, d); post('reply', { rid: d.rid, ok: true }); }
      else if (d.type === 'sendPin') { await sendPin(d.chatId, d.loc); post('reply', { rid: d.rid, ok: true }); }
      else if (d.type === 'open') { await WPP.chat.openChatBottom(d.chatId); post('reply', { rid: d.rid, ok: true }); }
    } catch (err) {
      post('reply', { rid: d.rid, ok: false, err: String(err?.message || err) });
    }
  });

  WPP.loader.onReady(() => {
    WPP.on('chat.new_message', m => onMsg(m).catch(() => {}));
    status();
    setInterval(status, 30000);
  });
})();
