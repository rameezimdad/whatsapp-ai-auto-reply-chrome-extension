/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// setup pages (.bk-setup): quick picks, chip lists, segmented picks, steppers, message tags, reset to default.
// every change goes through setVal, so the save bar and the page's own live preview see it
import { $, esc, toast } from './ui.js';
import { DEFAULTS } from './cfg.js';

export const list = v => String(v || '').split(',').map(x => x.trim()).filter(Boolean);
export const setVal = (id, v) => { $(id).value = v; $(id).dispatchEvent(new Event('input', { bubbles: true })); };
const nums = v => [...new Set(String(v || '').split(/[\s,;]+/).map(n => n.replace(/\D/g, '')).filter(n => n.length >= 7))];
const items = el => el.dataset.kind === 'num' ? nums($(el.dataset.chips).value) : list($(el.dataset.chips).value);
const fmtDate = d => new Date(`${d}T12:00`).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

// chip lists: [data-chips=<hidden input id>] + [data-add=<id>] box + [data-add-btn=<id>]
export const paintChips = (root = document) => root.querySelectorAll('[data-chips]').forEach(el => {
  const v = items(el), ic = el.dataset.icon || 'fa-hashtag';
  el.innerHTML = v.length ? v.map((x, i) => `<span class="bk-chip"><i class="fa-solid ${ic}"></i>${esc(el.dataset.kind === 'date' ? fmtDate(x) : x)}<button type="button" data-del="${el.dataset.chips}" data-i="${i}" aria-label="Remove ${esc(x)}"><i class="fa-solid fa-xmark"></i></button></span>`).join('')
    : `<span class="sub">${esc(el.dataset.empty || 'None yet')}</span>`;
  const n = document.querySelector(`[data-count="${el.dataset.chips}"]`);
  n && (n.textContent = v.length);
});
const add = id => {
  const box = document.querySelector(`[data-add="${id}"]`), el = document.querySelector(`[data-chips="${id}"]`), have = items(el);
  const raw = box.value.trim();
  if (!raw) return box.focus();
  const got = el.dataset.kind === 'num' ? nums(raw) : el.dataset.kind === 'date' ? [raw] : list(raw);
  if (!got.length) return toast(el.dataset.kind === 'num' ? 'Type the number with the country code, like 923001234567' : 'Type something to add', true);
  setVal(id, [...new Set([...have, ...got])].join(', '));
  box.value = '';
  box.focus();
};

document.addEventListener('click', e => {
  const t = e.target.closest('.bk-setup :is([data-pre-for], [data-seg-for] button, [data-step], [data-tag], [data-del], [data-add-btn], [data-reset], [data-line-for])');
  if (!t) return;
  if (t.dataset.preFor) { // toggle one word in a comma list
    const id = t.dataset.preFor, w = t.dataset.v, v = list($(id).value);
    return setVal(id, (v.some(x => x.toLowerCase() === w) ? v.filter(x => x.toLowerCase() !== w) : [...v, w]).join(', '));
  }
  if (t.dataset.lineFor) { // add a ready-made line once
    const ta = $(t.dataset.lineFor), have = ta.value.split('\n').map(x => x.trim()).filter(Boolean);
    return setVal(t.dataset.lineFor, (have.includes(t.dataset.v) ? have.filter(x => x !== t.dataset.v) : [...have, t.dataset.v]).join('\n'));
  }
  if (t.dataset.v) return setVal(t.closest('[data-seg-for]').dataset.segFor, t.dataset.v);
  if (t.dataset.step) { const el = $(t.dataset.step); return setVal(t.dataset.step, Math.min(+el.max || 99, Math.max(+el.min || 0, (+el.value || 0) + +t.dataset.d))); }
  if (t.dataset.del) { const el = document.querySelector(`[data-chips="${t.dataset.del}"]`); return setVal(t.dataset.del, items(el).filter((_, i) => i !== +t.dataset.i).join(', ')); }
  if (t.dataset.addBtn) return add(t.dataset.addBtn);
  if (t.dataset.reset) return setVal(t.dataset.reset, DEFAULTS[$(t.dataset.reset).dataset.k] ?? '');
  // message tag at the cursor
  const ta = $(t.closest('[data-tags-for]').dataset.tagsFor), at = ta.selectionStart ?? ta.value.length, tag = `{${t.dataset.tag}}`;
  ta.value = ta.value.slice(0, at) + tag + ta.value.slice(ta.selectionEnd ?? at);
  ta.focus(); ta.setSelectionRange(at + tag.length, at + tag.length);
  ta.dispatchEvent(new Event('input', { bubbles: true }));
});
document.addEventListener('keydown', e => e.key === 'Enter' && e.target.matches('.bk-setup [data-add]') && (e.preventDefault(), add(e.target.dataset.add)));

// selected state of quick picks + segmented picks, and the tag chips under each message box
export const paintPicks = root => {
  root.querySelectorAll('[data-seg-for]').forEach(g => g.querySelectorAll('button').forEach(b => b.classList.toggle('on', String(b.dataset.v) === String($(g.dataset.segFor).value))));
  root.querySelectorAll('[data-pre-for]').forEach(b => { const on = list($(b.dataset.preFor).value).some(x => x.toLowerCase() === b.dataset.v); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.querySelector('i').className = `fa-solid ${on ? 'fa-check' : 'fa-plus'}`; });
  root.querySelectorAll('[data-line-for]').forEach(b => { const on = $(b.dataset.lineFor).value.split('\n').map(x => x.trim()).includes(b.dataset.v); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
};
export const paintTags = (root, tags) => root.querySelectorAll('[data-tags-for]').forEach(t => t.innerHTML = tags.map(k => `<button type="button" class="bk-tag" data-tag="${esc(k)}">{${esc(k)}}</button>`).join(''));
// extra detail names typed by the owner, usable as {tags}
export const extraTags = (fields, std) => list(fields).map(f => f.toLowerCase().replace(/\W+/g, '_')).filter(f => f && !std.includes(f));
