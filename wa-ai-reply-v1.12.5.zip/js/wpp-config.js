/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// read by wa-js before it boots
window.WPPConfig = { disableGoogleAnalytics: true, syncAllStatus: false, sendStatusToDevice: false };
