# Developed by Mohammad Rameez Imdad (Rameez Scripts)
# WhatsApp: https://wa.me/923435347417 (For Custom Projects)
# YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
#
# WA AI Reply auto update: newest GitHub release -> this extension folder.
# Settings, orders and customers live inside Chrome, not here, so nothing is lost.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$repo = 'rameezimdad/whatsapp-ai-auto-reply-chrome-extension'
$ua = @{ 'User-Agent' = 'WA-AI-Reply-Updater' }
$dir = Split-Path -Parent $PSScriptRoot
$statusFile = Join-Path $PSScriptRoot 'status.json'
$latest = ''

function Save($state, $msg) {
  $o = [ordered]@{ checked = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); state = $state; msg = $msg; latest = $latest }
  ($o | ConvertTo-Json -Compress) | Set-Content -Path $statusFile -Encoding UTF8
}

$tmp = Join-Path $env:TEMP ('waai-update-' + [guid]::NewGuid().ToString('N'))
try {
  $cur = Get-Content (Join-Path $dir 'manifest.json') -Raw | ConvertFrom-Json
  if ($cur.name -notlike 'WA AI Reply*') { throw 'This script must stay in the updater folder of WA AI Reply' }   # never touch another folder
  $rel = Invoke-RestMethod "https://api.github.com/repos/$repo/releases/latest" -Headers $ua -TimeoutSec 60
  $latest = $rel.tag_name -replace '^v', ''
  if ([version]$latest -le [version]$cur.version) { Save 'ok' "Up to date (v$($cur.version))"; exit 0 }

  $asset = $rel.assets | Where-Object { $_.name -like 'wa-ai-reply-v*.zip' } | Select-Object -First 1
  if (-not $asset) { throw 'The new release has no zip' }
  $sha = [regex]::Match([string]$rel.body, 'SHA256:\s*([a-fA-F0-9]{64})').Groups[1].Value
  if (-not $sha) { throw 'The new release has no SHA256 line' }

  New-Item -ItemType Directory -Path $tmp | Out-Null
  $zip = Join-Path $tmp 'new.zip'
  Invoke-WebRequest $asset.browser_download_url -OutFile $zip -UseBasicParsing -Headers $ua -TimeoutSec 300
  if ((Get-FileHash $zip -Algorithm SHA256).Hash -ne $sha.ToUpper()) { throw 'Download check failed (SHA256 did not match)' }
  $src = Join-Path $tmp 'x'
  Expand-Archive $zip -DestinationPath $src -Force
  $man = Join-Path $src 'manifest.json'
  if ((Get-Content $man -Raw | ConvertFrom-Json).version -ne $latest) { throw 'The zip has a different version than the release' }

  # shipped file lists (updater/files.txt): the old one is read before the copy overwrites it
  $listOf = {
    param($root)
    $f = Join-Path $root 'updater\files.txt'
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    @(Get-Content -LiteralPath $f | ForEach-Object { $_.Trim() -replace '\\', '/' } | Where-Object { $_ -and $_ -notmatch '\.\.' -and $_ -notmatch '^/' -and $_ -notmatch ':' })
  }
  $oldList = & $listOf $dir

  # every file first, manifest.json last: the extension only sees the new version once everything is in place
  $base = (Get-Item -LiteralPath $src).FullName.TrimEnd('\') + '\'   # same spelling as the child paths (short TEMP names)
  Get-ChildItem -LiteralPath $base -Recurse -File | ForEach-Object {
    $rp = $_.FullName.Substring($base.Length)
    if ($rp -eq 'manifest.json') { return }
    $to = Join-Path $dir $rp
    New-Item -ItemType Directory -Path (Split-Path $to) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $to -Force
  }
  # files the old version shipped and the new one does not: removed. Only names from the old list, nothing else in the folder
  $newList = & $listOf $base
  $removed = 0
  if ($oldList.Count -and $newList.Count -ge 10) {
    $keep = @{}
    $newList | ForEach-Object { $keep[$_.ToLower()] = 1 }
    foreach ($rp in $oldList) {
      if ($keep.ContainsKey($rp.ToLower()) -or $rp -in 'manifest.json', 'updater/status.json') { continue }
      $p = Join-Path $dir ($rp -replace '/', '\')
      if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { continue }
      Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
      $removed++
      $up = Split-Path $p
      if ($up -ne $dir.TrimEnd('\') -and -not (Get-ChildItem -LiteralPath $up -Force)) { Remove-Item -LiteralPath $up -Force -ErrorAction SilentlyContinue }   # folder left empty
    }
  }
  Copy-Item $man (Join-Path $dir 'manifest.json') -Force
  Save 'updated' ("Updated from v$($cur.version) to v$latest" + $(if ($removed) { ", $removed old files removed" } else { '' }))
} catch {
  Save 'error' $_.Exception.Message
  exit 1
} finally {
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}
