/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// health checks, debug info, backup / restore
import { $, esc, bg, toast, busy, ago, connState, confirmBox, openWa, ENGINE } from './ui.js';
import { DEFAULTS, NEEDS, getCfg, setCfg, ready, today } from './cfg.js';

const VER = chrome.runtime.getManifest().version;
const SECRET = ['claudeKey', 'openaiKey', 'geminiKey', 'grokKey', 'mcpToken', 'hookSecret'];
const FLAGS = ['enabled', 'voiceOn', 'photoOn', 'ordersOn', 'qrOn', 'qrCode', 'qrLearn', 'groups', 'hoursOn', 'mcpOn', 'savedOnly', 'markRead', 'noLinks', 'alertOn', 'alertSound'];
const NUMS = ['delayMin', 'delayMax', 'minuteCap', 'dayCap', 'hourCap', 'humanPause', 'maxAge', 'history', 'errStop'];
const modelOf = c => ({ claude: c.claudeModel, openai: c.openaiModel, gemini: c.geminiModel, grok: c.grokModel }[c.engine] || '');
let keyNote = ''; // last key check, '!' = failed

const row = (ok, label, value, act = '') => `<li class="${ok ? '' : 'no'}"><i class="fa-solid ${ok ? 'fa-check' : 'fa-exclamation'}"></i>
  <span class="hl">${esc(label)}</span><span class="hv">${value}</span>${act}</li>`;

const render = async () => {
  const cfg = await getCfg();
  const { status = {}, log = [], stats } = await chrome.storage.local.get(['status', 'log', 'stats']);
  const [cls, txt] = await connState();
  const st = stats?.day === today() ? stats : {};
  const sent = log.find(l => l.st === 'sent'), err = log.find(l => l.st === 'error');
  const bytes = await chrome.storage.local.getBytesInUse(null);
  const perm = await new Promise(r => chrome.notifications.getPermissionLevel(r));
  const live = Date.now() - (status.at || 0) < 70000, hook = cfg.engine === 'webhook';
  $('healthList').innerHTML = [
    row(true, 'Extension', `v${esc(VER)}`),
    row(cls === 'ok', 'WhatsApp Web', esc(txt), `<button class="btn ghost sm" data-h="${/not open/.test(txt) ? 'open' : 'reload'}">${/not open/.test(txt) ? 'Open' : 'Reload tab'}</button>`),
    row(live && !status.fail, 'WhatsApp connection', status.fail ? 'Could not start, WhatsApp may have changed. Update the extension.'
      : live ? `WA-JS ${esc(status.wpp || '?')} · WhatsApp ${esc(status.wa || '?')}` : 'Not reported yet. Open or reload WhatsApp Web.'),
    row(ready(cfg) && !keyNote.startsWith('!'), hook ? 'My server URL' : `${ENGINE[cfg.engine] || 'AI'} key`,
      keyNote ? esc(keyNote.replace(/^!/, '')) : ready(cfg) ? 'Saved, not checked yet' : 'Missing', ready(cfg) ? '<button class="btn ghost sm" data-h="key">Check</button>' : '<button class="btn ghost sm" data-go="engine">Add</button>'),
    row(cfg.enabled, 'Bot', cfg.enabled ? 'On' : 'Off'),
    row(!!sent, 'Last reply', sent ? `${esc(sent.name || sent.phone || 'a chat')} · ${ago(sent.at)}` : 'None yet'),
    row(!err || Date.now() - new Date(err.at) > 864e5, 'Last error', err ? `${esc(err.err)} · ${ago(err.at)}` : 'None'),
    row(!st.error, 'Errors today', String(st.error || 0)),
    row(perm === 'granted', 'Desktop alerts', perm !== 'granted' ? 'Blocked by Chrome or Windows' : cfg.alertOn ? 'Allowed' : 'Allowed, turned off in Reply rules'),
    row(true, 'Storage used', `${(bytes / 1048576).toFixed(1)} MB`)
  ].join('');
};

$('healthList').addEventListener('click', async e => {
  const b = e.target.closest('[data-h]');
  if (!b) return;
  const a = b.dataset.h;
  if (a === 'open') return openWa();
  if (a === 'reload') {
    const [tab] = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
    tab ? (await chrome.tabs.reload(tab.id), toast('WhatsApp Web is reloading')) : openWa();
    return setTimeout(render, 15000);
  }
  busy(b, true);
  const cfg = await getCfg(), r = await bg({ type: 'keyTest', engine: cfg.engine, key: cfg[NEEDS[cfg.engine]] });
  busy(b, false);
  keyNote = r.ok ? (r.n ? `Works, ${r.n} models available` : 'Looks right') : `!${r.err}`;
  render();
});
$('hRefresh').onclick = () => { keyNote = ''; render(); toast('Checked again'); };

// support info: versions, switches, last errors; never keys, business text or numbers
$('hCopy').onclick = async () => {
  const cfg = await getCfg();
  const { status = {}, log = [], stats, qr = [], orders = [], kb = [], memo = {} } = await chrome.storage.local.get(['status', 'log', 'stats', 'qr', 'orders', 'kb', 'memo']);
  const info = {
    app: 'WA AI Reply', version: VER, at: new Date().toISOString(), engine: cfg.engine, model: modelOf(cfg), keySaved: ready(cfg),
    flags: Object.fromEntries(FLAGS.map(f => [f, !!cfg[f]])), limits: Object.fromEntries(NUMS.map(n => [n, +cfg[n]])),
    whatsapp: { wajs: status.wpp || '', web: status.wa || '', loggedIn: !!status.auth, fail: status.fail || '', seen: status.at ? new Date(status.at).toISOString() : '' },
    today: stats?.day === today() ? stats : {}, counts: { quickReplies: qr.length, orders: orders.length, log: log.length, facts: kb.length, customers: Object.keys(memo).length },
    errors: log.filter(l => l.st === 'error').slice(0, 5).map(l => ({ at: l.at, err: l.err, raw: l.raw || '' })), browser: navigator.userAgent
  };
  try { await navigator.clipboard.writeText(JSON.stringify(info, null, 2)); toast('Debug info copied. Paste it in your message to support.'); }
  catch { toast('Could not copy. Try again.', true); }
};

// backup / restore
const saveFile = (name, text) => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};
$('bkDown').onclick = async () => {
  const cfg = { ...(await getCfg()) }, { qr = [], kb = [] } = await chrome.storage.local.get(['qr', 'kb']);
  $('bkKeys').checked || SECRET.forEach(k => delete cfg[k]);
  delete cfg.enabled;
  saveFile(`wa-ai-reply-backup-${today()}.json`, JSON.stringify({ app: 'wa-ai-reply', version: VER, at: new Date().toISOString(), cfg, qr: qr.map(({ files, ...q }) => q), kb }, null, 2));
  toast($('bkKeys').checked ? 'Backup downloaded with your keys. Keep the file private.' : 'Backup downloaded');
};
$('bkUp').onclick = () => $('bkFile').click();
$('bkFile').onchange = async e => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  let j;
  try { j = JSON.parse(await f.text()); } catch { return toast('This is not a backup file', true); }
  if (j?.app !== 'wa-ai-reply' || !j.cfg || typeof j.cfg !== 'object') return toast('This is not a WA AI Reply backup', true);
  if (!(await confirmBox('Restore this backup?', `Made on ${String(j.at || '').slice(0, 10) || 'an unknown date'}. Your settings are replaced, its quick replies are added (codes you already have stay as they are), and the bot is turned off until you turn it on.`, { ok: 'Restore', danger: false }))) return;
  busy($('bkUp'), true);
  try {
    // only known settings with the right type; keys missing from the file keep their current value
    const patch = Object.fromEntries(Object.entries(j.cfg).filter(([k, v]) => k in DEFAULTS && k !== 'enabled' && typeof v === typeof DEFAULTS[k]));
    await setCfg({ ...patch, enabled: false });
    const r = Array.isArray(j.qr) ? await bg({ type: 'qrBulk', items: j.qr.map(q => ({ ...q, files: [] })) }) : { added: 0 };
    const k = Array.isArray(j.kb) ? await bg({ type: 'kbBulk', items: j.kb }) : { added: 0 };
    dispatchEvent(new CustomEvent('waai:saved'));
    toast(`Restored. ${r.added || 0} quick replies and ${k.added || 0} facts added. Turn the bot on when ready.`);
  } finally { busy($('bkUp'), false); }
};

// updates: this version, the newest GitHub release, the Windows auto updater
const updPaint = async (force = false) => {
  if (!$('updBox')) return; // store copy
  const u = await bg({ type: 'updInfo', force });
  if (!u?.ok) return;
  $('pillUpd') && ($('pillUpd').hidden = !u.behind);
  $('updCur').innerHTML = `<span class="pill c-human">v${esc(u.cur)}</span>`;
  $('updWhen').textContent = u.at ? `Checked ${ago(new Date(u.at).toISOString())}` : '';
  $('updLatest').innerHTML = !u.latest ? '<span class="pill c-skip">Could not check</span>'
    : u.behind ? `<span class="pill c-new">v${esc(u.latest)} available</span> <a class="btn ghost" href="${esc(u.url)}" target="_blank" rel="noopener"><i class="fa-solid fa-download"></i> Download</a>`
    : '<span class="pill c-sent">Up to date</span>';
  const a = u.auto;
  $('updAuto').innerHTML = u.autoOn ? `<span class="pill ${a.state === 'error' ? 'c-error' : 'c-sent'}">${a.state === 'error' ? 'Problem' : 'On'}</span>` : '<span class="pill c-skip">Off</span>';
  $('updAutoNote').textContent = u.autoOn ? `Last check ${ago(a.checked)} · ${a.msg || ''}`
    : a ? `Last ran ${ago(a.checked)}. Run Turn on auto update.bat again.` : 'Open this extension\'s folder › updater › double-click Turn on auto update.bat once.';
};
$('updCheck') && ($('updCheck').onclick = async e => { const b = e.currentTarget; busy(b, true); await updPaint(true).finally(() => busy(b, false)); toast('Checked for updates'); });

addEventListener('waai:view', e => e.detail === 'health' ? render() : e.detail === 'updates' && updPaint());
// sidebar dot when a newer version is out
$('pillUpd') && bg({ type: 'updInfo' }).then(u => { $('pillUpd').hidden = !u?.behind; });
