/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// AI budget page: this month's spend, cost by day, prices
import { $, esc } from './ui.js';
import { getCfg, money, month, usualPrice, today } from './cfg.js';

const modelOf = c => ({ claude: c.claudeModel, openai: c.openaiModel, gemini: c.geminiModel, grok: c.grokModel }[c.engine] || '');
const short = n => n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : String(n);

const render = async () => {
  const cfg = await getCfg();
  let { usage } = await chrome.storage.local.get('usage');
  if (usage?.month !== month()) usage = { calls: 0, inTok: 0, outTok: 0, cost: 0, unpriced: 0, days: {} };
  const td = usage.days[today()] || { calls: 0, cost: 0 }, r = cfg.budgetOn && +cfg.budget > 0 ? usage.cost / cfg.budget : 0;
  $('bMonth').textContent = money(usage.cost, cfg);
  $('bBar').style.width = `${Math.min(100, Math.round(r * 100))}%`;
  $('bBar').parentElement.className = `ib-bar ${r >= 1 ? 'bad' : r >= 0.8 ? 'warn' : ''}`;
  $('bMonthNote').textContent = cfg.budgetOn ? `${Math.round(r * 100)}% of the $${cfg.budget} budget` : 'No budget set';
  $('bToday').textContent = money(td.cost, cfg);
  $('bTodayNote').textContent = `${td.calls} AI ${td.calls === 1 ? 'call' : 'calls'}`;
  $('bPer').textContent = usage.calls ? `$${(usage.cost / usage.calls).toFixed(4)}` : '-';
  $('bCalls').textContent = `${usage.calls} AI calls this month`;
  $('bTok').textContent = short(usage.inTok + usage.outTok);
  $('bTokNote').textContent = `${short(usage.inTok)} in · ${short(usage.outTok)} out`;
  // one bar per day of this month so far
  const now = new Date(), days = Array.from({ length: now.getUTCDate() }, (_, i) => `${month()}-${String(i + 1).padStart(2, '0')}`);
  const max = Math.max(...days.map(d => usage.days[d]?.cost || 0), 0.0001);
  $('bDays').innerHTML = days.map(d => {
    const x = usage.days[d] || { calls: 0, cost: 0 }, h = Math.round(x.cost / max * 100);
    return `<span class="${d === today() ? 'today' : ''}${x.cost ? '' : ' zero'}" style="height:${Math.max(h, 2)}%" title="${d}: ${esc(money(x.cost, cfg))}, ${x.calls} calls"></span>`;
  }).join('');
  $('bFirst').textContent = new Date(`${days[0]}T00:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
  const model = modelOf(cfg), up = usualPrice(model), own = +cfg.priceIn > 0 || +cfg.priceOut > 0;
  $('bModel').textContent = model ? `Model now: ${model}` : 'My server: no AI cost counted here';
  $('bUsual').textContent = up ? `$${up[0]} in · $${up[1]} out` : 'Not known';
  $('bUsualNote').textContent = own ? 'Your own price below is used instead' : up ? 'Per 1M tokens, used for the estimate' : 'Add your price below, or this model is not counted';
  $('bUnpriced').hidden = !usage.unpriced;
  $('bUnpriced').innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${usage.unpriced} AI calls had no known price and are not in the total. Add your price below.`;
};

addEventListener('waai:view', e => e.detail === 'budget' && render());
chrome.storage.onChanged.addListener(c => (c.usage || c.cfg) && !$('bDays').closest('.view').hidden && render());
