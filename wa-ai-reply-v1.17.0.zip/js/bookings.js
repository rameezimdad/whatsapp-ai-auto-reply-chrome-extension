/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// bookings page: Tabulator list, pipeline, bulk bar, 360 popup, add/edit form, setup page free-time preview
import { $, esc, bg, toast, busy, confirmBox, toCSV, download, waFormat, userCell } from './ui.js';
import { getCfg, demoSeq } from './cfg.js';
import { list, setVal, paintChips, paintPicks, paintTags, extraTags } from './setup.js';
import { openMsg } from './msg.js';

const ST = {
  booked: ['Booked', 'c-human', 'fa-calendar-check'], done: ['Done', 'c-sent', 'fa-circle-check'],
  noshow: ['No-show', 'c-new', 'fa-user-slash'], cancelled: ['Cancelled', 'c-error', 'fa-ban']
};
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];
let rows = [], table = null, built = false, stage = 'today', curId = null, editId = null;

const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const no = b => `BK-${b.at.slice(0, 4)}-${String(b.no).padStart(3, '0')}`;
const dayOf = key => { const [y, m, d] = String(key).split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDay = key => /^\d{4}-\d{2}-\d{2}$/.test(key) ? dayOf(key).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }) : '';
const fmtTime = t => { const m = String(t || '').match(/^(\d{1,2}):(\d{2})/); if (!m) return ''; const n = +m[1] * 60 + +m[2], h = Math.floor(n / 60) % 12 || 12; return `${h}:${m[2]} ${n < 720 ? 'am' : 'pm'}`; };
const whenWord = key => { const diff = Math.round((dayOf(key) - dayOf(todayKey())) / 864e5); return diff === 0 ? 'today' : diff === 1 ? 'tomorrow' : `on ${fmtDay(key)}`; };
const when = iso => new Date(iso).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
const pill = s => { const [l, c, i] = ST[s] || ST.booked; return `<span class="pill ${c}"><i class="fa-solid ${i}"></i> ${l}</span>`; };
const fill = (tpl, b, cfg) => tpl.replace(/\{(\w+)\}/g, (m, k) => ({ no: b.at ? no(b) : 'BK-…', date: fmtDay(b.date), time: fmtTime(b.time), when: b.date ? whenWord(b.date) : '', service: b.service || '',
  name: b.name || '', phone: b.phone || '', what: cfg.bookWhat.trim() || 'appointment', notes: b.notes || '' }[k] ?? b.extra?.[k] ?? m)).replace(/\n{2,}/g, '\n').trim();
const inStage = (b, s) => {
  const t = todayKey();
  return s === 'all' ? true : s === 'today' ? b.date === t && b.status === 'booked' : s === 'upcoming' ? b.date > t && b.status === 'booked'
    : s === 'past' ? b.status === 'booked' && b.date < t : b.status === s;
};

// table
const build = () => {
  table = new Tabulator($('bookTable'), {
    data: rows,
    layout: 'fitColumns',
    responsiveLayout: 'collapse',
    placeholder: 'No bookings yet. When the AI books one, or you add one, it shows up here.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true,
    selectableRows: 'highlight',
    initialSort: [{ column: 'sortKey', dir: 'asc' }],
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'Booking', field: 'no', sorter: 'number', minWidth: 120, formatter: c => `<b class="mono tb-no">${esc(no(c.getData()))}</b>` },
      { title: 'When', field: 'sortKey', minWidth: 170, formatter: c => { const b = c.getData(); return `<b>${esc(fmtDay(b.date))}</b><small class="sub">${esc(fmtTime(b.time))}${b.date === todayKey() ? ' · today' : ''}</small>`; } },
      { title: 'Customer', field: 'name', minWidth: 180, formatter: c => { const b = c.getData(); return userCell(b.name || b.chatName || '-', b.phone || ''); } },
      { title: 'Service', field: 'service', minWidth: 140, formatter: c => c.getValue() ? `<span class="tb-pill role">${esc(c.getValue())}</span>` : '<span class="sub">-</span>' },
      { title: 'Status', field: 'status', minWidth: 120, formatter: c => pill(c.getValue()) },
      { title: 'Reminder', field: 'remind', hozAlign: 'center', width: 96, headerSort: false, formatter: c => c.getValue() ? '<i class="fa-solid fa-bell ok-ic" title="Reminder sent"></i>' : '<span class="sub">-</span>' },
      { title: 'Actions', field: 'id', headerSort: false, download: false, width: 168, hozAlign: 'right', formatter: () => ACT_ICONS,
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && rowAct(b.dataset.act, c.getData()); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('bookSel').textContent = d.length;
    document.querySelectorAll('[data-bbulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};
// row actions: open · edit · message · delete
const ACT_ICONS = '<button class="nav-btn ic-view" data-act="view" aria-label="Open" title="Open"><i class="fa-solid fa-eye"></i></button>'
  + '<button class="nav-btn ic-edit" data-act="edit" aria-label="Edit" title="Edit"><i class="fa-solid fa-pen"></i></button>'
  + '<button class="nav-btn ic-msg" data-act="msg" aria-label="Send a message" title="Send a message"><i class="fa-brands fa-whatsapp"></i></button>'
  + '<button class="nav-btn ic-del" data-act="del" aria-label="Delete" title="Delete"><i class="fa-solid fa-trash"></i></button>';
const rowAct = (a, b) => a === 'view' ? openBooking(b.id) : a === 'edit' ? openForm(b) : a === 'msg' ? message(b) : remove([b.id]);
const message = async b => {
  const cfg = await getCfg(), f = t => fill(t, b, cfg);
  openMsg({ kind: 'book', id: b.id, chatId: b.chatId, since: b.at, who: b.name || b.chatName, phone: b.phone, list: [
    ['Confirmation', 'fa-circle-check', f(cfg.bookMsg)], ['Reminder', 'fa-bell', f(cfg.bookRemindMsg)],
    ['Change time', 'fa-calendar-days', f('Hi {name}, we need to move your {what} on {date} at {time}. Which other time suits you?')],
    ['Thank you', 'fa-heart', f('Thank you for visiting, {name}. We hope to see you again soon!')]] });
};
const applyFilter = () => {
  if (!built) return;
  const k = $('bookSearch').value.trim().toLowerCase();
  table.setFilter(d => inStage(d, stage) && (!k || `${d.name} ${d.phone} ${d.service} ${d.notes} ${no(d)}`.toLowerCase().includes(k)));
};
const pipe = () => {
  const n = s => rows.filter(r => inStage(r, s)).length;
  const L = { today: ['Today', 'fa-sun'], upcoming: ['Upcoming', 'fa-calendar-day'], past: ['Not marked', 'fa-hourglass-end'], done: ['Done', 'fa-circle-check'], cancelled: ['Cancelled', 'fa-ban'], all: ['All', 'fa-layer-group'] };
  $('bookPipe').innerHTML = Object.entries(L).map(([s, [l, i]]) => `<button role="tab" aria-selected="${s === stage}" class="${s === stage ? 'active' : ''}" data-stage="${s}"><i class="fa-solid ${i}"></i> ${l} <b>${n(s)}</b></button>`).join('');
};
// KPI row: each footer filters the Tabulator list like the status tabs
const kpiBox = ([cls, val, label, ic, st, more]) => `<div class="small-box ${cls}"><div class="inner"><h3>${val}</h3><p>${label}</p></div><i class="icon fa-solid ${ic}"></i>
  <button type="button" class="small-box-footer" data-kstage="${st}">${more} <i class="fa-solid fa-circle-arrow-right"></i></button></div>`;
const kpis = () => {
  const m = todayKey().slice(0, 7), n = s => rows.filter(r => inStage(r, s)).length;
  $('bookKpis').innerHTML = [['bg-info', n('today'), 'Today', 'fa-sun', 'today', 'See today'], ['bg-navy', n('upcoming'), 'Upcoming', 'fa-calendar-day', 'upcoming', 'See upcoming'],
    ['bg-danger', n('past'), 'Not marked yet', 'fa-hourglass-end', 'past', 'Mark them'], ['bg-success', rows.filter(r => r.status === 'done' && String(r.date).slice(0, 7) === m).length, 'Done this month', 'fa-circle-check', 'done', 'See done']].map(kpiBox).join('');
};
$('bookKpis').addEventListener('click', e => { const b = e.target.closest('[data-kstage]'); if (!b) return; stage = b.dataset.kstage; pipe(); applyFilter(); $('bookPipe').scrollIntoView({ behavior: 'smooth', block: 'start' }); });

const load = async () => {
  const cfg = await getCfg();
  rows = ((await chrome.storage.local.get('bookings')).bookings || []).map(b => ({ ...b, sortKey: `${b.date} ${b.time}` }));
  const todayN = rows.filter(r => inStage(r, 'today')).length;
  $('pillBook').hidden = !todayN;
  $('pillBook').textContent = todayN > 99 ? '99+' : todayN;
  $('bookCount').textContent = rows.length;
  $('bookOff').hidden = !!cfg.bookOn;
  pipe();
  kpis();
  built && (table.replaceData(rows), applyFilter());
  curId && $('bookDlg').open && openBooking(curId);
};

// 360 popup
const card = (title, ic, body) => `<div class="ord-card"><h4><i class="fa-solid ${ic}"></i> ${title}</h4>${body}</div>`;
const kv = (k, v) => v ? `<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>` : '';
const openBooking = async id => {
  const b = rows.find(r => r.id === id);
  if (!b) return $('bookDlg').open && $('bookDlg').close();
  curId = id;
  const cfg = await getCfg(), late = Date.now() - new Date(b.at) > 864e5, chat = /@(c\.us|lid)$/.test(b.chatId || '');
  $('bookTitle').innerHTML = `<i class="fa-solid fa-calendar-check"></i> ${esc(no(b))} ${pill(b.status)}`;
  $('bookInfo').innerHTML = `<div class="ord-cards">
    ${card('When', 'fa-clock', kv('Day', fmtDay(b.date)) + kv('Time', fmtTime(b.time)) + kv('Service', b.service))}
    ${card('Customer', 'fa-user', kv('Name', b.name) + kv('Phone', b.phone) + kv('WhatsApp name', b.chatName))}
    </div>
    ${Object.keys(b.extra || {}).length || b.notes ? card('More details', 'fa-note-sticky', Object.entries(b.extra || {}).map(([k, v]) => kv(k.replace(/_/g, ' '), v)).join('') + kv('Notes', b.notes)) : ''}
    ${card('History', 'fa-clock-rotate-left', kv('Booked', when(b.at)) + kv('Updated', b.upd && when(b.upd)) + kv('Confirmation sent', b.notified && when(b.notified)) + kv('Reminder sent', b.remind && when(b.remind)))}`;
  $('bookSide').innerHTML = `<h3><i class="fa-brands fa-whatsapp"></i> Confirmation message</h3>
    <div class="wa-phone"><div class="bubble out">${waFormat(fill(cfg.bookMsg, b, cfg))}</div></div>
    ${!chat ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> No WhatsApp chat on this booking. Message the customer yourself.</p>' : late ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> More than 24 hours since it was booked. Message this customer yourself from WhatsApp.</p>' : ''}
    <div class="ord-acts">
      <button class="btn btn-primary" data-b="notify" ${late || !chat || b.notified || b.status !== 'booked' ? 'disabled' : ''}><i class="fa-solid fa-paper-plane"></i> Send confirmation</button>
      <button class="btn btn-secondary" data-b="remind" ${!chat || b.status !== 'booked' ? 'disabled' : ''}><i class="fa-solid fa-bell"></i> Send reminder now</button>
      <button class="btn btn-secondary" data-b="edit"><i class="fa-solid fa-pen"></i> Edit</button>
      <button class="btn btn-secondary" data-b="msg"><i class="fa-solid fa-paper-plane"></i> Send a message</button>
      <button class="btn btn-secondary" data-b="done" ${b.status === 'done' ? 'disabled' : ''}><i class="fa-solid fa-circle-check"></i> Mark done</button>
      <button class="btn btn-secondary" data-b="noshow" ${b.status === 'noshow' ? 'disabled' : ''}><i class="fa-solid fa-user-slash"></i> Mark no-show</button>
      <button class="btn btn-secondary" data-b="chat" ${chat ? '' : 'disabled'}><i class="fa-brands fa-whatsapp"></i> Open chat</button>
      <button class="btn btn-secondary" data-b="cancelled" ${b.status === 'cancelled' ? 'disabled' : ''}><i class="fa-solid fa-ban"></i> Cancel booking</button>
      <button class="btn btn-secondary del" data-b="delete"><i class="fa-solid fa-trash"></i> Delete</button>
    </div>`;
  $('bookDlg').open || $('bookDlg').showModal();
};
const setStatus = async (ids, status) => {
  const r = await bg({ type: 'bookSet', ids, status });
  r.ok ? toast(`${ids.length > 1 ? `${ids.length} bookings` : 'Booking'} marked ${ST[status][0].toLowerCase()}`) : toast(r.err, true);
};
const remove = async ids => {
  if (!(await confirmBox(`Delete ${ids.length > 1 ? `${ids.length} bookings` : 'this booking'}?`, 'It is removed from this list and its time becomes free again. A copy already sent to your sheet stays there.'))) return false;
  const r = await bg({ type: 'bookDel', ids });
  r.ok ? toast('Deleted') : toast(r.err, true);
  return r.ok;
};
$('bookSide').addEventListener('click', async e => {
  const btn = e.target.closest('[data-b]');
  if (!btn || !curId) return;
  const a = btn.dataset.b, b = rows.find(r => r.id === curId);
  if (a === 'notify' || a === 'remind') { busy(btn, true); const r = await bg({ type: 'bookNotify', id: curId, kind: a }); busy(btn, false); return r.ok ? toast(a === 'remind' ? 'Reminder sent' : 'Confirmation sent') : toast(r.err, true); }
  if (a === 'chat') return void bg({ type: 'openChat', chatId: b?.chatId });
  if (a === 'edit') return openForm(b);
  if (a === 'msg') return $('bookDlg').close(), message(b);
  if (a === 'delete') return (await remove([curId])) && $('bookDlg').close();
  busy(btn, true);
  await setStatus([curId], a);
});
$('bookDlg').addEventListener('click', e => e.target.closest('[data-close]') && $('bookDlg').close());
$('bookDlg').addEventListener('close', () => { curId = null; });

// add / edit form: form LEFT, the booking + its message RIGHT
const f = $('bookForm'), fdlg = $('bookFormDlg');
const pane = p => {
  fdlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  fdlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const formRow = () => ({ at: new Date().toISOString(), no: 0, date: f.date.value, time: f.time.value, name: f.name.value.trim(), phone: f.phone.value.replace(/\D/g, ''), service: f.service.value.trim(), notes: f.notes.value.trim() });
const preview = async () => {
  const cfg = await getCfg(), b = formRow();
  $('bkPreview').innerHTML = card('Booking', 'fa-calendar-check', (kv('Day', fmtDay(b.date)) + kv('Time', fmtTime(b.time)) + kv('Service', b.service) + kv('Name', b.name) + kv('Phone', b.phone) + kv('Notes', b.notes)) || '<p class="sub">Fill the form</p>')
    + `<p class="sub need">${[!b.date && 'date', !b.time && 'time', !b.name && 'name'].filter(Boolean).map(x => `Still needed: ${x}`).join(' · ') || 'Ready to save'}</p>`;
  $('bkMsgPrev').innerHTML = waFormat(fill(cfg.bookMsg, b, cfg));
};
const slotsFor = async () => { // free times of the picked day as buttons; any other time can still be typed
  const date = f.date.value, box = $('bkSlots');
  if (!date) return void (box.innerHTML = '');
  const r = await bg({ type: 'bookFree', days: 90 }), day = (r.free || []).find(x => x.date === date);
  const times = (day?.times || []).filter(t => editId ? true : t);
  box.innerHTML = times.length ? times.map(t => `<button type="button" class="slot${f.time.value === t ? ' on' : ''}" data-t="${t}">${esc(fmtTime(t))}</button>`).join('') : '<span class="sub">No free times that day. You can still type a time.</span>';
};
$('bkSlots').addEventListener('click', e => { const b = e.target.closest('[data-t]'); if (!b) return; f.time.value = b.dataset.t; slotsFor(); preview(); });
const openForm = b => {
  editId = b?.id || null;
  $('bookFormTitle').innerHTML = `<i class="fa-solid ${editId ? 'fa-pen' : 'fa-calendar-plus'}"></i> ${editId ? `Edit ${esc(no(b))}` : 'Add booking'}`;
  f.date.value = b?.date || ''; f.time.value = b?.time || ''; f.name.value = b?.name || ''; f.phone.value = b?.phone || ''; f.service.value = b?.service || ''; f.notes.value = b?.notes || '';
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  pane('form'); slotsFor(); preview();
  $('bookDlg').open && $('bookDlg').close();
  fdlg.showModal();
  setTimeout(() => f.date.focus(), 50);
};
fdlg.addEventListener('click', e => { e.target.closest('[data-close]') && fdlg.close(); const t = e.target.closest('[data-pane]'); t && pane(t.dataset.pane); });
f.addEventListener('input', e => { e.target === f.date && slotsFor(); preview(); });
f.onsubmit = async e => {
  e.preventDefault();
  const b = formRow(), bad = !b.date ? f.date : !b.time ? f.time : !b.name ? f.name : null;
  if (bad) { bad.classList.add('bad'); bad.focus(); return toast(`Add the ${bad.name}`, true); }
  const btn = $('bookSave');
  busy(btn, true);
  try {
    const r = await bg({ type: 'bookPut', id: editId, ...b });
    if (!r.ok) return toast(r.err, true);
    fdlg.close();
    toast(editId ? 'Booking updated' : r.dup ? 'That customer already has this time' : 'Booking added');
  } finally { busy(btn, false); }
};
$('bookDemo').onclick = () => { // demo set #n for testing
  const n = demoSeq('book'), d = new Date(); d.setDate(d.getDate() + 1 + (n % 5));
  const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  f.date.value = key; f.time.value = `${String(10 + (n % 7)).padStart(2, '0')}:${n % 2 ? '30' : '00'}`;
  f.name.value = `Client ${n}`; f.phone.value = String(923001000000 + n); f.service.value = ['Haircut', 'Check-up', 'Consultation', 'Facial', 'Viewing'][n % 5]; f.notes.value = '';
  slotsFor(); preview();
};
$('bookAdd').onclick = () => openForm(null);

// pipeline, search, bulk, csv
$('bookPipe').addEventListener('click', e => { const b = e.target.closest('[data-stage]'); b && (stage = b.dataset.stage, pipe(), applyFilter()); });
$('bookSearch').oninput = applyFilter;
document.querySelectorAll('[data-bbulk]').forEach(b => b.onclick = async () => {
  const ids = table.getSelectedData().map(d => d.id);
  if (!ids.length) return;
  b.dataset.bbulk === 'delete' ? await remove(ids) : await setStatus(ids, b.dataset.bbulk);
  table.deselectRow();
});
$('bookCsv').onclick = () => {
  const list = built ? table.getData('active') : rows;
  if (!list.length) return toast('No bookings to export', true);
  download('bookings.csv', toCSV([['Booking', 'Date', 'Time', 'Status', 'Name', 'Phone', 'Service', 'Notes', 'Booked at', 'WhatsApp'],
    ...list.map(b => [no(b), b.date, b.time, b.status, b.name, b.phone, b.service, b.notes, b.at, b.chatName])]));
};

// setup page: day chips write the hidden field; free-time preview from the saved settings
const chips = () => {
  const on = new Set($('bookDays').value.split(',').map(s => s.trim()));
  $('bookDayChips').innerHTML = DAYS.map(([k, l]) => `<button type="button" class="chip${on.has(k) ? ' on' : ''}" data-day="${k}" aria-pressed="${on.has(k)}">${l}</button>`).join('');
};
$('bookDayChips').addEventListener('click', e => {
  const b = e.target.closest('[data-day]');
  if (!b) return;
  const on = new Set($('bookDays').value.split(',').map(s => s.trim()).filter(Boolean));
  on.has(b.dataset.day) ? on.delete(b.dataset.day) : on.add(b.dataset.day);
  $('bookDays').value = DAYS.map(([k]) => k).filter(k => on.has(k)).join(',');
  $('bookDays').dispatchEvent(new Event('input', { bubbles: true })); // the settings page sees the change
  chips();
});
// setup page: quick picks, chip lists, breaks, message tags, live preview (unsaved edits included)
const WHAT = ['appointment', 'visit', 'table', 'class', 'viewing', 'session', 'consultation'];
const FIELDS = ['name', 'phone', 'service', 'people', 'doctor', 'stylist', 'notes'];
const TAGS = ['no', 'what', 'date', 'time', 'when', 'service', 'name', 'phone'];
const draft = () => ({ bookDays: $('bookDays').value, bookFrom: $('bookFrom').value, bookTo: $('bookTo').value, bookSlot: +$('bookSlot').value || 30,
  bookCap: +$('bookCap').value || 1, bookBreak: $('bookBreak').value, bookAhead: +$('bookAhead').value || 14,
  bookLeadH: $('bookLeadH').value, bookPerDay: $('bookPerDay').value, bookClosed: $('bookClosed').value || ' ' });
let firstFree = null, freeN = 0;
const freeList = async () => {
  const r = await bg({ type: 'bookFree', days: 7, draft: draft() }), free = r.free || [];
  firstFree = free[0] ? { date: free[0].date, time: free[0].times[0] } : null;
  freeN = free.reduce((n, x) => n + x.times.length, 0);
  $('bookFreeList').innerHTML = free.length ? free.slice(0, 5).map(x => `<div class="bk-fday"><b>${esc(fmtDay(x.date))}</b><div>${x.times.slice(0, 6).map(t => `<span>${esc(fmtTime(t))}</span>`).join('')}${x.times.length > 6 ? `<em>+${x.times.length - 6}</em>` : ''}</div></div>`).join('')
    : '<p class="sub">No free times in the next 7 days with these settings.</p>';
  previewMsgs();
};
const summary = () => {
  const lead = +$('bookLeadH').value, max = +$('bookPerDay').value, closed = list($('bookClosed').value).length, sv = list($('bookServices').value).length;
  $('bookSum').innerHTML = [
    ['fa-calendar-day', `<b>${freeN}</b> free times in 7 days`],
    ['fa-forward', firstFree ? `First: <b>${esc(fmtDay(firstFree.date))}, ${esc(fmtTime(firstFree.time))}</b>` : 'No free time soon'],
    ['fa-hourglass-half', lead ? `Book at least <b>${lead} ${lead === 1 ? 'hour' : 'hours'}</b> ahead` : 'Book right up to the time'],
    ['fa-gauge', max ? `Up to <b>${max}</b> a day` : 'No daily limit'],
    ['fa-list', sv ? `<b>${sv}</b> ${sv === 1 ? 'service' : 'services'} offered` : 'Any service'],
    ['fa-calendar-xmark', closed ? `<b>${closed}</b> closed ${closed === 1 ? 'date' : 'dates'}` : 'No closed dates']
  ].map(([i, t]) => `<li><i class="fa-solid ${i}"></i><span>${t}</span></li>`).join('');
};
const previewMsgs = () => {
  const extra = extraTags($('bookFields').value, TAGS);
  const b = { at: new Date().toISOString(), no: 1, date: firstFree?.date || todayKey(), time: firstFree?.time || $('bookFrom').value, service: list($('bookServices').value)[0] || 'Consultation', name: 'Client 1', phone: '03001000001',
    extra: Object.fromEntries(extra.map(k => [k, `[${k}]`])) };
  const cf = { bookWhat: $('bookWhat').value || 'appointment' };
  $('bookMsgPrev').innerHTML = waFormat(fill($('bookMsg').value, b, cf)) || '<span class="sub">No message</span>';
  $('bookRemPrev').innerHTML = waFormat(fill($('bookRemindMsg').value, b, cf)) || '<span class="sub">No message</span>';
  $('bookRemPrev').hidden = $('bkRemPrevH').hidden = $('bkRemField').hidden = !$('bookRemind').checked;
  summary();
};
const paintSetup = () => {
  const root = $('bookSetup'), fl = list($('bookFields').value).map(f => f.toLowerCase());
  $('bkWhatPre').innerHTML = WHAT.map(w => `<button type="button" class="bk-pre" data-v="${w}">${w}</button>`).join('');
  $('bkFieldPre').innerHTML = [...new Set([...FIELDS, ...fl])].map(f => `<button type="button" class="bk-pre" data-pre-for="bookFields" data-v="${esc(f)}"><i class="fa-solid fa-plus"></i> ${esc(f)}</button>`).join('');
  const br = list($('bookBreak').value);
  $('bookBreakList').innerHTML = br.length ? br.map((r, i) => `<span class="bk-chip"><i class="fa-solid fa-mug-hot"></i>${esc(r.replace(/\s/g, '').split('-').map(fmtTime).join(' – '))}<button type="button" data-br="${i}" aria-label="Remove this break"><i class="fa-solid fa-xmark"></i></button></span>`).join('')
    : '<span class="sub">No breaks: every time between your hours can be booked.</span>';
  paintTags(root, [...TAGS, ...extraTags($('bookFields').value, TAGS)]);
  paintPicks(root);
  paintChips(root);
  $('bookOnTxt').textContent = $('bookOn').checked ? 'On' : 'Off';
  root.classList.toggle('bk-paused', !$('bookOn').checked);
  previewMsgs();
};
let freeT = 0;
$('bookSetup').addEventListener('input', e => {
  paintSetup();
  /^(bookDays|bookFrom|bookTo|bookSlot|bookCap|bookBreak|bookAhead|bookLeadH|bookPerDay|bookClosed)$/.test(e.target.id) && (clearTimeout(freeT), freeT = setTimeout(freeList, 300));
});
$('bookSetup').addEventListener('change', e => e.target.id === 'bookOn' || e.target.id === 'bookRemind' ? paintSetup() : null);
// breaks: two times, start before end
$('bookSetup').addEventListener('click', e => {
  const t = e.target.closest('[data-br], #brAdd');
  if (!t) return;
  if (t.dataset.br) return setVal('bookBreak', list($('bookBreak').value).filter((_, i) => i !== +t.dataset.br).join(', '));
  const a = $('brFrom').value, z = $('brTo').value;
  if (!a || !z || a >= z) return toast('Pick when the break starts and ends', true);
  setVal('bookBreak', [...list($('bookBreak').value), `${a}-${z}`].join(', '));
  $('brFrom').value = $('brTo').value = '';
});
addEventListener('waai:saved', () => { chips(); paintSetup(); freeList(); });
addEventListener('waai:view', e => {
  if (e.detail === 'bookset') { chips(); paintSetup(); freeList(); }
  if (e.detail !== 'bookings') return;
  table ? built && table.redraw(true) : build();
});
chrome.storage.onChanged.addListener(c => { c.bookings && load(); c.cfg && (load(), freeList()); });
load();
chips();
