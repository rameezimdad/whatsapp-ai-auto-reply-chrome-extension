/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// orders page: Tabulator list, status pipeline, bulk bar, detail popup
import { $, esc, bg, toast, busy, confirmBox, toCSV, download, waFormat, userCell } from './ui.js';
import { getCfg, demoSeq, orderNo as no, orderCur, fillOrder } from './cfg.js';
import { openMsg } from './msg.js';

const ST = {
  new: ['New', 'c-new', 'fa-circle-dot'], confirmed: ['Confirmed', 'c-human', 'fa-circle-check'],
  done: ['Done', 'c-sent', 'fa-truck'], cancelled: ['Cancelled', 'c-error', 'fa-ban']
};
let rows = [], table = null, built = false, stage = 'all', curId = null;

const money = n => (+n || 0).toLocaleString('en-US');
const when = iso => new Date(iso).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
const itemsLine = o => o.items.map(i => `${i.qty} x ${i.name}`).join(', ');
const pill = s => { const [l, c, i] = ST[s] || ST.new; return `<span class="pill ${c}"><i class="fa-solid ${i}"></i> ${l}</span>`; };

// table
const build = () => {
  table = new Tabulator($('ordTable'), {
    data: rows,
    layout: 'fitColumns',
    responsiveLayout: 'collapse',
    placeholder: 'No orders yet. When the AI takes an order it shows up here.',
    pagination: 'local', paginationSize: 10, paginationSizeSelector: [10, 25, 50, 100, true], paginationCounter: 'rows',
    movableColumns: true,
    selectableRows: 'highlight',
    rowHeader: { formatter: 'rowSelection', titleFormatter: 'rowSelection', titleFormatterParams: { rowRange: 'active' }, headerSort: false, resizable: false,
      frozen: true, headerHozAlign: 'center', hozAlign: 'center', width: 46, download: false, cellClick: (e, c) => c.getRow().toggleSelect() },
    columns: [
      { title: 'Order', field: 'no', sorter: 'number', minWidth: 130, formatter: c => { const o = c.getData(); return `<b class="mono tb-no">${esc(no(o))}</b>${o.type === 'lead' ? ' <span class="pill c-skip">Lead</span>' : ''}`; } },
      { title: 'Date', field: 'at', minWidth: 130, formatter: c => esc(when(c.getValue())) },
      { title: 'Customer', field: 'name', minWidth: 180, formatter: c => { const o = c.getData(); return userCell(o.name || o.chatName || '-', o.phone || ''); } },
      { title: 'City', field: 'city', minWidth: 100, formatter: c => esc(c.getValue() || '-') },
      { title: 'Items', field: 'itemsLine', minWidth: 180, formatter: c => `<span class="clip">${esc(c.getValue() || '-')}</span>` },
      { title: 'Total', field: 'total', sorter: 'number', hozAlign: 'right', minWidth: 100, formatter: c => `<b class="num tb-money">${esc(orderCur(c.getData()))} ${money(c.getValue())}</b>` },
      { title: 'Status', field: 'status', minWidth: 120, formatter: c => pill(c.getValue()) },
      { title: 'Actions', field: 'id', headerSort: false, download: false, width: 168, hozAlign: 'right', formatter: () => ACT_ICONS,
        cellClick: (e, c) => { const b = e.target.closest('[data-act]'); b && rowAct(b.dataset.act, c.getData(), b); } }
    ]
  });
  table.on('rowSelectionChanged', d => {
    $('ordSel').textContent = d.length;
    document.querySelectorAll('[data-bulk]').forEach(b => b.disabled = !d.length);
  });
  table.on('tableBuilt', () => { built = true; table.setData(rows); applyFilter(); });
};

// row actions: open · edit · message · delete
const ACT_ICONS = '<button class="nav-btn ic-view" data-act="view" aria-label="Open" title="Open"><i class="fa-solid fa-eye"></i></button>'
  + '<button class="nav-btn ic-edit" data-act="edit" aria-label="Edit" title="Edit"><i class="fa-solid fa-pen"></i></button>'
  + '<button class="nav-btn ic-msg" data-act="msg" aria-label="Send a message" title="Send a message"><i class="fa-brands fa-whatsapp"></i></button>'
  + '<button class="nav-btn ic-del" data-act="del" aria-label="Delete" title="Delete"><i class="fa-solid fa-trash"></i></button>';
const rowAct = (a, o) => a === 'view' ? openOrder(o.id) : a === 'edit' ? openForm(o) : a === 'msg' ? message(o) : remove([o.id]);
const message = async o => {
  const cfg = await getCfg(), c = orderCur(o, cfg), f = t => fillOrder(t, o, cfg);
  openMsg({ kind: 'order', id: o.id, chatId: o.chatId, since: o.at, who: o.name || o.chatName, phone: o.phone, list: [
    ['Confirmation', 'fa-circle-check', f(cfg.orderMsg)],
    ['On the way', 'fa-truck', f(`Hi {name}, your order {no} is on its way. It will reach {city} soon.`)],
    ['Delivered', 'fa-box-open', f(`Hi {name}, your order {no} has been delivered. Thank you for shopping with us!`)],
    ['Payment', 'fa-wallet', f(`Hi {name}, the total for order {no} is ${c} {total}.${cfg.orderPay.trim() ? `\nYou can pay by:\n${cfg.orderPay.trim()}` : ''}`)]] });
};
const applyFilter = () => {
  if (!built) return;
  const k = $('ordSearch').value.trim().toLowerCase();
  table.setFilter(d => (stage === 'all' || d.status === stage) && (!k || `${d.name} ${d.phone} ${d.city} ${d.address} ${d.itemsLine} ${no(d)}`.toLowerCase().includes(k)));
};

const pipe = () => {
  const n = s => s === 'all' ? rows.length : rows.filter(r => r.status === s).length;
  $('ordPipe').innerHTML = ['all', 'new', 'confirmed', 'done', 'cancelled'].map(s => `<button role="tab" aria-selected="${s === stage}" class="${s === stage ? 'active' : ''}" data-stage="${s}">
    ${s === 'all' ? '<i class="fa-solid fa-layer-group"></i> All' : `<i class="fa-solid ${ST[s][2]}"></i> ${ST[s][0]}`} <b>${n(s)}</b></button>`).join('');
};

// KPI row: each footer filters the Tabulator list like the status tabs
const kpiBox = ([cls, val, label, ic, st, more]) => `<div class="small-box ${cls}"><div class="inner"><h3>${val}</h3><p>${label}</p></div><i class="icon fa-solid ${ic}"></i>
  <button type="button" class="small-box-footer" data-kstage="${st}">${more} <i class="fa-solid fa-circle-arrow-right"></i></button></div>`;
const kpis = () => {
  const m = new Date().toISOString().slice(0, 7), n = s => rows.filter(r => r.status === s).length;
  const sales = rows.filter(r => (r.status === 'confirmed' || r.status === 'done') && String(r.at).slice(0, 7) === m).reduce((t, r) => t + (+r.total || 0), 0);
  $('ordKpis').innerHTML = [['bg-info', n('new'), 'New, waiting for you', 'fa-bell', 'new', 'See new'], ['bg-success', n('confirmed'), 'Confirmed', 'fa-circle-check', 'confirmed', 'See confirmed'],
    ['bg-navy', `<small>${esc(orderCur(rows[0]))}</small> ${money(sales)}`, 'Sales this month', 'fa-sack-dollar', 'done', 'See done'], ['bg-danger', n('cancelled'), 'Cancelled', 'fa-ban', 'cancelled', 'See cancelled']].map(kpiBox).join('');
};
$('ordKpis').addEventListener('click', e => { const b = e.target.closest('[data-kstage]'); if (!b) return; stage = b.dataset.kstage; pipe(); applyFilter(); $('ordPipe').scrollIntoView({ behavior: 'smooth', block: 'start' }); });

const load = async () => {
  rows = ((await chrome.storage.local.get('orders')).orders || []).map(o => ({ ...o, itemsLine: itemsLine(o) }));
  const fresh = rows.filter(r => r.status === 'new').length;
  $('pillOrders').hidden = !fresh;
  $('pillOrders').textContent = fresh > 99 ? '99+' : fresh;
  $('ordCount').textContent = rows.length;
  pipe();
  kpis();
  built && (table.replaceData(rows), applyFilter());
  curId && $('ordDlg').open && openOrder(curId);
};

// detail popup
const card = (title, ic, body) => `<div class="ord-card"><h4><i class="fa-solid ${ic}"></i> ${title}</h4>${body}</div>`;
const kv = (k, v) => v ? `<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>` : '';
const openOrder = async id => {
  const o = rows.find(r => r.id === id);
  if (!o) return $('ordDlg').open && $('ordDlg').close();
  curId = id;
  const cfg = await getCfg(), late = Date.now() - new Date(o.at) > 864e5;
  $('ordTitle').innerHTML = `<i class="fa-solid fa-bag-shopping"></i> ${esc(no(o))} ${pill(o.status)}${o.type === 'lead' ? ' <span class="pill c-skip">Lead</span>' : ''}`;
  $('ordInfo').innerHTML = `<div class="ord-cards">
    ${card('Customer', 'fa-user', kv('Name', o.name) + kv('Phone', o.phone) + kv('WhatsApp name', o.chatName))}
    ${card('Delivery', 'fa-truck', (kv('City', o.city) + kv('Address', o.address)) || '<p class="sub">Not given</p>')}
    </div>
    ${card('Items', 'fa-list', o.items.length ? `<table class="ord-items"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead><tbody>
      ${o.items.map(i => `<tr><td>${esc(i.name)}</td><td class="num">${i.qty}</td><td class="num">${i.price ? money(i.price) : '-'}</td><td class="num">${i.price ? money(i.qty * i.price) : '-'}</td></tr>`).join('')}
      </tbody><tfoot>${+o.delivery ? `<tr><td colspan="3">Delivery</td><td class="num">${money(o.delivery)}</td></tr>` : ''}<tr><td colspan="3">Total</td><td class="num">${esc(orderCur(o))} ${money(o.total)}</td></tr></tfoot></table>` : '<p class="sub">No items, this is a lead</p>')}
    ${Object.keys(o.extra || {}).length || o.notes ? card('More details', 'fa-note-sticky', Object.entries(o.extra || {}).map(([k, v]) => kv(k.replace(/_/g, ' '), v)).join('') + kv('Notes', o.notes)) : ''}
    ${card('History', 'fa-clock-rotate-left', kv('Taken', when(o.at)) + kv('Updated', o.upd && when(o.upd)) + kv('Customer messaged', o.notified && when(o.notified)))}`;
  $('ordSide').innerHTML = `<h3><i class="fa-brands fa-whatsapp"></i> Confirm and message</h3>
    <div class="wa-phone"><div class="bubble out">${waFormat(fillOrder(cfg.orderMsg, o, cfg))}</div></div>
    ${late ? '<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> More than 24 hours have passed. Message this customer yourself from WhatsApp.</p>' : ''}
    <div class="ord-acts">
      <button class="btn btn-primary" data-o="notify" ${late || o.status !== 'new' ? 'disabled' : ''}><i class="fa-solid fa-paper-plane"></i> Confirm and message</button>
      <button class="btn btn-secondary" data-o="confirmed" ${o.status === 'confirmed' ? 'disabled' : ''}><i class="fa-solid fa-circle-check"></i> Mark confirmed (no message)</button>
      <button class="btn btn-secondary" data-o="done" ${o.status === 'done' ? 'disabled' : ''}><i class="fa-solid fa-truck"></i> Mark done</button>
      <button class="btn btn-secondary" data-o="edit"><i class="fa-solid fa-pen"></i> Edit</button>
      <button class="btn btn-secondary" data-o="msg"><i class="fa-solid fa-paper-plane"></i> Send a message</button>
      <button class="btn btn-secondary" data-o="chat"><i class="fa-brands fa-whatsapp"></i> Open chat</button>
      <button class="btn btn-secondary" data-o="cancelled" ${o.status === 'cancelled' ? 'disabled' : ''}><i class="fa-solid fa-ban"></i> Cancel order</button>
      <button class="btn btn-secondary del" data-o="delete"><i class="fa-solid fa-trash"></i> Delete</button>
    </div>`;
  $('ordDlg').open || $('ordDlg').showModal();
};

const notify = async (id, btn) => {
  busy(btn, true);
  const r = await bg({ type: 'orderNotify', id });
  busy(btn, false);
  r.ok ? toast('Order confirmed and the customer got the message') : toast(r.err, true);
};
const setStatus = async (ids, status) => {
  const r = await bg({ type: 'orderSet', ids, status });
  r.ok ? toast(`${ids.length > 1 ? `${ids.length} orders` : 'Order'} marked ${ST[status][0].toLowerCase()}`) : toast(r.err, true);
};
const remove = async ids => {
  if (!(await confirmBox(`Delete ${ids.length > 1 ? `${ids.length} orders` : 'this order'}?`, 'It is removed from this list. A copy already sent to your sheet stays there.'))) return false;
  const r = await bg({ type: 'orderDel', ids });
  r.ok ? toast('Deleted') : toast(r.err, true);
  return r.ok;
};

$('ordSide').addEventListener('click', async e => {
  const b = e.target.closest('[data-o]');
  if (!b || !curId) return;
  const a = b.dataset.o;
  if (a === 'notify') return notify(curId, b);
  if (a === 'chat') { await bg({ type: 'openChat', chatId: rows.find(r => r.id === curId)?.chatId }); return; }
  if (a === 'delete') return (await remove([curId])) && $('ordDlg').close();
  const o = rows.find(r => r.id === curId);
  if (a === 'edit') return $('ordDlg').close(), openForm(o);
  if (a === 'msg') return $('ordDlg').close(), message(o);
  busy(b, true);
  await setStatus([curId], a);
});
$('ordDlg').addEventListener('click', e => e.target.closest('[data-close]') && $('ordDlg').close());
$('ordDlg').addEventListener('close', () => { curId = null; });

// add / edit form: form LEFT, the order + its message RIGHT
const f = $('ordForm'), fdlg = $('ordFormDlg');
let editId = null;
const pane = p => {
  fdlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  fdlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const itemRow = (i = {}) => `<div class="of-item"><input class="field" data-i="name" maxlength="120" placeholder="Product A" value="${esc(i.name || '')}" aria-label="Item">
  <input class="field" type="number" data-i="qty" min="1" step="1" value="${+i.qty || 1}" aria-label="Quantity"><input class="field" type="number" data-i="price" min="0" step="10" placeholder="Price" value="${i.price ? +i.price : ''}" aria-label="Price">
  <button type="button" class="nav-btn del" data-rm aria-label="Remove item" title="Remove item"><i class="fa-solid fa-xmark"></i></button></div>`;
const formItems = () => [...$('ofItems').querySelectorAll('.of-item')].map(r => ({ name: r.querySelector('[data-i=name]').value.trim(), qty: +r.querySelector('[data-i=qty]').value || 1, price: +r.querySelector('[data-i=price]').value || 0 })).filter(i => i.name);
const formRow = () => {
  const items = formItems(), delivery = +f.delivery.value || 0;
  return { at: new Date().toISOString(), no: 0, type: f.type.value, name: f.name.value.trim(), phone: f.phone.value.replace(/\D/g, ''), city: f.city.value.trim(), address: f.address.value.trim(),
    items, delivery, total: items.reduce((t, i) => t + i.qty * i.price, 0) + delivery, notes: f.notes.value.trim() };
};
const preview = async () => {
  const cfg = await getCfg(), o = formRow(), c = orderCur(o, cfg);
  fdlg.querySelectorAll('[data-type]').forEach(b => b.classList.toggle('on', b.dataset.type === o.type));
  fdlg.querySelectorAll('.cur-u').forEach(u => u.textContent = c);
  $('ofPreview').innerHTML = card(o.type === 'lead' ? 'Lead' : 'Order', 'fa-bag-shopping', (kv('Name', o.name) + kv('Phone', o.phone) + kv('City', o.city) + kv('Address', o.address)
    + o.items.map(i => kv(`${i.qty} x ${i.name}`, i.price ? `${c} ${money(i.qty * i.price)}` : '-')).join('') + kv('Delivery', o.delivery ? `${c} ${money(o.delivery)}` : '') + kv('Total', o.items.length ? `${c} ${money(o.total)}` : '')) || '<p class="sub">Fill the form</p>')
    + `<p class="sub need">${!o.name && !o.phone ? 'Still needed: a name or a WhatsApp number' : 'Ready to save'}</p>`;
  $('ofMsgPrev').innerHTML = waFormat(fillOrder(cfg.orderMsg, { ...o, no: editId ? rows.find(r => r.id === editId)?.no || 0 : 0 }, cfg));
};
const openForm = async o => {
  editId = o?.id || null;
  const cfg = await getCfg();
  $('ordFormTitle').innerHTML = `<i class="fa-solid ${editId ? 'fa-pen' : 'fa-cart-plus'}"></i> ${editId ? `Edit ${esc(no(o))}` : 'Add order'}`;
  f.type.value = o?.type || 'order'; f.name.value = o?.name || ''; f.phone.value = o?.phone || ''; f.city.value = o?.city || ''; f.address.value = o?.address || '';
  f.delivery.value = o ? +o.delivery || 0 : +cfg.orderDelivery || 0; f.notes.value = o?.notes || '';
  $('ofItems').innerHTML = (o?.items?.length ? o.items : [{}]).map(itemRow).join('');
  f.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  pane('form'); preview();
  fdlg.showModal();
  setTimeout(() => f.name.focus(), 50);
};
$('ofAddItem').onclick = () => { $('ofItems').insertAdjacentHTML('beforeend', itemRow()); $('ofItems').lastElementChild.querySelector('input').focus(); preview(); };
$('ofItems').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (!b) return; $('ofItems').children.length > 1 ? b.closest('.of-item').remove() : b.closest('.of-item').querySelectorAll('input').forEach(i => i.value = i.dataset.i === 'qty' ? 1 : ''); preview(); });
fdlg.addEventListener('click', e => {
  e.target.closest('[data-close]') && fdlg.close();
  const t = e.target.closest('[data-pane]'); t && pane(t.dataset.pane);
  const ty = e.target.closest('[data-type]'); ty && (f.type.value = ty.dataset.type, preview());
});
f.addEventListener('input', preview);
f.onsubmit = async e => {
  e.preventDefault();
  const o = formRow();
  if (!o.name && !o.phone) { f.name.classList.add('bad'); f.name.focus(); return toast('Add a name or a WhatsApp number', true); }
  const btn = $('ordSave');
  busy(btn, true);
  try {
    const r = await bg({ ...o, type: 'orderPut', kind: o.type, id: editId }); // the row's own type rides as kind
    if (!r.ok) return toast(r.err, true);
    fdlg.close();
    toast(editId ? 'Order updated' : 'Order added');
  } finally { busy(btn, false); }
};
$('ordDemo').onclick = () => { // demo set #n for testing
  const n = demoSeq('order');
  f.type.value = 'order'; f.name.value = `Client ${n}`; f.phone.value = String(923001000000 + n); f.city.value = 'Demo City'; f.address.value = `House ${n}, Street ${n}, Demo City`; f.notes.value = '';
  $('ofItems').innerHTML = [{ name: 'Product A', qty: 1 + (n % 3), price: 1000 }, { name: 'Product B', qty: 1, price: 1500 }].map(itemRow).join('');
  preview();
};
$('ordAdd').onclick = () => openForm(null);

// pipeline, search, bulk, csv
$('ordPipe').addEventListener('click', e => { const b = e.target.closest('[data-stage]'); b && (stage = b.dataset.stage, pipe(), applyFilter()); });
$('ordSearch').oninput = applyFilter;
document.querySelectorAll('[data-bulk]').forEach(b => b.onclick = async () => {
  const ids = table.getSelectedData().map(d => d.id);
  if (!ids.length) return;
  b.dataset.bulk === 'delete' ? await remove(ids) : await setStatus(ids, b.dataset.bulk);
  table.deselectRow();
});
$('ordCsv').onclick = () => {
  const list = built ? table.getData('active') : rows;
  if (!list.length) return toast('No orders to export', true);
  download('orders.csv', toCSV([['Order', 'Date', 'Type', 'Status', 'Name', 'Phone', 'City', 'Address', 'Items', 'Total', 'Notes'],
    ...list.map(o => [no(o), o.at, o.type, o.status, o.name, o.phone, o.city, o.address, itemsLine(o), o.total, o.notes])]));
};

// build the first time the page is shown, Tabulator needs a visible box
addEventListener('waai:view', e => {
  if (e.detail !== 'orders') return;
  table ? built && table.redraw(true) : build();
});
chrome.storage.onChanged.addListener(c => c.orders && load());
load();
