/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// Google sign-in + the owner's own Google Sheet. Orders, bookings, customers, quick replies (and their files), knowledge,
// opt-outs and settings go there; the same sign-in on another computer brings them back. Only files this extension
// makes can be reached (drive.file). API keys never leave this browser.
// Rows match by the hidden _id column. Newer copy wins, a cell changed in the Sheet (status, name, notes…) comes back
// here, a row deleted here goes from the Sheet, a row this copy never saw is added here.
import { DEFAULTS, SECRET, getCfg, setCfg } from './cfg.js';
import { licGoogleLink } from './license.js';

const CLIENT = '792663243559-2vb88152rqui86s2dojf1t1ui9t6t0nk.apps.googleusercontent.com'; // rameezscripts.com Google login
const BACK = 'https://rameezscripts.com/ext-auth.html'; // hands Google's answer to this extension
const SCOPE = 'openid email profile https://www.googleapis.com/auth/drive.file';
const SHEETS = 'https://sheets.googleapis.com/v4/spreadsheets', DRIVE = 'https://www.googleapis.com/drive/v3/files', UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files';
const TABS_V = 2; // bump when tabs or columns change
const MIN = 60000;
const store = chrome.storage.local, sess = chrome.storage.session;
const gErr = (msg, kind = '') => Object.assign(new Error(msg), { kind });

// sign-in
const authUrl = (state, o) => `https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({ client_id: CLIENT, redirect_uri: BACK, scope: SCOPE, state, include_granted_scopes: 'true', ...o })}`;
const webAuth = async (url, interactive) => {
  try { return await chrome.identity.launchWebAuthFlow({ url, interactive, ...(!interactive && { abortOnLoadForNonInteractive: false, timeoutMsForNonInteractive: 20000 }) }); }
  catch (e) { if (interactive || !/Unexpected property/i.test(e.message)) throw e; return chrome.identity.launchWebAuthFlow({ url, interactive }); } // Chrome before 113
};
const jwt = t => { try { return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0)))); } catch { return {}; } };
// interactive = the Google window; silent = the same account again with no window (fails when Google wants a click)
const signIn = async ({ interactive, hint = '', id = false }) => {
  const nonce = crypto.randomUUID().replace(/-/g, ''), state = `${nonce}.${chrome.runtime.id}`;
  let back;
  try { back = await webAuth(authUrl(state, { response_type: id ? 'token id_token' : 'token', ...(id && { nonce }), ...(hint && { login_hint: hint }), prompt: interactive ? 'select_account' : 'none' }), interactive); }
  catch (e) { throw gErr(interactive ? 'Google sign-in was closed before it finished.' : 'Google sign-in has expired. Sign in again.', 'login'); }
  const p = new URLSearchParams(new URL(back).hash.slice(1));
  if (p.get('error')) throw gErr(p.get('error') === 'access_denied' ? 'Google sign-in was cancelled.' : 'Google sign-in did not finish. Try again.', 'login');
  if (p.get('state') !== state || !p.get('access_token')) throw gErr('The Google answer could not be checked. Try again.', 'login');
  if (!String(p.get('scope')).includes('drive.file')) throw gErr('Tick the Google Drive box on the Google page, so your data can be saved in your own Google Sheet.', 'login');
  const tok = { t: p.get('access_token'), exp: Date.now() + (+p.get('expires_in') || 3600) * 1000 };
  await sess.set({ gTok: tok });
  if (!id) return { tok };
  const c = jwt(p.get('id_token') || '');
  if (c.nonce !== nonce || c.aud !== CLIENT || !c.email) throw gErr('The Google answer could not be checked. Try again.', 'login');
  return { tok, gid: p.get('id_token'), acct: { email: String(c.email).toLowerCase(), name: String(c.name || c.email.split('@')[0]).slice(0, 80) } };
};
let silent = null;
const token = async () => {
  const { gTok } = await sess.get('gTok');
  if (gTok?.exp - Date.now() > 2 * MIN) return gTok.t;
  const { gAcct } = await store.get('gAcct');
  if (!gAcct?.email) throw gErr('Sign in with Google first.', 'login');
  silent ??= signIn({ interactive: false, hint: gAcct.email }).finally(() => { silent = null; });
  return (await silent).tok.t;
};

// Google APIs
const gfetch = async (url, opt = {}, again = true) => {
  const r = await fetch(url, { ...opt, headers: { Authorization: `Bearer ${await token()}`, ...opt.headers }, signal: AbortSignal.timeout(90000) })
    .catch(() => { throw gErr('Could not reach Google. Check the internet.', 'net'); });
  if (r.status === 401 && again) { await sess.remove('gTok'); return gfetch(url, opt, false); }
  if (r.ok) return r;
  const m = (await r.json().catch(() => ({})))?.error?.message || `HTTP ${r.status}`;
  throw gErr(r.status === 401 ? 'Google sign-in has expired. Sign in again.' : r.status === 404 ? 'Your Google Sheet was not found.' : `Google: ${m}`,
    r.status === 401 ? 'login' : r.status === 404 ? 'gone' : /parse range/i.test(m) ? 'tabs' : '');
};
const gjson = (url, body, method = body ? 'POST' : 'GET') => gfetch(url, { method, ...(body && { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }) }).then(r => r.json());
const findFile = async tag => (await gjson(`${DRIVE}?${new URLSearchParams({ q: `appProperties has { key='waai' and value='${tag}' } and trashed = false`, orderBy: 'modifiedTime desc', fields: 'files(id,name)', pageSize: '1' })}`)).files?.[0] || null;
const q1 = s => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
const findByName = async name => (await gjson(`${DRIVE}?${new URLSearchParams({ q: `name = '${q1(name)}' and mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false`, fields: 'files(id,name)', pageSize: '1' })}`)).files?.[0] || null;
const makeFile = (name, mimeType, tag) => gjson(`${DRIVE}?fields=id,name`, { name, mimeType, appProperties: { waai: tag } });

// what goes in the Sheet: [header, value, edit from the Sheet]
const p2 = n => String(n).padStart(2, '0');
const when = v => { const d = v ? new Date(v) : null; return !d || isNaN(d) ? '' : `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
const yes = v => v ? 'Yes' : 'No';
const docNo = (pre, x) => x.no ? `${pre}-${String(x.at).slice(0, 4)}-${String(x.no).padStart(3, '0')}` : '';
const txt = (field, max) => ({ field, read: c => String(c ?? '').trim().slice(0, max) });
const pick = (field, list) => ({ field, read: c => list.includes(String(c).trim().toLowerCase()) ? String(c).trim().toLowerCase() : undefined });
const ORDER_ST = ['new', 'confirmed', 'done', 'cancelled'], BOOK_ST = ['booked', 'done', 'noshow', 'cancelled'], SCREEN_ST = ['new', 'qualified', 'contacted', 'nofit'];
const TABS = [
  { tab: 'Orders', key: 'orders', arr: true, sort: true, count: 'orderNo', status: ORDER_ST, cols: [
    ['Order no', v => docNo('ORD', v)], ['Date', v => when(v.at)], ['Status', v => v.status, pick('status', ORDER_ST)], ['Type', v => v.type],
    ['Name', v => v.name, txt('name', 300)], ['Phone', v => v.phone, txt('phone', 40)], ['City', v => v.city, txt('city', 300)], ['Address', v => v.address, txt('address', 300)],
    ['Items', v => (v.items || []).map(i => `${i.qty} x ${i.name}${i.price ? ` @ ${i.price}` : ''}`).join('; ')], ['Total', v => +v.total || 0],
    ['Notes', v => v.notes, txt('notes', 300)], ['WhatsApp name', v => v.chatName], ['Updated', v => when(v.upd || v.at)]] },
  { tab: 'Bookings', key: 'bookings', arr: true, sort: true, count: 'bookNo', status: BOOK_ST, cols: [
    ['Booking no', v => docNo('BK', v)], ['Date', v => v.date], ['Time', v => v.time], ['Service', v => v.service], ['Status', v => v.status, pick('status', BOOK_ST)],
    ['Name', v => v.name, txt('name', 300)], ['Phone', v => v.phone, txt('phone', 40)], ['Notes', v => v.notes, txt('notes', 300)],
    ['Booked on', v => when(v.at)], ['Updated', v => when(v.upd || v.at)]] },
  { tab: 'Screening', key: 'screens', arr: true, sort: true, count: 'screenNo', status: SCREEN_ST, cols: [
    ['No', v => docNo('SCR', v)], ['Date', v => when(v.at)], ['Status', v => v.status, pick('status', SCREEN_ST)], ['Name', v => v.name, txt('name', 300)], ['Phone', v => v.phone, txt('phone', 40)],
    ['Details', v => Object.entries(v.fields || {}).filter(([k]) => k !== 'name' && k !== 'phone').map(([k, x]) => `${k.replace(/_/g, ' ')}: ${x}`).join(' · ')],
    ['Summary', v => v.summary, txt('summary', 300)], ['Notes', v => v.notes, txt('notes', 300)], ['WhatsApp name', v => v.chatName], ['Updated', v => when(v.upd || v.at)]] },
  { tab: 'Customers', key: 'memo', valid: (k, v) => CHAT.test(k) && typeof v === 'object' && !Array.isArray(v), cols: [
    ['Name', v => v.name, txt('name', 80)], ['Phone', (v, k) => /@c\.us$/.test(k) ? `+${k.split('@')[0]}` : ''],
    ['Tags', v => (v.tags || []).join(', '), { field: 'tags', read: c => [...new Set(String(c ?? '').split(',').map(t => t.trim().slice(0, 30)).filter(Boolean))].slice(0, 10) }],
    ['Reply language', v => v.lang], ['My notes', v => v.o, txt('o', 1000)], ['AI notes', v => v.s], ['Updated', v => when(v.at)]] },
  { tab: 'Quick replies', key: 'qr', arr: true, cols: [
    ['Code', v => v.code], ['Reply', v => v.text, txt('text', 4000)], ['When to use', v => v.when, txt('when', 200)], ['On', v => yes(v.on)],
    ['Times used', v => +v.uses || 0], ['Files', v => (v.files || []).map(f => f.name).join(', ')]] },
  { tab: 'Knowledge', key: 'kb', arr: true, cols: [
    ['Title', v => v.title, txt('title', 80)], ['Fact', v => v.text, txt('text', 1500)], ['Tags', v => v.tags, txt('tags', 120)], ['Pinned', v => yes(v.pinned)], ['On', v => yes(v.on)]] },
  { tab: 'Opted out', key: 'optout', valid: (k, v) => CHAT.test(k) && typeof v === 'number', cols: [['WhatsApp chat', (v, k) => k], ['Since', v => when(v)]] }
];
const HEAD = Object.fromEntries([...TABS.map(T => [T.tab, [...T.cols.map(c => c[0]), '_id', '_data']]), ['Settings', ['Setting', 'Value']], ['Files', ['File', 'Type', 'Size KB', '_id', '_data']]]);
const ALL = Object.keys(HEAD);
export const WATCH = new Set([...TABS.map(T => T.key), 'cfg']); // a change here = sync soon
const NO_SYNC = new Set([...SECRET, 'enabled', 'setupDone', 'consent', 'autoSend', 'cfgVersion']); // per computer, never in the Sheet
const tsOf = v => typeof v === 'number' ? v : typeof v?.upd === 'string' ? Date.parse(v.upd) || 0 : typeof v?.at === 'number' ? v.at : Date.parse(v?.at) || 0;
const CHAT = /^[\w.-]{5,40}@(c\.us|lid|g\.us)$/;
const cell = c => String(c ?? '').trim();

// tabs, bold frozen header, hidden _id/_data, status lists; a new file loses its empty first sheet
const ensureTabs = async (id, fresh) => {
  const { sheets = [] } = await gjson(`${SHEETS}/${id}?fields=sheets.properties(sheetId,title)`);
  const have = new Map(sheets.map(s => [s.properties.title, s.properties.sheetId])), add = ALL.filter(t => !have.has(t));
  if (add.length) (await gjson(`${SHEETS}/${id}:batchUpdate`, { requests: add.map(title => ({ addSheet: { properties: { title } } })) })).replies.forEach(r => r.addSheet && have.set(r.addSheet.properties.title, r.addSheet.properties.sheetId));
  const req = ALL.flatMap(t => {
    const sid = have.get(t), hid = HEAD[t].indexOf('_id');
    return [
      { updateSheetProperties: { properties: { sheetId: sid, gridProperties: { frozenRowCount: 1 } }, fields: 'gridProperties.frozenRowCount' } },
      { repeatCell: { range: { sheetId: sid, startRowIndex: 0, endRowIndex: 1 }, cell: { userEnteredFormat: { textFormat: { bold: true }, backgroundColor: { red: .87, green: .92, blue: .98 } } }, fields: 'userEnteredFormat(textFormat,backgroundColor)' } },
      ...(hid >= 0 ? [{ updateDimensionProperties: { range: { sheetId: sid, dimension: 'COLUMNS', startIndex: hid, endIndex: hid + 2 }, properties: { hiddenByUser: true }, fields: 'hiddenByUser' } }] : [])
    ];
  });
  TABS.filter(T => T.status).forEach(T => {
    const c = HEAD[T.tab].indexOf('Status');
    req.push({ setDataValidation: { range: { sheetId: have.get(T.tab), startRowIndex: 1, startColumnIndex: c, endColumnIndex: c + 1 }, rule: { condition: { type: 'ONE_OF_LIST', values: T.status.map(userEnteredValue => ({ userEnteredValue })) }, showCustomUi: true, strict: false } } });
  });
  fresh && [...have].filter(([t]) => !HEAD[t]).forEach(([, sheetId]) => req.push({ deleteSheet: { sheetId } }));
  await gjson(`${SHEETS}/${id}:batchUpdate`, { requests: req });
};

// the Sheet for this Google account: the id the licence server kept, the one tagged before, one with the same name, or a new one
const openSheet = async (saved = '') => {
  const { gsync = {} } = await store.get('gsync');
  if (gsync.sheet) return gsync;
  const name = `WA AI Reply - ${(await getCfg()).bizName.trim() || 'My business'}`;
  let f = saved ? await gjson(`${DRIVE}/${saved}?fields=id,name,trashed`).catch(() => null) : null;
  f?.trashed && (f = null);
  f ||= await findFile('book') || await findByName(name);
  const fresh = !f;
  if (fresh) {
    f = await makeFile(name, 'application/vnd.google-apps.spreadsheet', 'book');
    await ensureTabs(f.id, true);
  } else gjson(`${DRIVE}/${f.id}?fields=id`, { appProperties: { waai: 'book' } }, 'PATCH').catch(() => {}); // found again next time
  const g = { ...gsync, sheet: f.id, name: f.name, url: `https://docs.google.com/spreadsheets/d/${f.id}/edit`, tabsV: fresh ? TABS_V : 0, err: '', kind: '' };
  await store.set({ gsync: g });
  return g;
};

// quick reply files <-> a Drive folder. map: file id -> {d: drive id, name, mime, kb}
const b64 = buf => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const syncFiles = async (g, map, qr) => {
  const ids = [...new Set(qr.flatMap(q => (q.files || []).map(f => f.id)))];
  if (!ids.length) return;
  const have = await store.get(ids.map(i => `qrf:${i}`));
  let n = 0;
  for (const id of ids) {
    if (n >= 20) break; // the rest next time
    const blob = have[`qrf:${id}`];
    if (!blob && map[id]) { // here: missing, Drive: there
      const r = await gfetch(`${DRIVE}/${map[id].d}?alt=media`).catch(() => null);
      r && await store.set({ [`qrf:${id}`]: { name: map[id].name, mime: map[id].mime, dataUrl: `data:${map[id].mime};base64,${b64(await r.arrayBuffer())}` } });
      n++;
    } else if (blob?.dataUrl && !map[id]) { // new here: up to Drive
      g.folder ||= (await findFile('files'))?.id || (await makeFile('WA AI Reply files', 'application/vnd.google-apps.folder', 'files')).id;
      const data = await (await fetch(blob.dataUrl)).blob(), meta = JSON.stringify({ name: blob.name, parents: [g.folder], appProperties: { waai: 'qrf', fid: id } });
      const body = new Blob([`--wa\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--wa\r\nContent-Type: ${blob.mime}\r\n\r\n`, data, '\r\n--wa--']);
      const f = await (await gfetch(`${UPLOAD}?uploadType=multipart&fields=id`, { method: 'POST', headers: { 'Content-Type': 'multipart/related; boundary=wa' }, body })).json();
      map[id] = { d: f.id, name: blob.name, mime: blob.mime, kb: Math.ceil(data.size / 1024) };
      n++;
    }
  }
};

// one tab: Sheet rows -> {k, v, edits}
const readTab = (T, values) => {
  const [head = [], ...rows] = values, at = Object.fromEntries(head.map((h, i) => [h, i]));
  if (at._id === undefined || at._data === undefined) return [];
  return rows.map(r => {
    const k = cell(r[at._id]);
    let v;
    try { v = JSON.parse(r[at._data]); } catch { return null; }
    if (!k || v == null || !(T.valid ? T.valid(k, v) : typeof v === 'object' && v.id === k)) return null; // only rows this extension wrote
    const edits = {};
    for (const [h, fn, ed] of T.cols) {
      if (!ed || at[h] === undefined || cell(r[at[h]]) === cell(fn(v, k))) continue;
      const x = ed.read(r[at[h]]);
      x !== undefined && (edits[ed.field] = x);
    }
    return { k, v, edits };
  }).filter(Boolean);
};
// newer copy wins, Sheet edits on top, deleted-here rows stay deleted, unseen rows come in
const mergeTab = (T, local, rows, known) => {
  const L = new Map(T.arr ? local.map(v => [v.id, v]) : Object.entries(local)), order = [...L.keys()];
  let added = 0, changed = 0;
  for (const r of rows) {
    const cur = L.get(r.k);
    if (cur === undefined && known.has(r.k)) continue;
    let v = cur === undefined || tsOf(r.v) > tsOf(cur) ? r.v : cur;
    if (Object.keys(r.edits).length && typeof v === 'object') v = { ...v, ...r.edits, ...(T.arr ? { upd: new Date().toISOString() } : { at: Date.now() }), ...(T.key === 'screens' && r.edits.status ? { manual: true } : {}) }; // a status set in the Sheet is mine
    if (v === cur) continue;
    L.set(r.k, v);
    cur === undefined ? (added++, order.push(r.k)) : changed++;
  }
  let out = order.map(k => [k, L.get(k)]);
  T.sort && out.sort((a, b) => Date.parse(b[1].at) - Date.parse(a[1].at));
  return { data: T.arr ? out.map(e => e[1]) : Object.fromEntries(out), added, changed, keys: out.map(e => e[0]) };
};
const rowsOf = (T, data) => (T.arr ? data.map(v => [v.id, v]) : Object.entries(data)).map(([k, v]) => {
  const j = JSON.stringify(v);
  return [...T.cols.map(([, fn]) => fn(v, k) ?? ''), k, j.length < 49000 ? j : ''];
});
// AI keys go to the Sheet ENCRYPTED (AES-GCM) with the Google account's unlock key from the licence server:
// the Sheet alone and the server alone can never read them
const ub = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const aes = (vault, use) => crypto.subtle.importKey('raw', ub(vault), 'AES-GCM', false, [use]);
const lockKeys = async (vault, obj) => { const iv = crypto.getRandomValues(new Uint8Array(12)); return `enc:v1:${b64(iv)}:${b64(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await aes(vault, 'encrypt'), new TextEncoder().encode(JSON.stringify(obj))))}`; };
const openKeys = async (vault, blob) => { const [, , iv, ct] = String(blob).split(':'); return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ub(iv) }, await aes(vault, 'decrypt'), ub(ct)))); };
const sha = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].slice(0, 12).map(b => b.toString(16).padStart(2, '0')).join('');

// one round: read the Sheet, merge here, write everything back (skipped when nothing changed)
let quietUntil = 0;
const round = async (locked, g) => {
  if (g.tabsV !== TABS_V) { await ensureTabs(g.sheet, false); g.tabsV = TABS_V; }
  const q = new URLSearchParams([...ALL.map(t => ['ranges', `'${t}'!A1:Z`]), ['valueRenderOption', 'UNFORMATTED_VALUE']]);
  const got = Object.fromEntries((await gjson(`${SHEETS}/${g.sheet}/values:batchGet?${q}`)).valueRanges.map((vr, i) => [ALL[i], vr.values || []]));
  // files first, so the Files tab below is complete
  const fileRows = got.Files.slice(1), map = { ...Object.fromEntries(fileRows.filter(r => r[3] && r[4]).map(r => [cell(r[3]), { d: cell(r[4]), name: cell(r[0]), mime: cell(r[1]) || 'application/octet-stream', kb: +r[2] || 0 }])), ...(g.files || {}) };
  await syncFiles(g, map, (await store.get('qr')).qr || []);
  g.files = map;
  const sheetCfg = Object.fromEntries(got.Settings.slice(1).filter(r => r[0]).map(r => { try { return [cell(r[0]), JSON.parse(r[1])]; } catch { return null; } }).filter(Boolean));
  const res = await locked(async () => {
    const keys = [...TABS.map(T => T.key), ...TABS.filter(T => T.count).map(T => T.count), 'gKnown'];
    const s = await store.get(keys), K = s.gKnown?.sheet === g.sheet ? s.gKnown.sets || {} : {};
    const out = {}, put = {}, sum = {}, sets = {};
    for (const T of TABS) {
      const m = mergeTab(T, s[T.key] || (T.arr ? [] : {}), readTab(T, got[T.tab]), new Set(K[T.key] || []));
      out[T.tab] = m.data; sets[T.key] = m.keys;
      if (m.added || m.changed) { put[T.key] = m.data; sum[T.tab] = m.added; }
      if (T.count) { const top = Math.max(+s[T.count] || 0, ...m.data.map(x => +x.no || 0)); top > (+s[T.count] || 0) && (put[T.count] = top); }
    }
    // settings come back once, on a copy that was never set up
    let cfg = await getCfg();
    quietUntil = Date.now() + 3000; // our own writes below don't ask for another round
    if (!g.cfgDone && !cfg.setupDone && Object.keys(sheetCfg).length) {
      const patch = Object.fromEntries(Object.entries(sheetCfg).filter(([k, v]) => k in DEFAULTS && !NO_SYNC.has(k) && typeof v === typeof DEFAULTS[k]));
      if (Object.keys(patch).length) { await setCfg({ ...patch, setupDone: true, enabled: false }); cfg = await getCfg(); sum.Settings = 1; }
    }
    g.cfgDone = true;
    // keys come back once, into empty fields only (a key cleared here on purpose is never put back)
    if (g.vault && !g.keysDone && typeof sheetCfg._keys === 'string') {
      try {
        const k = await openKeys(g.vault, sheetCfg._keys), patch = Object.fromEntries(SECRET.filter(x => typeof k[x] === 'string' && k[x] && !cfg[x]).map(x => [x, k[x].slice(0, 500)]));
        if (Object.keys(patch).length) { await setCfg(patch); cfg = await getCfg(); sum.Keys = Object.keys(patch).length; }
      } catch {}
    }
    g.vault && (g.keysDone = true);
    if (Object.keys(put).length) { quietUntil = Date.now() + 3000; await store.set(put); }
    out.Settings = Object.entries(cfg).filter(([k]) => k in DEFAULTS && !NO_SYNC.has(k)).map(([k, v]) => [k, JSON.stringify(v)]);
    const sec = Object.fromEntries(SECRET.filter(k => cfg[k]).map(k => [k, cfg[k]]));
    if (g.vault && Object.keys(sec).length) {   // same keys = same locked text, so an unchanged Sheet is not written again
      const h = await sha(JSON.stringify(sec) + g.vault);
      h !== g.keysHash && (g.keysBlob = await lockKeys(g.vault, sec), g.keysHash = h);
      out.Settings.push(['_keys', JSON.stringify(g.keysBlob)]);
    }
    return { out, sum, sets };
  });
  const vals = Object.fromEntries(ALL.map(t => [t, [HEAD[t], ...(t === 'Settings' ? res.out.Settings : t === 'Files' ? Object.entries(map).map(([id, f]) => [f.name, f.mime, f.kb, id, f.d]) : rowsOf(TABS.find(T => T.tab === t), res.out[t]))]]));
  const hash = await sha(JSON.stringify(vals));
  if (hash !== g.hash) {
    // about 3 MB per call, then clear the rows left under the new end
    let batch = [], size = 0;
    const send = async () => { batch.length && await gjson(`${SHEETS}/${g.sheet}/values:batchUpdate`, { valueInputOption: 'RAW', data: batch }); batch = []; size = 0; };
    for (const t of ALL) {
      const n = JSON.stringify(vals[t]).length;
      size + n > 3e6 && await send();
      batch.push({ range: `'${t}'!A1`, values: vals[t] }); size += n;
    }
    await send();
    await gjson(`${SHEETS}/${g.sheet}/values:batchClear`, { ranges: ALL.map(t => `'${t}'!A${vals[t].length + 1}:Z`) });
    g.hash = hash;
  }
  await store.set({ gKnown: { sheet: g.sheet, sets: res.sets } });
  return res.sum;
};

let running = null;
export const gSync = locked => running ??= (async () => {
  const { gAcct, gsync } = await store.get(['gAcct', 'gsync']);
  if (!gAcct?.email || !gsync?.sheet) return { ok: false, err: 'Sign in with Google first.' };
  let g = { ...gsync }, sum;
  try {
    try { sum = await round(locked, g); }
    catch (e) {
      if (e.kind === 'tabs') { g.tabsV = 0; sum = await round(locked, g); } // a tab was deleted in the Sheet
      else if (e.kind === 'gone') { await store.set({ gsync: { ...g, sheet: '' } }); g = { ...(await openSheet()) }; sum = await round(locked, g); } // the Sheet is gone: a new one, filled from here
      else throw e;
    }
    await store.set({ gsync: { ...g, last: Date.now(), err: '', kind: '' } });
    return { ok: true, sum };
  } catch (e) {
    await store.set({ gsync: { ...g, err: e.message, kind: e.kind || '' } });
    return { ok: false, err: e.message, kind: e.kind || '' };
  }
})().finally(() => { running = null; });

// Continue with Google: account + Sheet (found or made). gid = the id token, for the free trial
export const gLogin = async () => {
  const r = await signIn({ interactive: true, id: true });
  const { gAcct, gsync = {} } = await store.get(['gAcct', 'gsync']), same = gAcct?.email === r.acct.email;
  await store.set({ gAcct: { ...r.acct, at: Date.now() }, gsync: same ? { ...gsync, err: '', kind: '' } : {} });
  same || await store.remove('gKnown');
  const a = await licGoogleLink('glink', { gid: r.gid }), saved = a?.sheet || '';   // portal: this device is signed in with that Gmail
  const g = await openSheet(saved);
  let vault = a?.vault || '';
  if (g.sheet !== saved || !vault) vault = (await licGoogleLink('glink', { gid: r.gid, sheet: g.sheet }))?.vault || vault;   // next sign-in, any computer: the same Sheet
  /^[A-Za-z0-9+/]{43}=$/.test(vault) && await store.set({ gsync: { ...(await store.get('gsync')).gsync, vault } });   // unlock key for the AI keys in the Sheet
  return r;
};
export const gLogout = async () => {
  const { gTok } = await sess.get('gTok');
  gTok?.t && fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(gTok.t)}`, { method: 'POST' }).catch(() => {}); // Google forgets this access too
  await sess.remove('gTok');
  licGoogleLink('gunlink');
  await store.remove(['gAcct', 'gsync', 'gKnown']); // the data stays here and in the Sheet
  return { ok: true };
};
export const gState = async () => {
  const { gAcct, gsync = {} } = await store.get(['gAcct', 'gsync']);
  return { acct: gAcct ? { email: gAcct.email, name: gAcct.name } : null, sheet: gsync.sheet ? { url: gsync.url, name: gsync.name } : null,
    last: gsync.last || 0, err: gsync.err || '', kind: gsync.kind || '', busy: !!running };
};
// a change to synced data: one round within 5 minutes (not one per change)
export const gSoon = async changes => {
  if (Date.now() < quietUntil || !Object.keys(changes).some(k => WATCH.has(k))) return;
  const { gAcct } = await store.get('gAcct');
  gAcct && !(await chrome.alarms.get('gsync')) && chrome.alarms.create('gsync', { delayInMinutes: 5 });
};
