/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// page language, like the PHP template's switcher: the English text of the page goes to Google Translate as plain
// data (no remote code), each language is kept in storage so it is fetched once, new text is translated as it appears,
// right-to-left languages flip the layout. Customer data (chats, tables, names, my message boxes) is never sent
import { LANGS } from './langs.js';

const KEY = 'appLang', GT = 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=en&tl=';
const SKIP = '.notranslate, [translate="no"], script, style, code, pre, textarea, input, select, .bubble, .bk-bubble, .wa-phone, .bk-chat, .tabulator-cell, .tabulator-responsive-collapse, .tb-uid, .kv b, .scr-row .kv b, .msg-to, .lang-menu, .tl, .pwd-mask, .qr-text, .qr-ex, .bk-chip, #pageCrumb .crumb-now';
const ATTRS = ['placeholder', 'title', 'aria-label', 'data-tip', 'data-tooltip', 'data-empty'];
const WORDS = /\p{L}{2}/u;   // anything with real words; numbers, codes and symbols stay as they are
const orig = new WeakMap();  // node → { text, attrs } as written in English
let lang = 'en', dict = {}, busy = null, obs = null;
const ls = { get: () => { try { return localStorage.getItem(KEY) || 'en'; } catch { return 'en'; } }, set: v => { try { localStorage.setItem(KEY, v); } catch {} } };
export const langOf = code => LANGS.find(l => l[0] === code) || LANGS[0];

// what the page says in English right now (text nodes + a few attributes), skipping customer data
const targets = (root = document.body) => {
  const out = [];
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, {
    acceptNode: n => n.nodeType === 1 ? (n.matches(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP) : n.parentElement?.closest(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
  });
  for (let n = w.nextNode(); n; n = w.nextNode()) out.push(n);
  root.nodeType === 1 && [root, ...root.querySelectorAll(ATTRS.map(a => `[${a}]`).join(','))].forEach(el => el.hasAttribute && ATTRS.some(a => el.hasAttribute(a)) && !el.matches('.notranslate, [translate="no"]') && !el.parentElement?.closest(SKIP) && out.push(el)); // a box's placeholder is page text, its value is not
  return out;
};
const remember = n => {
  let o = orig.get(n);
  if (n.nodeType === 3) {
    const t = n.nodeValue;
    if (!o || (t !== o.tr && t !== o.text)) orig.set(n, o = { text: t, tr: null }); // the page wrote new English text
    return o;
  }
  o = o || { attrs: {} };
  ATTRS.forEach(a => { const v = n.getAttribute(a); v != null && v !== o.attrs[a]?.tr && (o.attrs[a] = { text: v, tr: null }); });
  orig.set(n, o);
  return o;
};
const need = s => s && WORDS.test(s) && !(s.trim() in dict);

// Google Translate, many lines per call; a reply that does not line up is tried again one line at a time
const fetchLines = async (lines, tl) => {
  const r = await fetch(GT + encodeURIComponent(tl) + '&q=' + encodeURIComponent(lines.join('\n')));
  if (!r.ok) throw new Error(`Google Translate: HTTP ${r.status}`);
  const out = ((await r.json())[0] || []).map(x => x[0]).join('').split('\n');
  return out.length >= lines.length ? out.slice(0, lines.length) : null;
};
const translate = async (list, tl) => {
  const todo = [...new Set(list.map(s => s.trim()).filter(s => need(s)))].map(s => s.replace(/\s*\n\s*/g, ' '));
  for (let i = 0; i < todo.length;) {
    const batch = [];
    for (let len = 0; i < todo.length && len + todo[i].length < 1800; len += todo[i].length + 1) batch.push(todo[i++]);
    batch.length || batch.push(todo[i++]);
    let got = await fetchLines(batch, tl).catch(() => null);
    if (!got) got = await Promise.all(batch.map(s => fetchLines([s], tl).then(x => x?.[0] ?? s).catch(() => s)));
    batch.forEach((s, k) => dict[s] = String(got[k] ?? s).trim());
  }
  chrome.storage.local.set({ [`i18n_${tl}`]: dict });
};
const keep = (s, t) => { const m = s.match(/^(\s*)[\s\S]*?(\s*)$/); return m[1] + t + m[2]; }; // same spaces around it

// put the language on these nodes (English = put the original back)
const paint = async (nodes, english) => {
  const recs = nodes.map(n => [n, remember(n)]);
  if (!english) await translate(recs.flatMap(([n, o]) => n.nodeType === 3 ? [o.text] : Object.values(o.attrs).map(a => a.text)), lang);
  obs?.disconnect();
  for (const [n, o] of recs) {
    if (n.nodeType === 3) { const t = english ? o.text : keep(o.text, dict[o.text.trim()] ?? o.text.trim()); o.tr = t; n.nodeValue !== t && (n.nodeValue = t); }
    else Object.entries(o.attrs).forEach(([a, v]) => { const t = english ? v.text : dict[v.text.trim()] ?? v.text; v.tr = t; n.getAttribute(a) !== t && n.setAttribute(a, t); });
  }
  watch();
};

// text the page adds later (lists, dialogs, toasts) follows the language
let pend = new Set(), tm = 0;
const watch = () => {
  obs = obs || new MutationObserver(ms => {
    if (lang === 'en') return;
    ms.forEach(m => m.type === 'childList' ? m.addedNodes.forEach(n => pend.add(n)) : pend.add(m.target));
    clearTimeout(tm);
    tm = setTimeout(() => { const roots = [...pend].filter(n => n.isConnected); pend = new Set(); busy = (busy || Promise.resolve()).then(() => paint(roots.flatMap(r => r.nodeType === 3 ? (r.parentElement?.closest(SKIP) ? [] : [r]) : targets(r)), false)).catch(() => {}); }, 120);
  });
  obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
};

export const applyLanguage = async code => {
  const [c, , , rtl] = langOf(code);
  lang = c;
  ls.set(c);
  document.documentElement.lang = c;
  document.documentElement.dir = rtl ? 'rtl' : 'ltr';
  dict = c === 'en' ? {} : (await chrome.storage.local.get(`i18n_${c}`))[`i18n_${c}`] || {};
  document.body.classList.add('lang-busy');
  try { await (busy = paint(targets(), c === 'en')); }
  finally { document.body.classList.remove('lang-busy'); }
  dispatchEvent(new CustomEvent('waai:lang', { detail: c }));
};

// header switcher: search + every language, native name first (same as the template)
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const label = c => c.split('-')[0].slice(0, 3).toUpperCase();
const renderMenu = q => {
  const k = String(q || '').trim().toLowerCase(), cur = ls.get();
  const hit = !k ? LANGS : LANGS.filter(([c, en, nat]) => `${c} ${en} ${nat}`.toLowerCase().includes(k));
  document.querySelector('#langMenu .lang-list').innerHTML = hit.length ? hit.map(([c, en, nat, rtl]) => `<button type="button" class="lang-item${c === cur ? ' active' : ''}" data-code="${esc(c)}"${rtl ? ' dir="rtl"' : ''}>
    <span class="lang-code">${esc(label(c))}</span><span class="lang-names"><b>${esc(nat || en)}</b>${nat && nat !== en ? `<small>${esc(en)}</small>` : ''}</span>${c === cur ? '<i class="fa-solid fa-check lang-check"></i>' : ''}</button>`).join('')
    : '<div class="lang-none">No language matches</div>';
};
export const mountSwitcher = () => {
  const menu = document.getElementById('langMenu');
  if (!menu) return;
  menu.innerHTML = `<div class="lang-search-wrap"><i class="fa-solid fa-magnifying-glass"></i><input type="search" class="lang-search notranslate" placeholder="Search ${LANGS.length} languages" autocomplete="off" aria-label="Search languages"></div><div class="lang-list"></div>`;
  const btn = document.getElementById('langBtn'), set = open => { menu.classList.toggle('open', open); btn.setAttribute('aria-expanded', open); };
  btn.onclick = e => { e.stopPropagation(); const open = !menu.classList.contains('open'); renderMenu(''); menu.querySelector('.lang-search').value = ''; set(open); open && setTimeout(() => menu.querySelector('.lang-search').focus(), 30); };
  menu.querySelector('.lang-search').oninput = e => renderMenu(e.target.value);
  menu.addEventListener('click', async e => {
    e.stopPropagation();
    const b = e.target.closest('[data-code]');
    if (!b) return;
    set(false);
    document.getElementById('curLangLabel').textContent = label(b.dataset.code);
    await applyLanguage(b.dataset.code).catch(() => {});
  });
  document.addEventListener('click', () => set(false));
  document.addEventListener('keydown', e => e.key === 'Escape' && set(false));
  document.getElementById('curLangLabel').textContent = label(ls.get());
};

// start in the saved language (English needs nothing)
export const startLanguage = () => ls.get() !== 'en' ? applyLanguage(ls.get()).catch(() => {}) : Promise.resolve();
