/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// License page, dashboard banner and sidebar pill
import { $, esc, bg, toast, busy, confirmBox } from './ui.js';

const day = ms => new Date(ms).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const when = ms => ms ? new Date(ms).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'never';
const safeUrl = u => /^https:\/\//i.test(u || '') ? u : '';
const SOON = 7;

// state -> [icon, title, line, tone]
const head = s => ({
  dev: ['fa-code', 'Developer build', 'This copy runs without a key.', ''],
  none: ['fa-key', 'Not activated', 'Paste the key you got from the seller and press Activate.', 'warn'],
  active: ['fa-circle-check', 'Active', s.exp ? `Until ${day(s.exp)} · ${s.days < 1 ? 'ends today' : `${s.days} days left`}` : 'Lifetime key, it never ends.', s.days != null && s.days < SOON ? 'warn' : 'ok'],
  offline: ['fa-wifi', 'Needs a check', `The licence server could not be reached since ${when(s.at)}. Nothing is sent until it can check. Connect to the internet and press Check now.`, 'bad'],
  expired: ['fa-calendar-xmark', 'Expired', `Ended on ${s.exp ? day(s.exp) : 'its end date'}. Renew the key to keep replying.`, 'bad'],
  suspended: ['fa-pause', 'Paused by the seller', s.msg, 'bad'],
  revoked: ['fa-ban', 'Cancelled by the seller', s.msg, 'bad'],
  other_device: ['fa-laptop', 'Used on another device', s.msg, 'bad'],
  reset: ['fa-rotate', 'Activate again', s.msg, 'warn'],
  invalid: ['fa-ban', 'Key removed', 'The seller removed this key. Get a new key from the seller.', 'bad'],
  cloned: ['fa-clone', 'Copied to another computer', s.msg, 'bad'],
}[s.state] || ['fa-triangle-exclamation', 'Could not check the key', s.msg || s.err || '', 'bad']);

let last = null;
const paint = s => {
  last = s;
  if (!$('licHero')) return;
  const [ic, title, line, tone] = head(s), soon = s.ok && s.days != null && s.days < SOON, renew = safeUrl(s.renew);
  $('licHero').className = `lic-hero ${tone}`;
  $('licHero').innerHTML = `<span class="lic-ic"><i class="fa-solid ${ic}"></i></span><div><b>${esc(title)}</b><span>${esc(line)}</span></div>`;
  const askKey = ['none', 'reset'].includes(s.state);
  $('licForm').hidden = !askKey;
  askKey && s.key && !$('licKey').value && ($('licKey').value = s.key);
  $('licFail').hidden = !s.fail;
  $('licFail').innerHTML = s.fail ? `<i class="fa-solid fa-circle-exclamation"></i> ${esc(s.fail)}` : '';
  const showInfo = !!s.key && s.state !== 'none' && !s.dev;
  $('licInfo').hidden = !showInfo;   // buttons only, the key details are not shown
  if (showInfo) {
    $('licCheck').hidden = false;
    $('licRelease').hidden = !['active', 'expired', 'offline'].includes(s.state);
    $('licForget').hidden = !['other_device', 'revoked', 'reset', 'invalid'].includes(s.state);
    $('licRenew').hidden = !renew || !(soon || ['expired', 'suspended', 'revoked'].includes(s.state));
    renew && ($('licRenew').href = renew);
  }
  paintBadges(s);
};

// key not active: every page but License is locked, and the lock says why
const lock = s => {
  const on = !s.ok && !s.dev;
  document.body.classList.toggle('lic-locked', on);
  if (!on) return;
  $('licLockWhy').textContent = s.state === 'none' ? 'Activate your licence key to use the extension.' : `${head(s)[1]}. ${head(s)[2] || ''}`.trim();
  const cur = document.querySelector('.view:not([hidden])')?.dataset.view;
  $('licLock').hidden = cur === 'license';
};
addEventListener('waai:view', e => document.body.classList.contains('lic-locked') && ($('licLock').hidden = e.detail === 'license'));
document.addEventListener('click', e => { const b = e.target.closest('[data-nav-to]'); b && document.querySelector(`[data-nav="${b.dataset.navTo}"]`)?.click(); });

// sidebar pill + dashboard banner, also used before the License page was opened
export const paintBadges = s => {
  if (!s?.state) return;
  lock(s);
  const soon = s.ok && s.days != null && s.days < SOON, bad = !s.ok && !s.dev;
  $('pillLic') && ($('pillLic').hidden = !bad && !soon);
  const b = $('licBanner');
  if (!b) return;
  b.hidden = !bad && !soon;
  if (b.hidden) return;
  const [ic, title, line] = head(s);
  b.className = `lic-banner ${bad ? 'bad' : 'warn'}`;
  b.innerHTML = `<i class="fa-solid ${ic}"></i><div><b>${esc(bad ? `Licence: ${title}` : `Licence ends in ${s.days < 1 ? 'less than a day' : `${s.days} days`}`)}</b><span>${esc(bad ? `${line || ''} The bot stays off until the key is active.` : 'Renew it so replies do not stop.')}</span></div>
    <button class="btn sm" data-go="license"><i class="fa-solid fa-key"></i> ${bad ? 'Open License' : 'Renew'}</button>`;
};

const load = async (type, extra) => {
  const s = await bg({ type, ...extra });
  s.state ? paint(s) : toast(s.err || 'Could not check the key', true);
  return s;
};
export const licLoad = () => load('licGet');

$('licActivate').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  const key = $('licKey').value.trim();
  if (!key) { $('licKey').focus(); return toast('Paste your key first', true); }
  busy(btn, true);
  try {
    const s = await load('licActivate', { key });
    if (s.ok) {
      toast('Activated');
      $('licKey').value = '';
      dispatchEvent(new CustomEvent('waai:licensed')); // first run: setup comes next
    }
  } finally { busy(btn, false); }
};
$('licKey').addEventListener('keydown', e => e.key === 'Enter' && $('licActivate').click());
$('licCheck').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try { const s = await load('licCheck'); s.fail ? toast(s.fail, true) : toast(s.ok ? 'Checked: the key is active' : 'Checked'); }
  finally { busy(btn, false); }
};
$('licRelease').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  if (!(await confirmBox('Remove the key from this device?', `The bot turns off here, and you can activate the key on another device. ${last?.moves ?? 0} moves left.`, { ok: 'Remove', danger: true }))) return;
  busy(btn, true);
  try { const s = await load('licRelease'); s.done ? toast('Removed. Activate the key on your other device.') : s.fail && toast(s.fail, true); }
  finally { busy(btn, false); }
};
$('licForget').onclick = async e => {
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  try { await load('licForget'); $('licKey').value = ''; $('licKey').focus(); }
  finally { busy(btn, false); }
};

addEventListener('waai:view', e => (e.detail === 'license' || e.detail === 'dashboard') && licLoad());
chrome.storage.onChanged.addListener(c => c.lic && last && bg({ type: 'licGet' }).then(s => s.state && paint(s)));
licLoad();
