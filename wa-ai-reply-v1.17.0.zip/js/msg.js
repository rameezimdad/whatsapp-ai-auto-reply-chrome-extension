/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// send a message from an order / booking / screening row: pick a ready text (filled with the row), edit, Send.
// my click is the confirmation; the service worker still checks licence, chat and the 24 h window
import { $, esc, bg, toast, busy, waFormat } from './ui.js';

let cur = null, tpls = [];
const dlg = $('msgDlg'), CHAT = /@(c\.us|lid)$/;
const pane = p => {
  dlg.querySelectorAll('[data-pane]').forEach(b => b.classList.toggle('active', b.dataset.pane === p));
  dlg.querySelectorAll('[data-pane-box]').forEach(b => b.classList.toggle('show', b.dataset.paneBox === p));
};
const paint = () => {
  const t = $('msgText').value;
  $('msgPrev').innerHTML = waFormat(t) || '<span class="sub">Write a message</span>';
  $('msgLen').textContent = `${t.length} / 4000`;
  dlg.querySelectorAll('[data-tpl]').forEach(b => b.classList.toggle('on', tpls[+b.dataset.tpl]?.[2] === t));
};

// tpls: [[label, icon, text], …] already filled with the row's details; last = blank
export const openMsg = ({ kind, id, chatId, since, who, phone, list }) => {
  cur = { kind, id, chatId, since };
  tpls = [...list, ['Write my own', 'fa-pen', '']];
  const chat = CHAT.test(chatId || ''), old = Date.now() - (Date.parse(since) || 0) > 864e5;
  $('msgTo').innerHTML = `<i class="fa-brands fa-whatsapp"></i><span><b>${esc(who || 'Customer')}</b><small>${esc(phone || (chat ? chatId.split('@')[0] : 'No WhatsApp number'))}</small></span>`;
  $('msgTpls').innerHTML = tpls.map(([l, ic], i) => `<button type="button" class="bk-pre" data-tpl="${i}"><i class="fa-solid ${ic}"></i> ${esc(l)}</button>`).join('');
  $('msgText').value = tpls[0][2];
  $('msgWarn').hidden = chat && !old;
  $('msgWarn').innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${!chat ? 'No WhatsApp chat on this row. Add the number with Edit, or message them yourself.' : 'They may not have written in the last 24 hours. If so, the message is not sent: write to them yourself from WhatsApp.'}`;
  $('msgSend').disabled = !chat;
  $('msgOpen').disabled = !chat;
  pane('form');
  paint();
  dlg.showModal();
  setTimeout(() => $('msgText').focus(), 50);
};

$('msgTpls').addEventListener('click', e => { const b = e.target.closest('[data-tpl]'); if (!b) return; $('msgText').value = tpls[+b.dataset.tpl][2]; paint(); $('msgText').focus(); });
$('msgText').addEventListener('input', paint);
dlg.addEventListener('click', e => { e.target.closest('[data-close]') && dlg.close(); const t = e.target.closest('[data-pane]'); t && pane(t.dataset.pane); });
$('msgOpen').onclick = () => cur && bg({ type: 'openChat', chatId: cur.chatId });
$('msgForm').onsubmit = async e => {
  e.preventDefault();
  if (!cur) return;
  const text = $('msgText').value.trim();
  if (!text) { $('msgText').classList.add('bad'); return toast('Write the message first', true); }
  busy($('msgSend'), true);
  try {
    const r = await bg({ type: 'sendMsg', ...cur, text });
    if (!r.ok) return toast(r.err, true);
    dlg.close();
    toast('Message sent');
  } finally { busy($('msgSend'), false); }
};
