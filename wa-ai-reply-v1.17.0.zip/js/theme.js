/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// dark mode before paint: first thing in <body>, own choice wins, else the system
try { const t = localStorage.getItem('theme'); (t === 'dark' || (!t && matchMedia('(prefers-color-scheme: dark)').matches)) && document.body.classList.add('dark-mode'); } catch {}
