/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
import { DEFAULTS, NEEDS, BIZ, PRESETS, buildPrompt, presetOf, getCfg, setCfg, ready, today, money, month } from './cfg.js';
import { $, esc, bg, toast, busy, ago, optoutHtml, connState, openWa, confirmBox, ENGINE, ST } from './ui.js';
import './qr.js';
import { syncModels } from './models.js';
import './orders.js';
import './kb.js';
import './customers.js';
import { openWizard, openTour, wizLater } from './wizard.js';
import { licState } from './license.js';
import './licui.js';
let licDay = 0, licUsed = 0; // the seller's contacts-a-day limit (0 = none), contacts the server counted today
const licSync = () => licState().then(s => { licDay = s.day || 0; licUsed = s.cday === today() ? s.used || 0 : 0; renderDash(); });
import { STORE_BUILD } from './build.js';
import './health.js';
import './budget.js';

// business type tiles are form fields, draw them before the field list is read
$('bizTypes').innerHTML = Object.entries(BIZ).map(([k, b]) => `<label class="tile"><input type="radio" name="bizType" data-k="bizType" value="${k}">
  <span class="ic"><i class="fa-solid ${b.ic}"></i></span><b>${b.label}</b><i class="chk fa-solid fa-circle-check"></i></label>`).join('');
const fields = [...document.querySelectorAll('[data-k]')];
const BIZ_FIELDS = new Set(['bizType', 'bizName', 'bizAbout', 'bizProducts', 'bizHours', 'bizAddress', 'bizDelivery', 'bizPayment', 'bizReturns', 'bizOrder', 'bizTone', 'bizExtra']);
const engineOf = () => document.querySelector('[name=engine]:checked')?.value || DEFAULTS.engine;
const NUMS = { delayMin: [1, 120], delayMax: [1, 300], history: [1, 50], hourCap: [1, 200], humanPause: [0, 1440], dayCap: [1, 5000], minuteCap: [1, 30], maxAge: [0, 1440], errStop: [0, 50], budget: [1, 100000], priceIn: [0, 1000], priceOut: [0, 1000], fxRate: [0, 100000], memoryDepth: [50, 1000] };
// view → [sidebar item, title, icon]; Orders has tabs
const VIEWS = {
  dashboard: ['dashboard', 'Dashboard', 'fa-gauge-high'],
  orders: ['orders', 'Order list', 'fa-bag-shopping'], ordset: ['orders', 'Setup', 'fa-gear'], ordsheet: ['orders', 'Google Sheets', 'fa-table'],
  qr: ['qr', 'Quick replies', 'fa-bolt'], customers: ['customers', 'Customers', 'fa-user-group'], engine: ['engine', 'AI engine', 'fa-microchip'],
  business: ['business', 'Business info', 'fa-store'], knowledge: ['knowledge', 'Knowledge', 'fa-book-open'],
  media: ['media', 'Voice & photos', 'fa-microphone'], mcp: ['mcp', 'MCP tools', 'fa-plug'], rules: ['rules', 'Reply rules', 'fa-sliders'],
  safety: ['safety', 'Safety', 'fa-shield-halved'], budget: ['budget', 'AI budget', 'fa-wallet'], contacts: ['contacts', 'Contacts', 'fa-address-book'],
  guide: ['guide', 'Guide', 'fa-book'], test: ['test', 'Test the AI', 'fa-vial'], health: ['health', 'Health', 'fa-heart-pulse'],
  license: ['license', 'License', 'fa-key'], about: ['about', 'About', 'fa-circle-info']
};
const GROUPS = { orders: 'Orders' };
const lastSub = { orders: 'orders' };
const modelOf = cfg => ({ claude: cfg.claudeModel, openai: cfg.openaiModel, gemini: cfg.geminiModel, grok: cfg.grokModel }[cfg.engine] || '');
const isDemo = q => /Demo (Store|Bank)/.test(q.text);
const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };
const app = $('app');
let saved = {}; // last saved cfg
let logFilter = '', cur = 'dashboard';
let info = {}; // latest dashboard numbers, feeds the header

// page header tier 2: primary labelled, the rest icon-only with a tooltip
const ACTS = {
  wa: ['fa-brands fa-whatsapp', 'Open WhatsApp', () => openWa()],
  test: ['fa-solid fa-vial', 'Test the AI', () => go('test')],
  csv: ['fa-solid fa-file-csv', 'Export CSV', () => $('ordCsv').click()],
  addqr: ['fa-solid fa-plus', 'Add quick reply', () => $('qrAdd').click()],
  addkb: ['fa-solid fa-plus', 'Add fact', () => $('kbAdd').click()],
  addcust: ['fa-solid fa-plus', 'Add customer', () => $('custAdd').click()]
};
const PAGE_ACTS = { dashboard: ['wa', 'test'], orders: ['csv'], qr: ['addqr'], knowledge: ['addkb'], customers: ['addcust'], test: ['wa'] };
const head = () => {
  const { cfg } = info;
  if (!cfg) return;
  const on = cfg.enabled, noReview = !STORE_BUILD && cfg.autoSend;
  $('pageStatus').innerHTML = {
    dashboard: `<span class="pill dot-l ${on ? (noReview ? 'c-new' : 'c-sent') : 'c-skip'}">${!on ? 'Bot is off' : noReview ? 'Bot sends replies itself' : 'Bot is replying, you press Send'}</span>`,
    orders: info.fresh ? `<span class="pill dot-l c-new">${info.fresh} new to check</span>` : '',
    qr: `<span class="pill dot-l c-skip">${info.qrOn || 0} on</span>`,
    engine: `<span class="pill dot-l ${ready(cfg) ? 'c-sent' : 'c-error'}">${ready(cfg) ? 'Ready' : 'Needs a key'}</span>`,
    budget: info.budgetPct === null ? '' : `<span class="pill dot-l ${info.over ? 'c-error' : info.budgetPct >= 80 ? 'c-new' : 'c-sent'}">${info.over ? 'Budget used up' : `${info.budgetPct}% used`}</span>`
  }[cur] || '';
  const acts = PAGE_ACTS[cur] || [];
  $('pageActs').innerHTML = acts.map((k, i) => i === 0 && cur !== 'orders' && cur !== 'test'
    ? `<button class="btn" data-act="${k}"><i class="${ACTS[k][0]}"></i> ${ACTS[k][1]}</button>`
    : `<button class="btn ghost icon" data-act="${k}" title="${ACTS[k][1]}" aria-label="${ACTS[k][1]}"><i class="${ACTS[k][0]}"></i></button>`).join('');
  $('tier2').hidden = !acts.length;
  // Orders tabs with counts
  const g = VIEWS[cur][0];
  $('pageTabs').hidden = !GROUPS[g];
  $('pageTabs').innerHTML = GROUPS[g] ? Object.entries(VIEWS).filter(([, x]) => x[0] === g).map(([k, x]) => {
    const n = k === 'orders' ? info.orders : k === 'ordsheet' ? (cfg.orderHook ? '<i class="fa-solid fa-check"></i>' : '') : '';
    return `<button class="rs-tab${k === cur ? ' active' : ''}" data-go="${k}"${k === cur ? ' aria-current="page"' : ''}><i class="fa-solid ${x[2]}"></i> ${esc(x[1])}${n !== '' && n !== undefined ? `<span class="rs-tab-n">${n}</span>` : ''}</button>`;
  }).join('') : '';
};
$('pageActs').addEventListener('click', e => { const b = e.target.closest('[data-act]'); b && ACTS[b.dataset.act][2](); });

// routing
const go = v => {
  v = VIEWS[v] ? v : 'dashboard';
  cur = v;
  const [g, t, ic] = VIEWS[v];
  GROUPS[g] && (lastSub[g] = v);
  document.querySelectorAll('.view').forEach(s => s.hidden = s.dataset.view !== v);
  document.querySelectorAll('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === g));
  $('pageIcon').className = `fa-solid ${GROUPS[g] ? VIEWS[g][2] : ic}`;
  $('pageTitle').textContent = GROUPS[g] ? GROUPS[g] : t;
  const trail = ['Home', GROUPS[g], t].filter(Boolean);
  $('pageCrumb').innerHTML = `<i class="fa-solid fa-house"></i> ${trail.map(esc).join(' <span>/</span> ')}`;
  document.title = `${t} · WA AI Reply`;
  app.classList.remove('open');
  history.replaceState(null, '', '#' + v);
  window.scrollTo(0, 0);
  head();
  dispatchEvent(new CustomEvent('waai:view', { detail: v })); // tables size themselves when shown
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-go], [data-nav]');
  if (!b) return;
  const n = b.dataset.nav;
  go(n ? (GROUPS[n] ? lastSub[n] : n) : b.dataset.go);
});

// sidebar: rail on desktop, drawer on narrow screens
const narrow = matchMedia('(max-width: 860px)');
ls.get('waai_rail') === '1' && app.classList.add('rail');
$('menuBtn').onclick = () => narrow.matches ? app.classList.toggle('open') : ls.set('waai_rail', app.classList.toggle('rail') ? '1' : '0');
$('scrim').onclick = () => app.classList.remove('open');
document.addEventListener('keydown', e => e.key === 'Escape' && app.classList.remove('open'));

// settings search: every setting row and section, by label, hint and tip
const SKIP_VIEWS = new Set(['dashboard', 'orders', 'guide', 'test', 'about', 'customers']);
const INDEX = [...document.querySelectorAll('.view')].filter(v => !SKIP_VIEWS.has(v.dataset.view)).flatMap(v =>
  [...v.querySelectorAll('.set-row, .set-head')].map(el => {
    const b = el.querySelector('.set-label b, h2');
    return b && { el, view: v.dataset.view, label: b.textContent.trim(), hay: `${b.textContent} ${el.querySelector('.set-label span, .set-head p')?.textContent || ''} ${[...el.querySelectorAll('.tip')].map(t => t.dataset.tip).join(' ')}`.toLowerCase() };
  }).filter(Boolean));
let hits = [], hiIx = 0;
const shown = x => !x.el.closest('[data-engine][hidden], [data-bizmode][hidden]'); // other engine / other mode
const paintHits = () => {
  $('setResults').hidden = !$('setSearch').value.trim();
  $('setResults').innerHTML = hits.length ? hits.map((x, i) => `<button type="button" role="option" class="${i === hiIx ? 'hi' : ''}" data-hit="${i}"><b>${esc(x.label)}</b><small>${esc(VIEWS[x.view][1])}</small></button>`).join('')
    : '<p>No setting matches</p>';
};
const openHit = x => {
  if (!x) return;
  x.el.closest('.set-group.adv') && showAdv(true);
  go(x.view);
  $('setSearch').value = '';
  $('setResults').hidden = true;
  requestAnimationFrame(() => { x.el.scrollIntoView({ behavior: 'smooth', block: 'center' }); x.el.classList.remove('flash'); void x.el.offsetWidth; x.el.classList.add('flash'); });
};
$('setSearch').addEventListener('input', e => {
  const words = e.target.value.toLowerCase().split(/\s+/).filter(Boolean);
  hits = words.length ? INDEX.filter(x => shown(x) && words.every(w => x.hay.includes(w))).slice(0, 8) : [];
  hiIx = 0;
  paintHits();
});
$('setSearch').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); hiIx = (hiIx + (e.key === 'ArrowDown' ? 1 : -1) + hits.length) % (hits.length || 1); paintHits(); }
  else if (e.key === 'Enter') openHit(hits[hiIx]);
  else if (e.key === 'Escape') { e.target.value = ''; $('setResults').hidden = true; }
});
$('setResults').addEventListener('mousedown', e => { const b = e.target.closest('[data-hit]'); b && (e.preventDefault(), openHit(hits[+b.dataset.hit])); });
$('setSearch').addEventListener('blur', () => setTimeout(() => $('setResults').hidden = true, 150));

// collapsible cards
document.addEventListener('click', e => {
  const b = e.target.closest('[data-collapse]');
  if (!b) return;
  const c = b.closest('.lte-card').classList.toggle('collapsed');
  b.querySelector('i').className = `fa-solid ${c ? 'fa-plus' : 'fa-minus'}`;
  b.setAttribute('aria-label', c ? 'Expand' : 'Collapse');
});

// corner shape, saved with the settings
const applyShape = s => { document.documentElement.dataset.shape = s; ls.set('waai_shape', s); };

// form <-> cfg
const showEngine = () => {
  const e = engineOf();
  document.querySelectorAll('[data-engine]').forEach(el => el.hidden = !el.dataset.engine.split(' ').includes(e));
  $('mcpWarn').hidden = e !== 'gemini';
};
// which key will hear voice notes
const voiceNote = () => {
  const via = document.querySelector('[name=voiceVia]:checked')?.value || 'auto', g = !!$('geminiKey').value.trim(), o = !!$('openaiKey').value.trim();
  const use = via !== 'openai' && g ? 'Gemini' : via !== 'gemini' && o ? 'OpenAI' : '';
  $('voiceNote').innerHTML = use ? `<i class="fa-solid fa-circle-check"></i> Using your ${use} key`
    : `<i class="fa-solid fa-circle-exclamation"></i> No ${via === 'auto' ? 'Gemini or OpenAI' : via === 'gemini' ? 'Gemini' : 'OpenAI'} key yet. Add one on AI engine (pick its tile, paste the key, pick your main AI again, Save).`;
  $('voiceNote').className = use ? 'ok-note' : 'warn-note';
};
const keyBadges = () => { voiceNote(); document.querySelectorAll('[data-keyfor]').forEach(el => {
  const has = !!$(NEEDS[el.dataset.keyfor]).value.trim(), hook = el.dataset.keyfor === 'webhook';
  el.className = has ? 'ok' : '';
  el.innerHTML = has ? `<i class="fa-solid fa-circle-check"></i> ${hook ? 'URL added' : 'Key added'}` : (hook ? 'No URL yet' : 'No key yet');
}); };

const fill = cfg => {
  // old saved text opens in "write it yourself" so nothing is overwritten
  cfg = { ...cfg, bizMode: cfg.bizMode || (cfg.prompt.trim() === DEFAULTS.prompt.trim() ? 'form' : 'text') };
  saved = cfg;
  fields.forEach(el => el.type === 'checkbox' ? (el.checked = !!cfg[el.dataset.k]) : el.type === 'radio' ? (el.checked = String(cfg[el.dataset.k]) === el.value) : (el.value = cfg[el.dataset.k] ?? ''));
  (document.querySelector(`[name=engine][value="${cfg.engine}"]`) || document.querySelector('[name=engine]')).checked = true;
  (document.querySelector(`[name=voiceVia][value="${cfg.voiceVia}"]`) || document.querySelector('[name=voiceVia]')).checked = true;
  (document.querySelector(`[name=shape][value="${cfg.shape}"]`) || document.querySelector('[name=shape]')).checked = true;
  applyShape(cfg.shape || 'rounded');
  document.querySelectorAll('.field.bad').forEach(f => f.classList.remove('bad'));
  showEngine();
  keyBadges();
  syncModels();
  showBiz();
  paintPreset();
  dirty();
};

const values = () => {
  const c = { engine: engineOf(), voiceVia: document.querySelector('[name=voiceVia]:checked')?.value || 'auto', shape: document.querySelector('[name=shape]:checked')?.value || 'rounded' };
  fields.forEach(el => {
    const k = el.dataset.k;
    if (el.type === 'radio') return void ((el.checked || !(k in c)) && (c[k] = el.checked ? el.value : saved[k] ?? ''));
    c[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value.trim();
  });
  return c;
};

// business info: easy form writes the AI text
const bizMode = () => document.querySelector('[name=bizMode]:checked')?.value || 'form';
const showBiz = () => {
  const mode = bizMode(), t = BIZ[document.querySelector('[name=bizType]:checked')?.value] || BIZ.other;
  document.querySelectorAll('[data-bizmode]').forEach(el => el.hidden = el.dataset.bizmode !== mode);
  $('bizProductsLabel').textContent = t.products;
  $('bizProducts').placeholder = t.ph;
  $('bizPreview').textContent = $('prompt').value;
};
const rebuild = () => { $('prompt').value = buildPrompt(values()); showBiz(); };

// safety presets
const paintPreset = () => {
  const cur = presetOf(values());
  $('presetTiles').innerHTML = Object.entries(PRESETS).map(([k, p]) => `<button type="button" class="tile${k === cur ? ' on' : ''}" data-preset="${k}" aria-pressed="${k === cur}">
    <span class="ic"><i class="fa-solid ${p.ic}"></i></span><b>${p.label}</b><small>${p.note}</small><small class="nums">${p.set.minuteCap}/min · ${p.set.dayCap}/day · wait ${p.set.delayMin}-${p.set.delayMax}s</small><i class="chk fa-solid fa-circle-check"></i></button>`).join('')
    + `<div class="tile custom${cur === 'custom' ? ' on' : ''}" aria-hidden="${cur !== 'custom'}"><span class="ic"><i class="fa-solid fa-sliders"></i></span><b>Custom</b><small>Your own numbers</small><i class="chk fa-solid fa-circle-check"></i></div>`;
};
$('presetTiles').addEventListener('click', e => {
  const b = e.target.closest('[data-preset]');
  if (!b) return;
  Object.entries(PRESETS[b.dataset.preset].set).forEach(([k, n]) => $(k).value = n);
  paintPreset();
  dirty();
  toast(`${PRESETS[b.dataset.preset].label} picked. Press Save to keep it.`);
});
const showAdv = on => { $('advToggle').checked = on; document.querySelectorAll('.set-group.adv').forEach(g => g.hidden = !on); ls.set('waai_adv', on ? '1' : '0'); };
$('advToggle').addEventListener('change', e => showAdv(e.target.checked));
showAdv(ls.get('waai_adv') === '1');
const dirty = () => {
  const c = values();
  $('saveBar').classList.toggle('show', Object.keys(c).some(k => String(c[k]) !== String(saved[k] ?? '')));
};

// bad input → mark field, jump to its view
const fail = (id, msg) => {
  const el = $(id);
  el.closest('.set-group.adv') && showAdv(true);
  go(el.closest('.view').dataset.view);
  el.classList.add('bad');
  el.focus();
  toast(msg, true);
  return null;
};
const valid = () => {
  const c = values();
  document.querySelectorAll('.field.bad').forEach(f => f.classList.remove('bad'));
  for (const [k, [lo, hi]] of Object.entries(NUMS)) {
    if (!Number.isFinite(c[k]) || c[k] < lo || c[k] > hi) return fail(k, `Use a number from ${lo} to ${hi}`);
  }
  if (c.fxCode && !/^[A-Za-z]{3}$/.test(c.fxCode)) return fail('fxCode', 'Use a 3-letter currency code, like PKR');
  if (c.delayMax < c.delayMin) return fail('delayMax', 'Longest wait must be equal or more than the shortest wait');
  if (c.mcpOn && !/^https:\/\//i.test(c.mcpUrl)) return fail('mcpUrl', 'MCP server URL must start with https://');
  const SAFE_URL = /^https:\/\/|^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/|$)/i; // https only, local test server allowed
  if (c.orderHook && !SAFE_URL.test(c.orderHook)) return fail('orderHook', 'The orders URL must start with https://');
  if (!/\bitems\b/i.test(c.orderFields)) return fail('orderFields', 'Keep "items" in the details to collect');
  if (c.engine === 'webhook' && c.hookUrl && !SAFE_URL.test(c.hookUrl)) return fail('hookUrl', 'Server URL must start with https://');
  return c;
};

// webhook host needs a one-time browser permission
const askHost = urls => {
  try {
    const o = [...new Set(urls.filter(Boolean).flatMap(u => {
      const h = new URL(u).origin;
      return h === 'https://script.google.com' ? [h + '/*', 'https://script.googleusercontent.com/*'] : [h + '/*']; // Apps Script redirects
    }))];
    return o.length ? chrome.permissions.request({ origins: o }) : Promise.resolve(true);
  } catch { return Promise.resolve(false); }
};

const save = async btn => {
  const c = valid();
  if (!c) return false;
  const perm = askHost([c.engine === 'webhook' && c.hookUrl, c.orderHook]); // before any await, the click still counts
  busy(btn, true);
  try {
    if (!(await perm)) return toast('Allow access to your server to use it', true), false;
    if (!ready(c) && saved.enabled) c.enabled = false; // engine lost its key
    await setCfg(c);
    fill(await getCfg());
    return true;
  } finally { busy(btn, false); }
};

$('saveBtn').onclick = async e => (await save(e.currentTarget)) && toast('Settings saved');
$('resetBtn').onclick = () => { fill(saved); toast('Changes undone'); };
document.addEventListener('input', e => e.target.matches('[data-k], [name=engine], [name=voiceVia], [name=shape]') && (e.target.classList.remove('bad'), keyBadges(), dirty()));
document.addEventListener('change', e => {
  if (!e.target.matches('[data-k], [name=engine], [name=voiceVia], [name=shape]')) return;
  e.target.name === 'shape' && (document.documentElement.dataset.shape = e.target.value); // preview, kept on Save
  e.target.name === 'bizMode' && e.target.value === 'form' ? rebuild() : showBiz();
  showEngine();
  dirty();
});
document.addEventListener('input', e => {
  const k = e.target.dataset?.k;
  BIZ_FIELDS.has(k) && bizMode() === 'form' ? (rebuild(), dirty()) : k === 'prompt' && showBiz();
  k in PRESETS.normal.set && paintPreset();
});

// no review: only after a clear warning (direct build only, the store copy has no switch)
$('autoSend')?.addEventListener('change', async e => {
  if (!e.target.checked) return;
  const ok = await confirmBox('Send replies without review?', 'Every reply the AI writes will go to customers straight away, without you checking it. Wrong prices or answers go out too, and fully automatic sending raises the risk of a WhatsApp ban. You can turn it off any time. Turn it on and press Save?', { ok: 'Turn it on', danger: true });
  if (!ok) { e.target.checked = false; dirty(); }
});

// MCP: check the server, tick the tools the AI may use (all ticked = empty = every tool)
let mcpList = [];
const mcpTicks = () => {
  const on = [...document.querySelectorAll('[data-tool]:checked')].map(c => c.dataset.tool);
  $('mcpTools').value = on.length === mcpList.length ? '' : on.join(', ');
  dirty();
};
$('mcpCheck').onclick = async e => {
  const btn = e.currentTarget, url = $('mcpUrl').value.trim(), box = $('mcpResult');
  if (!/^https:\/\//i.test(url)) { $('mcpUrl').classList.add('bad'); $('mcpUrl').focus(); return toast('Add the server URL first, starting with https://', true); }
  let perm = Promise.resolve(false);
  try { perm = chrome.permissions.request({ origins: [new URL(url).origin + '/*'] }); } catch {} // inside the click
  busy(btn, true);
  if (!(await perm)) { busy(btn, false); return toast('Allow access to the server to check it', true); }
  const r = await bg({ type: 'mcpTest', url, token: $('mcpToken').value.trim() });
  busy(btn, false);
  box.hidden = false;
  if (!r.ok) { mcpList = []; box.innerHTML = `<p class="warn-note"><i class="fa-solid fa-circle-exclamation"></i> ${esc(r.err)}</p>`; return; }
  mcpList = r.tools;
  const allowed = $('mcpTools').value.split(',').map(x => x.trim()).filter(Boolean);
  box.innerHTML = `<p class="ok-note"><i class="fa-solid fa-circle-check"></i> Connected${r.name ? ` to ${esc(r.name)}` : ''} · ${r.tools.length} ${r.tools.length === 1 ? 'tool' : 'tools'}. Tick the ones the AI may use.</p>`
    + (r.tools.length ? `<div class="mcp-tools">${r.tools.map(t => `<label><input type="checkbox" data-tool="${esc(t.name)}" ${!allowed.length || allowed.includes(t.name) ? 'checked' : ''}>
      <span><b>${esc(t.name)}</b>${t.desc ? `<small>${esc(t.desc)}</small>` : ''}</span>${t.ro ? '<span class="pill c-sent">Read only</span>' : '<span class="pill c-skip">Not marked read-only</span>'}</label>`).join('')}</div>` : '<p class="hint">The server has no tools yet.</p>');
};
$('mcpResult').addEventListener('change', e => e.target.matches('[data-tool]') && mcpTicks());

$('alertTest').onclick = async e => {
  if ($('saveBar').classList.contains('show')) return toast('Save your changes first', true);
  const btn = e.currentTarget; // gone after the first await
  busy(btn, true);
  const r = await bg({ type: 'alertTest' });
  busy(btn, false);
  r.ok ? toast(r.note || 'Test alert sent') : toast(r.err, true);
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-eye]');
  if (!b) return;
  const inp = $(b.dataset.eye), show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  b.querySelector('i').className = `fa-solid ${show ? 'fa-eye-slash' : 'fa-eye'}`;
});
addEventListener('beforeunload', e => $('saveBar').classList.contains('show') && e.preventDefault());

// bot switch saves at once
const paintBot = on => {
  $('botToggle').checked = on;
  $('botText').textContent = on ? 'Bot on' : 'Bot off';
};
const setBot = async on => {
  const cfg = await getCfg();
  if (on && !ready(cfg)) {
    paintBot(false);
    go('engine');
    return toast('Save an API key for the selected AI first', true);
  }
  if (on && !cfg.consent) { // plain notice + agreement before any chat is read
    paintBot(false);
    const ok = await confirmBox('Before the bot starts', `WA AI Reply reads new messages in your WhatsApp Web chats and sends them, with your business info, to ${ENGINE[cfg.engine] || 'the AI you picked'} so it can write replies. Every reply waits for your Send, except saved quick replies to numbers you approved. Nothing is sent to Rameez Scripts. Do you agree?`, { ok: 'I agree', danger: false });
    if (!ok) return toast('The bot stays off', true);
    await setCfg({ consent: true });
    paintBot(true);
  }
  await setCfg({ enabled: on });
  toast(on ? 'Auto-reply is ON' : 'Auto-reply is OFF');
};
$('botToggle').addEventListener('change', e => setBot(e.target.checked));

// dashboard
const MARK = { sent: 'fa-check', human: 'fa-exclamation', error: 'fa-xmark', stop: 'fa-hand', held: 'fa-pause' };
const tlItem = l => {
  const [, , label] = ST[l.st] || ST.error;
  return `<li class="tl ${esc(l.st)}"><span class="mk">${MARK[l.st] ? `<i class="fa-solid ${MARK[l.st]}"></i>` : ''}</span><div class="tx">
    <b>${esc(l.name || l.phone || l.chatId || 'Chat')}</b>${l.qr?.length ? `<span class="qr-pill"><i class="fa-solid fa-bolt"></i>/${esc(l.qr.join(' /'))}</span>` : ''}${l.order ? '<span class="qr-pill"><i class="fa-solid fa-bag-shopping"></i>Order</span>' : ''}
    <span class="meta">${label} · <time title="${esc(l.at)}">${ago(l.at)}</time></span>
    ${l.in ? `<p><i class="fa-solid fa-arrow-down"></i> ${esc(l.in)}</p>` : ''}
    ${l.out ? `<p><i class="fa-solid fa-arrow-up"></i> ${esc(l.out)}</p>` : ''}
    ${l.err ? `<p${l.raw ? ` title="${esc(l.raw)}"` : ''}><i class="fa-solid fa-circle-info"></i> ${esc(l.err)}</p>` : ''}
    ${l.fix && l.fix !== 'dashboard' && VIEWS[l.fix] ? `<button class="btn ghost sm tl-fix" data-go="${esc(l.fix)}"><i class="fa-solid fa-wrench"></i> ${l.st === 'held' ? 'Change' : 'Fix it'}</button>` : ''}</div></li>`;
};
const paintSide = () => {
  const { cfg, st, qr = [] } = info;
  if (!cfg) return;
  // daily limit meter
  // plan limit = contacts a day; without one, my own messages-a-day limit
  const ppl = Math.max((st.ppl || []).length, licUsed), sent = licDay ? ppl : st.sent || 0, cap = Math.max(1, licDay || +cfg.dayCap), r = sent / cap;
  const lvl = r >= 0.9 ? ['bad', 'Near limit'] : r >= 0.7 ? ['warn', 'Getting close'] : ['', 'Safe'];
  $('mSent').textContent = sent;
  $('mOf').textContent = `/ ${cap}${licDay ? ' contacts' : ''}`;
  $('mBar').parentElement.className = `ib-bar ${lvl[0]}`;
  $('mBar').style.width = `${Math.min(100, Math.round(r * 100))}%`;
  $('mTag').className = `tag ${lvl[0]}`;
  $('mTag').textContent = lvl[1];
  $('mNote').textContent = licDay
    ? (sent >= cap ? 'New contacts used up for today. Contacts already answered keep getting replies. The server is asked again every 5 minutes in case the seller raised it.'
                   : `${cap - sent} new ${cap - sent === 1 ? 'contact' : 'contacts'} left today · contacts already answered can chat as much as they like · resets at midnight`)
    : `${Math.max(0, cap - sent)} replies left today, resets at midnight`;
  // setup checklist
  const voiceOk = !cfg.voiceOn || (cfg.voiceVia !== 'openai' && cfg.geminiKey.trim()) || (cfg.voiceVia !== 'gemini' && cfg.openaiKey.trim());
  const realQr = qr.some(q => q.on !== false && !isDemo(q));
  const checks = [
    [ready(cfg), `${ENGINE[cfg.engine] || 'AI'} ${cfg.engine === 'webhook' ? 'URL' : 'key'} added`, 'engine'],
    [cfg.prompt.trim() !== DEFAULTS.prompt.trim() && (cfg.bizMode === 'form' ? !!cfg.bizName.trim() : cfg.prompt.trim().length > 40), 'Business info written', 'business'],
    [realQr, 'Your own quick replies', 'qr'],
    [info.conn === 'ok', 'WhatsApp Web connected', 'wa'],
    [voiceOk, 'Voice notes can be heard', 'media']
  ];
  $('setupList').innerHTML = checks.map(([ok, t, to]) => `<li class="${ok ? '' : 'no'}"><i class="fa-solid ${ok ? 'fa-check' : 'fa-exclamation'}"></i>${esc(t)}${ok ? '' : `<button class="btn ghost sm" ${to === 'wa' ? 'data-nba="wa"' : `data-go="${to}"`}>Fix</button>`}</li>`).join('');
  // next best action
  const n = (k, txt, acts) => ({ k, txt, acts });
  const demoLeft = qr.some(isDemo);
  const pick = !ready(cfg) ? n('key', 'Run the 4-step setup: pick the AI, add its key, describe your business, go live', [['wiz', 'Start the setup', 'fa-solid fa-wand-magic-sparkles'], ['go:engine', 'AI engine', 'fa-solid fa-key', 1]])
    : info.over ? n('budget', 'The monthly AI budget is used up, so the bot is not replying. Raise the budget or wait for next month', [['go:budget', 'AI budget', 'fa-solid fa-wallet'], ['wa', 'Open WhatsApp', 'fa-brands fa-whatsapp', 1]])
    : info.drafts ? n('drafts', `${info.drafts} ${info.drafts === 1 ? 'reply is' : 'replies are'} waiting for your Send. Check them on WhatsApp Web or here`, [['wa', 'Open WhatsApp', 'fa-brands fa-whatsapp'], ['top', 'See them', 'fa-solid fa-list', 1]])
    : info.conn !== 'ok' ? n('wa', 'Open WhatsApp Web and keep the tab open, the bot works inside it', [['wa', 'Open WhatsApp', 'fa-brands fa-whatsapp'], ['go:guide', 'How it works', 'fa-solid fa-book', 1]])
    : info.live ? n('live', `${info.live} ${info.live === 1 ? 'chat needs' : 'chats need'} you. Reply in WhatsApp, then press Resume`, [['wa', 'Open WhatsApp', 'fa-brands fa-whatsapp'], ['f:human', 'See them', 'fa-solid fa-list', 1]])
    : info.fresh ? n('ord', `${info.fresh} new ${info.fresh === 1 ? 'order is' : 'orders are'} waiting for your check`, [['go:orders', 'Open orders', 'fa-solid fa-bag-shopping'], ['wa', 'Open WhatsApp', 'fa-brands fa-whatsapp', 1]])
    : cfg.prompt.trim() === DEFAULTS.prompt.trim() ? n('biz', 'The AI still uses the demo Business info. Write your real products, prices and timings', [['go:business', 'Business info', 'fa-solid fa-store'], ['go:test', 'Test the AI', 'fa-solid fa-vial', 1]])
    : demoLeft ? n('demo', 'Change the demo quick replies to your real prices, address and bank details', [['go:qr', 'Quick replies', 'fa-solid fa-bolt'], ['go:test', 'Test the AI', 'fa-solid fa-vial', 1]])
    : !cfg.enabled ? n('on', 'Everything is ready. Turn the bot on to start replying', [['on', 'Turn the bot on', 'fa-solid fa-power-off'], ['go:test', 'Test first', 'fa-solid fa-vial', 1]])
    : n('ok', 'All good. Read a few replies in Activity now and then to keep the tone right', [['go:test', 'Test the AI', 'fa-solid fa-vial'], ['go:qr', 'Quick replies', 'fa-solid fa-bolt', 1]]);
  $('nba').innerHTML = `<small><i class="fa-solid fa-bolt"></i> Next best action</small><h3>${esc(pick.txt)}</h3>
    <div class="btn-row">${pick.acts.map(([a, t, ic, ghost]) => `<button class="btn ${ghost ? 'ghost' : ''}" data-nba="${a}"><i class="${ic}"></i> ${esc(t)}</button>`).join('')}</div>`;
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-nba]');
  if (!b) return;
  const a = b.dataset.nba;
  a === 'top' ? $('drafts').scrollIntoView({ behavior: 'smooth', block: 'start' }) : a === 'wiz' ? openWizard() : a === 'wa' ? openWa() : a === 'on' ? setBot(true) : a.startsWith('go:') ? go(a.slice(3))
    : a.startsWith('f:') && (logFilter = a.slice(2), renderDash(), $('logChips').scrollIntoView({ behavior: 'smooth', block: 'center' }));
});

const renderDash = async () => {
  const cfg = await getCfg();
  const { stats, log = [], paused = {}, optout = {}, orders = [], qr = [], usage: u } = await chrome.storage.local.get(['stats', 'log', 'paused', 'optout', 'orders', 'qr', 'usage']);
  const usage = u?.month === month() ? u : { cost: 0 }, br = cfg.budgetOn && +cfg.budget > 0 ? usage.cost / cfg.budget : 0;
  $('dCost').textContent = money(usage.cost, cfg);
  $('dCostBar').style.width = `${Math.min(100, Math.round(br * 100))}%`;
  $('dCostBar').parentElement.className = `ib-bar ${br >= 1 ? 'bad' : br >= 0.8 ? 'warn' : ''}`;
  $('dCostNote').textContent = cfg.budgetOn ? `${Math.round(br * 100)}% of the $${cfg.budget} budget` : 'No budget set';
  const st = stats?.day === today() ? stats : {};
  const live = Object.entries(paused).filter(([, t]) => t > Date.now());
  const fresh = orders.filter(o => o.status === 'new').length;
  info = { ...info, cfg, st, qr, over: br >= 1, budgetPct: cfg.budgetOn ? Math.round(br * 100) : null, live: live.length, fresh, orders: orders.length, qrAll: qr.length, qrOn: qr.filter(q => q.on !== false).length };
  // today rows
  $('kSent').textContent = st.sent || 0;
  $('kHuman').textContent = live.length;
  $('kOrders').textContent = fresh;
  $('kSkip').textContent = st.skip || 0;
  $('kError').textContent = st.error || 0;
  $('todayDate').textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  // settings at a glance
  const voiceVia = cfg.voiceVia !== 'openai' && cfg.geminiKey.trim() ? 'Gemini' : cfg.voiceVia !== 'gemini' && cfg.openaiKey.trim() ? 'OpenAI' : '';
  $('fEngine').textContent = `${ENGINE[cfg.engine] || 'Claude'}${ready(cfg) ? '' : ' · no key'}`;
  $('fModel').textContent = modelOf(cfg) || '-';
  $('fQr').textContent = `${info.qrOn} of ${qr.length}`;
  $('fVoice').textContent = !cfg.voiceOn ? 'Off' : voiceVia ? `On, ${voiceVia}` : 'On, no key';
  $('fHours').textContent = cfg.hoursOn ? `${cfg.hoursFrom} – ${cfg.hoursTo}` : 'All day';
  // waiting for you + timeline
  const names = Object.fromEntries([...log].reverse().map(l => [l.chatId, l]));
  $('paused').innerHTML = live.length ? `<span class="sub">Waiting for you</span>` + live.map(([id, t]) => {
    const l = names[id] || {};
    return `<div class="wrow"><span class="ic"><i class="fa-solid fa-user-clock"></i></span>
      <div><b>${esc(l.name || l.phone || id.split('@')[0])}</b><small>${esc(l.err || l.in || 'You replied yourself')} · paused till ${new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>
      <div class="btn-row"><button class="btn ghost sm" data-open-chat="${esc(id)}">Open chat</button><button class="btn ghost sm" data-resume="${esc(id)}">Resume</button></div></div>`;
  }).join('') : '';
  // replies waiting for my Send; keep what I typed while it re-renders
  const { drafts: dl = [] } = await chrome.storage.local.get('drafts'), drafts = dl.filter(d => Date.now() - new Date(d.at) < 864e5);
  info.drafts = drafts.length;
  if (!document.activeElement?.matches?.('[data-dtext]')) {
    const typed = Object.fromEntries([...document.querySelectorAll('[data-dtext]')].map(t => [t.dataset.dtext, t.value]));
    $('drafts').innerHTML = drafts.length ? `<span class="sub">Waiting for your Send (${drafts.length})</span>` + drafts.map(d => `<div class="drow">
      <div class="dhead"><b>${esc(d.name || d.phone || 'Customer')}</b>${d.kind === 'optout' ? '<span class="pill c-skip">Stop note</span>' : d.kind === 'payment' ? '<span class="pill c-new">Payment</span>' : ''}<time>${ago(d.at)}</time></div>
      ${d.inText ? `<p class="din"><i class="fa-solid fa-arrow-down"></i> ${esc(d.inText)}</p>` : ''}
      <textarea class="field dtext" data-dtext="${esc(d.id)}" rows="3" aria-label="Reply to ${esc(d.name || d.phone || 'customer')}, you can change it">${esc(typed[d.id] ?? d.text)}</textarea>
      ${(d.files || []).length || d.loc ? `<span class="sub">${[(d.files || []).length ? `+ ${d.files.length} file${d.files.length > 1 ? 's' : ''}` : '', d.loc ? '+ map pin' : ''].filter(Boolean).join(' · ')}</span>` : ''}
      <div class="btn-row"><button class="btn sm" data-dsend="${esc(d.id)}"><i class="fa-solid fa-paper-plane"></i> Send</button><button class="btn ghost sm" data-dskip="${esc(d.id)}"><i class="fa-solid fa-forward"></i> Skip</button><button class="btn ghost sm" data-open-chat="${esc(d.chatId)}"><i class="fa-brands fa-whatsapp"></i> Open chat</button></div></div>`).join('') : '';
  }
  $('pillHuman').hidden = $('bellDot').hidden = !(live.length + drafts.length);
  $('pillHuman').textContent = $('bellDot').textContent = live.length + drafts.length > 99 ? '99+' : live.length + drafts.length;
  const rows = logFilter ? log.filter(l => l.st === logFilter) : log;
  $('log').innerHTML = rows.slice(0, 40).map(tlItem).join('')
    || `<li class="empty"><i class="fa-regular fa-comments"></i><b>${logFilter ? 'Nothing here' : 'No activity yet'}</b>${logFilter ? 'Nothing with this label in the last 100 entries.' : 'Turn the bot on and every reply shows up here.'}</li>`;
  $('logCount').textContent = rows.length ? `${Math.min(40, rows.length)} of ${rows.length} shown` : '';
  document.querySelectorAll('#logChips [data-f]').forEach(b => b.classList.toggle('active', b.dataset.f === logFilter));
  $('optouts').innerHTML = optoutHtml(optout, log);
  paintBot(cfg.enabled);
  paintSide();
  head();
};
const renderConn = async () => {
  const [cls, txt] = await connState();
  $('connChip').innerHTML = `<span class="dot ${cls}"></span><span>${esc(txt)}</span>`;
  $('fConn').textContent = cls === 'ok' ? 'Connected' : cls === 'wait' ? 'Loading…' : txt;
  if (info.conn !== cls) { info.conn = cls; paintSide(); }
};
document.querySelectorAll('[data-filter]').forEach(b => b.onclick = () => { logFilter = b.dataset.filter; renderDash(); });
$('logChips').addEventListener('click', e => { const b = e.target.closest('[data-f]'); b && (logFilter = b.dataset.f, renderDash()); });
$('logClear').onclick = async e => { const btn = e.currentTarget; busy(btn, true); await bg({ type: 'clearLog' }); busy(btn, false); toast('Activity cleared'); };
$('optouts').addEventListener('click', async e => {
  const b = e.target.closest('[data-optin]');
  if (!b) return;
  busy(b, true);
  await bg({ type: 'optin', chatId: b.dataset.optin });
  toast('Auto-replies allowed again for this chat');
});
// customer notes count + forget
const memoCount = async () => { const n = Object.keys((await chrome.storage.local.get('memo')).memo || {}).length; $('memoCount').textContent = n ? `${n} ${n === 1 ? 'customer' : 'customers'} remembered` : 'No notes yet'; };
$('memoClear').onclick = async e => {
  const btn = e.currentTarget; // gone after the confirm
  if (!(await confirmBox('Forget all customer notes?', 'The AI will read older chats again the next time each customer writes. Orders are not touched.'))) return;
  busy(btn, true);
  await bg({ type: 'memoClear' });
  busy(btn, false);
  toast('All customer notes forgotten');
};
chrome.storage.onChanged.addListener(c => c.memo && memoCount());
memoCount();

$('drafts').addEventListener('click', async e => {
  const s = e.target.closest('[data-dsend]'), k = e.target.closest('[data-dskip]'), o = e.target.closest('[data-open-chat]');
  if (o) return bg({ type: 'openChat', chatId: o.dataset.openChat });
  const b = s || k;
  if (!b) return;
  busy(b, true);
  const r = s ? await bg({ type: 'draftSend', id: s.dataset.dsend, text: document.querySelector(`[data-dtext="${CSS.escape(s.dataset.dsend)}"]`)?.value })
    : await bg({ type: 'draftSkip', id: k.dataset.dskip });
  busy(b, false);
  r.ok === false ? toast(r.err, true) : toast(s ? 'Sent' : 'Skipped');
});
$('paused').addEventListener('click', async e => {
  const r = e.target.closest('[data-resume]'), o = e.target.closest('[data-open-chat]');
  if (o) return bg({ type: 'openChat', chatId: o.dataset.openChat });
  if (!r) return;
  busy(r, true);
  await bg({ type: 'resume', chatId: r.dataset.resume });
  toast('Chat resumed');
});

// test chat
const bubble = (cls, html) => {
  const d = document.createElement('div');
  d.className = `bubble ${cls}`;
  d.innerHTML = html;
  $('chatLog').append(d);
  $('chatLog').scrollTop = $('chatLog').scrollHeight;
  return d;
};
const chatIntro = () => !$('chatLog').children.length && bubble('note', 'Type a message the way a customer would. Saved settings are used. The chat here continues, so you can test follow-up questions.');
const testTurns = () => [...$('chatLog').querySelectorAll('.bubble.in, .bubble.out')].filter(b => b.firstChild?.nodeType === 3) // real text only, not the typing dots or a Needs-you note
  .map(b => ({ me: b.classList.contains('out'), text: b.firstChild.textContent })).filter(t => t.text.trim());
$('testClear')?.addEventListener('click', () => { $('chatLog').innerHTML = ''; chatIntro(); });
$('testForm').onsubmit = async e => {
  e.preventDefault();
  const btn = $('testBtn'), text = $('testIn').value.trim();
  if (!text) return $('testIn').focus();
  if ($('saveBar').classList.contains('show') && !(await save(btn))) return;
  const cfg = await getCfg();
  if (!ready(cfg)) return go('engine'), toast('Add an API key for the selected AI first', true);
  $('testIn').value = '';
  const items = testTurns(); // the chat so far, so the AI remembers what it already said here
  bubble('in', esc(text));
  const wait = bubble('out', '<span class="typing" aria-label="AI is typing"><i></i><i></i><i></i></span>');
  busy(btn, true);
  try {
    const r = await bg({ type: 'test', text, items });
    const out = r.text || '';
    wait.className = `bubble ${r.ok ? 'out' : 'err'}`;
    wait.innerHTML = !r.ok ? `<i class="fa-solid fa-circle-exclamation"></i> ${esc(r.err)}`
      : /\[HUMAN\]/.test(out) ? '<i class="fa-solid fa-user-clock"></i> AI would hand this chat to you (Needs you)'
      : !out || /\[SKIP\]/.test(out) ? '<i class="fa-solid fa-forward"></i> AI would not reply to this'
      : `${esc(out)}<small>${esc(ENGINE[cfg.engine])}</small>`;
  } finally { busy(btn, false); $('testIn').focus(); }
};

chrome.storage.onChanged.addListener(c => {
  c.cfg && (saved = { ...saved, enabled: !!c.cfg.newValue?.enabled });
  (c.stats || c.log || c.paused || c.cfg || c.optout || c.orders || c.qr || c.usage || c.drafts) && renderDash();
  c.status && renderConn();
  c.lic && licSync();
});

getCfg().then(async cfg => {
  fill(cfg);
  renderDash();
  const L0 = await licState();
  if (!L0.ok && !L0.dev) return go('license'); // locked: key first, the wizard follows activation
  !cfg.setupDone && !ready(cfg) && !wizLater() ? openWizard() : openTour(); // first run
});
addEventListener('waai:licensed', () => getCfg().then(cfg => !cfg.setupDone && !ready(cfg) && !wizLater() && openWizard()));
addEventListener('waai:saved', () => getCfg().then(fill));
$('wizOpen').onclick = () => openWizard();
$('tourOpen').onclick = () => openTour(true);
renderConn();
licSync();
setInterval(renderConn, 20000);
go(location.hash.slice(1));
chatIntro();
