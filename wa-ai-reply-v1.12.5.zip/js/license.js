/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// licence key: one key = one device. activate / check / remove against the seller's server.
// every server answer is signed (ECDSA P-256 / SHA-256); this file only holds the public key.
import { today } from './cfg.js';

export const LIC_URL = 'https://license.rameezscripts.com/license_api.php';
export const LIC_PUB = 'BEKoFr1zOmJr0KszBjLqd_3x13e6kX5KrZ0PqHsY5W5eA6gmH69xA9x14MPPLmq7L35ppEfq26VpiuOqbPssalk'; // Licenses › Server settings › Public key (license.rameezscripts.com) — never change after release
const store = chrome.storage.local;
const VER = chrome.runtime.getManifest().version;
const NET = 'Could not reach the licence server. Check the internet and try again.';
const BAD = 'The licence server answer could not be checked. Try again in a few minutes.';

const bytes = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(s + '='.repeat((4 - s.length % 4) % 4)), c => c.charCodeAt(0)); };
let pubKey = null;
const seen = new Map(); // payload -> verified, per worker life
const verify = async (payload, sig) => {
  if (seen.has(payload)) return seen.get(payload);
  let ok = false;
  try {
    pubKey ??= crypto.subtle.importKey('raw', bytes(LIC_PUB), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await pubKey, bytes(sig || ''), new TextEncoder().encode(payload));
  } catch {}
  seen.size > 20 && seen.clear();
  seen.set(payload, ok);
  return ok;
};

// random install id: one per Chrome profile, never synced, never sent anywhere but the licence server
export const deviceId = async () => {
  let { licDevice } = await store.get('licDevice');
  if (!licDevice) await store.set({ licDevice: licDevice = crypto.randomUUID() });
  return licDevice;
};
export const deviceLabel = () => {
  const ua = navigator.userAgent, b = ua.match(/Edg\/(\d+)/) ? `Edge ${ua.match(/Edg\/(\d+)/)[1]}` : ua.match(/Chrome\/(\d+)/) ? `Chrome ${ua.match(/Chrome\/(\d+)/)[1]}` : 'Browser';
  const os = /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /CrOS/.test(ua) ? 'ChromeOS' : /Android/.test(ua) ? 'Android' : /Linux/.test(ua) ? 'Linux' : 'another system';
  return `${b} · ${os}`;
};

const call = async (action, key, extra = {}) => {
  const device = await deviceId(), nonce = crypto.randomUUID().replace(/-/g, '');
  const { lic } = await store.get('lic');
  let tok = '';
  try { tok = lic?.payload ? JSON.parse(lic.payload).tok || '' : ''; } catch {}   // the device token the server gave last time (signed, so it can't be made up)
  let j;
  try {
    const r = await fetch(LIC_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(15000),
      body: JSON.stringify({ action, key, device, nonce, label: deviceLabel(), ver: VER, tok, ...extra }) });
    j = await r.json();
  } catch (e) { return { net: e?.name === 'SyntaxError' ? BAD : NET }; }
  if (!j?.payload || !(await verify(j.payload, j.sig))) return { net: BAD };
  const p = JSON.parse(j.payload);
  if (p.nonce !== nonce || p.device !== device) return { net: BAD }; // an old or someone else's answer
  return { p, payload: j.payload, sig: j.sig };
};

// what the stored, signed answer says right now (no network)
export const licState = async () => {
  if (!LIC_PUB) return { ok: true, dev: true, state: 'dev', day: 0 };
  const { lic, licSeen = 0 } = await store.get(['lic', 'licSeen']);
  if (!lic?.key) return { ok: false, state: 'none', day: 0 };
  const base = { key: lic.key, at: lic.at || 0, lastTry: lic.try || 0, net: lic.net || '' };
  if (!lic.payload || !(await verify(lic.payload, lic.sig))) return { ...base, ok: false, state: 'none', day: 0 };
  const p = JSON.parse(lic.payload);
  if (p.device !== await deviceId() || p.key !== lic.key) return { ...base, ok: false, state: 'none', day: 0 };
  // clock turned back never buys time: the latest moment seen (or the server's own) wins
  const t = Math.max(Date.now(), licSeen, p.now * 1000);
  t - licSeen > 60000 && store.set({ licSeen: t });
  const checkMs = (p.checkm ?? p.check * 60) * 60000, graceMs = (p.gracem ?? p.grace * 1440) * 60000;   // minutes from the server (old servers: hours / days)
  const exp = p.exp ? p.exp * 1000 : 0, offlineEnd = p.now * 1000 + checkMs + graceMs;   // from the server's signed time, never from local storage
  let state = p.code === 'ok' ? (exp && exp <= t ? 'expired' : 'active') : p.code;
  if (state === 'active' && t > offlineEnd) state = 'offline';
  return { ...base, ok: state === 'active', state, msg: p.msg, exp, days: exp ? Math.floor((exp - t) / 864e5) : null, day: +p.day || 0,
    plan: p.plan || '', name: p.name || '', moves: p.moves ?? 0, renew: p.renew || '', product: p.product || 'WA AI Reply', checkMs, graceMs,
    offlineEnd, cday: p.cday || today(), used: +p.used || 0 };
};

// short-lived server trouble keeps the last good answer (offline grace covers it)
const TRANSIENT = new Set(['rate_limited', 'bad_request', 'server']);
const save = async (key, r) => {
  const { lic = {} } = await store.get('lic');
  if (r.net || TRANSIENT.has(r.p.code)) {
    await store.set({ lic: { ...lic, key: lic.key || key, try: Date.now(), net: r.net || r.p.msg } });
    return;
  }
  await store.set({ lic: { key: r.p.key || key, payload: r.payload, sig: r.sig, at: Date.now(), try: Date.now(), net: '' } });
};

let running = null;
// activate | verify | release | contact, then the new state (+ the raw answer). invalid keys are never stored
export const licCall = (action, key, extra) => running = (async () => {
  await running?.catch(() => {});
  const r = await call(action, key, extra);
  if (!r.net && r.p.code === 'invalid' && action === 'activate') return { ...(await licState()), fail: r.p.msg };
  if (!r.net && r.p.code === 'released') { await store.remove('lic'); return { ok: false, state: 'none', day: 0, done: r.p.msg }; }
  await save(key, r);
  const s = await licState();
  return r.net || TRANSIENT.has(r.p.code) ? { ...s, fail: r.net || r.p.msg } : { ...s, p: r.p, raw: { payload: r.payload, sig: r.sig } };
})();

// check with the server when the last answer is older than the server's check interval (or when forced)
export const licRefresh = async (force = false) => {
  const s = await licState();
  if (s.dev || !s.key) return s;
  const due = Date.now() - s.at > (s.checkMs || 600000) || s.state === 'offline';
  if (!force && (!due || Date.now() - s.lastTry < 60000)) return s; // server down: try again each minute, not on every message
  return licCall('verify', s.key);
};

export const licForget = () => store.remove(['lic', 'licPermits']);

// new contact today = a signed permit from the server, which counts contacts itself. Permits are kept for that server day
// and checked again on every use, so editing storage can't add contacts or lift the limit
const sha = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join('');
const refused = new Map(); // who -> time the server said no (asked again after 5 min)
const permitOk = async (e, who, s) => {
  if (!e || !(await verify(e.payload, e.sig))) return false;
  const p = JSON.parse(e.payload);
  return p.code === 'ok' && p.permit === true && p.who === who && p.key === s.key && p.device === await deviceId() && p.cday === s.cday;
};
export const licPermit = async chatId => {
  const s = await licState();
  if (s.dev) return { ok: true };
  if (!s.ok) return { ok: false };
  const who = await sha(`${s.key}|${chatId}`);
  const { licPermits: P = {} } = await store.get('licPermits');
  if (P.cday === s.cday && await permitOk((P.list || []).find(e => e.who === who), who, s)) return { ok: true };
  if (Date.now() - (refused.get(who) || 0) < 300000) return { ok: false, limit: true };
  const r = await licCall('contact', s.key, { who });
  if (r.p?.code !== 'ok') return { ok: false, net: !!r.fail };
  if (!r.p.permit) { refused.set(who, Date.now()); return { ok: false, limit: true, used: r.p.used }; }
  refused.delete(who);
  const { licPermits: Q = {} } = await store.get('licPermits');
  const list = Q.cday === r.p.cday ? Q.list || [] : [];
  await store.set({ licPermits: { cday: r.p.cday, list: [...list.filter(e => e.who !== who), { who, ...r.raw }].slice(-3000) } });
  return { ok: true, used: r.p.used };
};
