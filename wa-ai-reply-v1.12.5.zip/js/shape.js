/**
 * Developed by Mohammad Rameez Imdad (Rameez Scripts)
 * WhatsApp: https://wa.me/923435347417 (For Custom Projects)
 * YouTube: https://www.youtube.com/@rameezimdad (Subscribe for more!)
 */
// corner shape before first paint, rounded by default
try { document.documentElement.dataset.shape = localStorage.getItem('waai_shape') || 'rounded'; }
catch { document.documentElement.dataset.shape = 'rounded'; }
